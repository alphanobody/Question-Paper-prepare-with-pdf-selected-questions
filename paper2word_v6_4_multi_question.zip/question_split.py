"""Locate printed MAIN question headings, never parenthesized option labels.

Geometry is in original PDF points. This module has no OCR/PDF imports and no
source-specific question text/coordinates. Detection is intentionally bounded
and conservative for ambiguous/incomplete selections.
"""
import re

HEADING=re.compile(r'^\s*(?:(?:Q(?:uestion)?\.?\s*)?(\d{1,4})\.(?!\d)\s*|Q(?:uestion)?\.?\s*(\d{1,4})(?:[.):\s]|$))',re.I)


def split_selection(clip,lines,column_split=None):
    left,top,right,bottom=map(float,clip);warnings=[];anchors=[]
    for line in lines:
        if float(line.get('confidence',100))<70:continue
        text=str(line.get('text','')).strip();match=HEADING.match(text)
        if not match:continue
        number=int(match[1] or match[2])
        if not 1<=number<=9999:continue
        try:x0,y0,x1,y1=map(float,line['bbox'])
        except (KeyError,ValueError,TypeError):continue
        if not left-1<=x0<=right or not top-2<=y0<bottom:continue
        anchors.append(dict(number=number,x=x0,y=y0,bottom=y1,text=text))
    if len(anchors)<2:return [dict(bbox=[left,top,right,bottom],source_number=None)],warnings
    crossing=column_split is not None and left<float(column_split)-12 and right>float(column_split)+12
    if crossing:
        mid=float(column_split)
        left_heads=[a for a in anchors if a['x']<mid-8]
        right_heads=[a for a in anchors if a['x']>=mid-8]
        if not left_heads or not right_heads:
            warnings.append('This selection spans source columns, but clear headings were not found in both. It was kept together; use one box per column if it contains several questions.')
            return [dict(bbox=[left,top,right,bottom],source_number=None)],warnings
        groups=[(left,mid,left_heads),(mid,right,right_heads)]
    else:groups=[(left,right,anchors)]
    accepted=[]
    for x0,x1,heads in groups:
        # Main question numbers occupy the leftmost heading margin. Indented
        # numbered steps/lists must not turn into extra questions.
        margin=min(a['x'] for a in heads)
        heads=sorted([a for a in heads if abs(a['x']-margin)<=8],key=lambda a:a['y'])
        unique=[]
        for a in heads:
            if unique and abs(a['y']-unique[-1]['y'])<5:
                if a['x']<unique[-1]['x']:unique[-1]=a
                continue
            unique.append(a)
        selected=[]
        for a in unique:
            if not selected or a['number']>selected[-1]['number']:
                selected.append(a)
        if not selected:continue
        if any(b['number']!=a['number']+1 for a,b in zip(selected,selected[1:])):
            warnings.append('There is a gap in the detected source question numbers. Check the detected question count; an unreadable number can prevent a correct split.')
        for index,a in enumerate(selected):
            y0=top if index==0 else max(top,a['y']-2)
            y1=min(bottom,selected[index+1]['y']-2) if index+1<len(selected) else bottom
            if y1-y0<12:continue
            accepted.append(dict(bbox=[x0,y0,x1,y1],source_number=a['number']))
    if not 2<=len(accepted)<=100:
        return [dict(bbox=[left,top,right,bottom],source_number=None)],warnings
    numbers=[r['source_number'] for r in accepted]
    if any(b<=a for a,b in zip(numbers,numbers[1:])):
        warnings.append('Question headings were ambiguous across columns. The selection was kept together rather than guessing.')
        return [dict(bbox=[left,top,right,bottom],source_number=None)],warnings
    return accepted,warnings
