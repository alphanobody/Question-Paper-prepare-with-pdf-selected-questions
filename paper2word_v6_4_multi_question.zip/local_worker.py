"""Isolated local MinerU worker. No cloud client or API-key input.

Pinned to MinerU 4.2.3 because the explicit low-memory hooks are version-specific.
One subprocess per question releases native-model RAM on completion.
"""
import os
import sys
import json
import socket
from pathlib import Path

BASE = Path(__file__).resolve().parent


def runtime_environment():
    os.environ.setdefault('MINERU_HOME', str(BASE / 'model_data'))
    for key, value in {
        'MINERU_TELEMETRY_DISABLED': '1', 'HF_HUB_DISABLE_TELEMETRY': '1',
        'HF_HUB_OFFLINE': '1', 'TRANSFORMERS_OFFLINE': '1',
        'MINERU_MODEL_SMALL_BACKEND': 'onnx', 'MINERU_MODEL_ONNX_DEVICE': 'cpu',
        'MINERU_PROCESSING_WINDOW_SIZE': '1', 'MINERU_INTRA_OP_NUM_THREADS': '2',
        'MINERU_INTER_OP_NUM_THREADS': '1', 'MINERU_MALLOC_TRIM': '1',
        'OMP_NUM_THREADS': '2', 'OPENBLAS_NUM_THREADS': '2',
    }.items():
        os.environ[key] = value
    for key in ('GOOGLE_API_KEY', 'GEMINI_API_KEY', 'OPENAI_API_KEY', 'MINERU_API_KEY'):
        os.environ.pop(key, None)


def block_remote_connections():
    """Prevent Python networking to non-loopback addresses during recognition.

    Local sockets are retained for PDF renderer multiprocessing. The local
    parser and CPUExecutionProvider do not use remote inference services.
    """
    original_connect = socket.socket.connect
    original_ex = socket.socket.connect_ex
    original_lookup = socket.getaddrinfo
    def allowed(address):
        if isinstance(address, (str, bytes)):  # local Unix socket
            return True
        return isinstance(address, tuple) and str(address[0]) in ('127.0.0.1', '::1', 'localhost')
    def connect(self, address):
        if not allowed(address):
            raise OSError('External networking is disabled during local recognition. Run SETUP_LOCAL_WINDOWS.bat if models are missing.')
        return original_connect(self, address)
    def connect_ex(self, address):
        if not allowed(address):
            raise OSError('External networking is disabled during local recognition.')
        return original_ex(self, address)
    def lookup(host, *args, **kwargs):
        if host not in (None, '127.0.0.1', '::1', 'localhost'):
            raise OSError('External DNS is disabled during local recognition.')
        return original_lookup(host, *args, **kwargs)
    socket.socket.connect = connect
    socket.socket.connect_ex = connect_ex
    socket.getaddrinfo = lookup


def low_memory_models():
    from importlib.metadata import version
    if version('mineru') != '4.2.3':
        raise RuntimeError('This build requires MinerU 4.2.3. Run SETUP_LOCAL_WINDOWS.bat.')
    import onnxruntime as ort
    import mineru.model.runtime.onnx as runtime
    import mineru.model.mfr.pp_formulanet_plus_m_onnx as formula
    def create(model_path, **options):
        # CPU-only profile: avoid graph-optimizer/arena allocation peaks for
        # layout as well as formula models. Arithmetic/model weights unchanged.
        settings = ort.SessionOptions()
        settings.intra_op_num_threads = 2
        settings.inter_op_num_threads = 1
        settings.graph_optimization_level = ort.GraphOptimizationLevel.ORT_DISABLE_ALL
        settings.enable_cpu_mem_arena = False
        settings.enable_mem_pattern = False
        return ort.InferenceSession(model_path, sess_options=settings, providers=['CPUExecutionProvider'])
    runtime.create_ort_session = create
    formula.CPU_BATCH_SIZE = 1


# Spawned PDF renderer processes must inherit the offline network guard too.
runtime_environment()
block_remote_connections()


def read_geometry(input_pdf,dpi=260):
    import numpy as np
    import pymupdf as fitz
    from mineru.model.ocr.pp_ocr_v6_onnx import PPOCRv6ONNX
    models = Path(os.environ['MINERU_HOME']) / 'models' / 'MinerU-4_models_onnx'
    ocr = PPOCRv6ONNX(
        str(models/'OCR/paddleocr/ch_PP-OCRv6_tiny_det_infer.onnx'),
        str(models/'OCR/paddleocr/ch_PP-OCRv6_small_rec_infer.onnx'),
        enable_merge_det_boxes=False, rec_batch_num=1, intra_op_num_threads=2)
    with fitz.open(input_pdf) as source:
        pix = source[0].get_pixmap(dpi=dpi, alpha=False)
        img = np.frombuffer(pix.samples, dtype=np.uint8).reshape(pix.height, pix.width, 3)[:,:,::-1].copy()
        recognized = ocr.ocr(img)[0] or []
        geometry = [
            {'bbox':[min(p[0] for p in box)/pix.width, min(p[1] for p in box)/pix.height,
                     max(p[0] for p in box)/pix.width, max(p[1] for p in box)/pix.height],
             'text':str(rec[0]), 'confidence':float(rec[1])*100}
            for box,rec in recognized]
    return geometry


def main():
    if len(sys.argv) not in (3,4) or (len(sys.argv)==4 and sys.argv[3]!='--detect-questions'):
        raise SystemExit('Usage: local_worker.py input.pdf output.json [--detect-questions]')
    output=Path(sys.argv[2])
    try:
        low_memory_models()
        if len(sys.argv)==4:
            # No layout/formula/table weights are loaded by this small probe.
            data={'pages':[{'blocks':[]}], 'question_probe':True,
                  'local_geometry':read_geometry(sys.argv[1],dpi=240)}
        else:
            from mineru import parse
            result=parse(Path(sys.argv[1]),tier='basic',ocr_mode='ocr')
            data=result.to_dict()
            data['local_geometry']=read_geometry(sys.argv[1])
        output.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding='utf-8')
    except Exception as exc:
        # No credentials exist in this worker. Keep diagnostics local for setup.
        print('LOCAL_RECOGNITION_ERROR:', str(exc), file=sys.stderr)
        raise SystemExit(1)


if __name__ == '__main__':
    import multiprocessing
    multiprocessing.freeze_support()
    main()
