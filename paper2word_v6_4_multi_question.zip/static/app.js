"use strict";

const state = {
  jobId: null,
  pages: [],
  pageCount: 0,
  filename: "",
  selections: {},           // pageNumber -> [{x,y,w,h}]  (ratios 0..1)
  currentSelectPage: 1,
  rangeText: "",
  pollTimer: null,
  reviewModel: null,
};

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

// Map step number -> panel id
const PANELS = { 1: "panel-1", 2: "panel-select", 3: "panel-3", 4: "panel-4" };

function showStep(n) {
  $$(".panel").forEach((p) => p.classList.add("hidden"));
  const panel = $(`#${PANELS[n]}`);
  if (panel) panel.classList.remove("hidden");
  $$(".step").forEach((s) => {
    const sn = Number(s.dataset.step);
    s.classList.toggle("active", sn === (n === 3 ? 2 : n));
    s.classList.toggle("done", sn < n);
  });
}

// ---------------------------------------------------------------------------
// Step 1 — Upload
// ---------------------------------------------------------------------------
const dropzone = $("#dropzone");
const fileInput = $("#fileInput");

["dragover", "dragenter"].forEach((ev) =>
  dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.add("drag"); })
);
["dragleave", "drop"].forEach((ev) =>
  dropzone.addEventListener(ev, (e) => { e.preventDefault(); dropzone.classList.remove("drag"); })
);
dropzone.addEventListener("drop", (e) => {
  const f = e.dataTransfer.files[0];
  if (f) uploadFile(f);
});
fileInput.addEventListener("change", (e) => {
  const f = e.target.files[0];
  if (f) uploadFile(f);
});

function uploadFile(file) {
  state.reviewModel = null; state.dirty = false;
  $("#optionalReview").classList.add("hidden");
  const errBox = $("#uploadError");
  errBox.hidden = true;
  if (!file.name.toLowerCase().endsWith(".pdf")) {
    errBox.textContent = "Please choose a PDF file.";
    errBox.hidden = false;
    return;
  }
  const fd = new FormData();
  fd.append("file", file);
  dropzone.querySelector(".dz-inner").innerHTML = "<strong>Opening PDF…</strong>";

  fetch("/api/upload", { method: "POST", body: fd })
    .then((r) => r.json().then((j) => (r.ok ? j : Promise.reject(j))))
    .then((j) => {
      state.jobId = j.job_id;
      state.pages = j.pages;
      state.pageCount = j.page_count;
      state.filename = j.filename;
      state.selections = {};
      state.rangeText = `1-${j.page_count}`;
      state.currentSelectPage = 1;
      renderSelectPage(1);
      showStep(2);
    })
    .catch((j) => {
      errBox.textContent = j.error || "Upload failed. Please try again.";
      errBox.hidden = false;
      dropzone.querySelector(".dz-inner").innerHTML = `
        <div class="dz-icon">⬆</div>
        <strong>Drop a PDF here</strong> or click to browse
        <small>Question papers, test series, worksheets — up to ~120 pages</small>`;
    });
}

// ---------------------------------------------------------------------------
// Step 2 — Select questions (draw boxes, Prev/Next)
// ---------------------------------------------------------------------------
const selImg = $("#selImg");
const selOverlay = $("#selOverlay");
const selPageLabel = $("#selPageLabel");
const selCount = $("#selCount");

function renderSelectPage(n) {
  state.currentSelectPage = n;
  const pg = state.pages.find((p) => p.n === n);
  if (!pg) return;
  $('#pageLoading').hidden = false; $('#pageError').hidden = true;
  $('#selectStage').classList.add('page-busy');
  $('#selOverlay').inert = true;
  selImg.src = pg.url;
  selPageLabel.textContent = `Page ${n} / ${state.pageCount}`;
  $("#prevPageBtn").disabled = n <= 1;
  $("#nextPageBtn").disabled = n >= state.pageCount;
  drawSelections(n);
  updateSelCount(n);
}

selImg.addEventListener('load', () => {
  $('#pageLoading').hidden = true;
  $('#selectStage').classList.remove('page-busy');
  $('#selOverlay').inert = false;
});
selImg.addEventListener('error', () => {
  $('#pageLoading').hidden = true;
  $('#pageError').textContent = 'Could not display this page. Go to another page and return to retry.';
  $('#pageError').hidden = false;
});

function updateSelCount(n) {
  const arr = state.selections[n] || [];
  selCount.textContent = `${arr.filter((r) => r.kind === "text" || !r.kind).length} selections · ${arr.filter((r) => r.kind && r.kind !== "text").length} extras`;
}

function drawSelections(n) {
  selOverlay.querySelectorAll(".sel-rect").forEach((el) => el.remove());
  const arr = state.selections[n] || [];
  arr.forEach((r, idx) => addRectEl(r, idx, n));
}

function addRectEl(r, idx, n) {
  const div = document.createElement("div");
  div.className = "sel-rect" + (r.kind === "diagram" ? " diagram" : r.kind === "table" ? " table-box" : "");
  const label = document.createElement("span");
  label.className = "box-label";
  label.textContent = `${idx + 1} · ${r.kind === "diagram" ? "Diagram" : r.kind === "table" ? "Table" : "Selection"}`;
  div.appendChild(label);
  div.style.left = r.x * 100 + "%";
  div.style.top = r.y * 100 + "%";
  div.style.width = r.w * 100 + "%";
  div.style.height = r.h * 100 + "%";
  const del = document.createElement("button");
  del.className = "del";
  del.textContent = "×";
  del.title = "Remove";
  del.addEventListener("click", (e) => {
    e.stopPropagation();
    state.selections[n].splice(idx, 1);
    drawSelections(n);
    updateSelCount(n);
  });
  div.appendChild(del);
  selOverlay.appendChild(div);
}

function ratioXY(e) {
  const rect = selOverlay.getBoundingClientRect();
  let x = (e.clientX - rect.left) / rect.width;
  let y = (e.clientY - rect.top) / rect.height;
  return { x: Math.max(0, Math.min(1, x)), y: Math.max(0, Math.min(1, y)) };
}

let dragStart = null;
let tempRect = null;

selOverlay.addEventListener("pointerdown", (e) => {
  if (e.target.closest("button")) return;
  e.preventDefault();
  dragStart = ratioXY(e);
  tempRect = document.createElement("div");
  tempRect.className = "sel-rect" + ($("#boxKind").value === "diagram" ? " diagram" : $("#boxKind").value === "table" ? " table-box" : "");
  tempRect.style.left = dragStart.x * 100 + "%";
  tempRect.style.top = dragStart.y * 100 + "%";
  tempRect.style.width = "0%";
  tempRect.style.height = "0%";
  selOverlay.appendChild(tempRect);
  selOverlay.setPointerCapture(e.pointerId);
});

selOverlay.addEventListener("pointermove", (e) => {
  if (!dragStart) return;
  const cur = ratioXY(e);
  const x = Math.min(dragStart.x, cur.x);
  const y = Math.min(dragStart.y, cur.y);
  const w = Math.abs(cur.x - dragStart.x);
  const h = Math.abs(cur.y - dragStart.y);
  tempRect.style.left = x * 100 + "%";
  tempRect.style.top = y * 100 + "%";
  tempRect.style.width = w * 100 + "%";
  tempRect.style.height = h * 100 + "%";
});

function endDrag(e) {
  if (!dragStart) return;
  const cur = ratioXY(e);
  const w = Math.abs(cur.x - dragStart.x);
  const h = Math.abs(cur.y - dragStart.y);
  const n = state.currentSelectPage;
  if (tempRect) tempRect.remove();
  tempRect = null;
  if (w >= 0.02 && h >= 0.02) {
    const r = { x: Math.min(dragStart.x, cur.x), y: Math.min(dragStart.y, cur.y), w, h, kind: $("#boxKind").value };
    if (!state.selections[n]) state.selections[n] = [];
    state.selections[n].push(r);
    drawSelections(n);
    updateSelCount(n);
  }
  dragStart = null;
}
selOverlay.addEventListener("pointerup", endDrag);
selOverlay.addEventListener("pointercancel", endDrag);

$("#prevPageBtn").addEventListener("click", () => {
  if (state.currentSelectPage > 1) renderSelectPage(state.currentSelectPage - 1);
});
$("#nextPageBtn").addEventListener("click", () => {
  if (state.currentSelectPage < state.pageCount) renderSelectPage(state.currentSelectPage + 1);
});
$("#clearSelBtn").addEventListener("click", () => {
  const n = state.currentSelectPage;
  state.selections[n] = [];
  drawSelections(n);
  updateSelCount(n);
});

// Step 2 -> start processing directly
$("#generateBtn").addEventListener("click", startProcessing);

// ---------------------------------------------------------------------------
// Step 3 — Process
// ---------------------------------------------------------------------------
async function startProcessing() {
  if (state.processing) return;
  const questions = Object.values(state.selections).flat().filter((r) => !r.kind || r.kind === "text");
  if (!questions.length) { alert("Draw at least one complete-question box first."); return; }
  const start=Number($('#startNumber').value), size=Number($('#fontSize').value), font=$('#fontName').value.trim();
  if (!Number.isInteger(start) || start<1 || start+questions.length-1>9999) { alert('Enter a valid start number; the last question must not exceed 9999.'); return; }
  if (!font || font.length>80 || !Number.isFinite(size) || size<7 || size>28) { alert('Enter a font name and a size from 7 to 28 pt.'); return; }
  state.processing = true; state.reviewModel = null; state.dirty = false;
  $('#optionalReview').classList.add('hidden'); $('#reviewQuestions').replaceChildren();
  $('#cancelBtn').hidden = false; $('#cancelBtn').disabled = false; $('#cancelBtn').textContent = 'Stop conversion';
  $('#diagnosticsBtn').hidden = true; $('#elapsedTime').textContent = '';
  const errBox = $("#processError"); errBox.hidden = true;
  $("#progressWrap").classList.remove("hidden"); $("#progressBar").style.width = "0%";
  $("#progressStage").textContent = "Starting local recognition — no API key…";
  $("#backToSelection").hidden = true; showStep(3);
  try {
    const response = await fetch("/api/process", { method: "POST", cache: "no-store",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ job_id: state.jobId, pages: state.rangeText,
        output_columns: $("#outputColumns").value, selections: state.selections,
        start_number: start, font_name: font, font_size: size }) });
    const result = await response.json();
    if (!response.ok || result.status !== "started") throw new Error(result.error || "Could not start local processing.");
    pollStatus();
  } catch (err) {
    state.processing = false; $("#cancelBtn").hidden = true; errBox.textContent = err.message || "Could not start local recognition.";
    errBox.hidden = false; $("#backToSelection").hidden = false;
    $("#diagnosticsBtn").href = `/api/diagnostics/${state.jobId}`; $("#diagnosticsBtn").hidden = false;
  }
}
$('#cancelBtn').addEventListener('click', async () => {
  $('#cancelBtn').disabled = true; $('#cancelBtn').textContent = 'Stopping…';
  try { await api(`/api/cancel/${state.jobId}`, {method:'POST'}); }
  catch (err) { $('#cancelBtn').disabled = false; $('#cancelBtn').textContent = 'Stop conversion'; }
});
$('#openReviewBtn').addEventListener('click', async () => {
  const box = $('#optionalReview');
  if (!box.classList.contains('hidden')) { box.classList.add('hidden'); return; }
  const control=$('#openReviewBtn'); control.disabled=true; control.textContent='Opening editor…';
  try {
    if (!state.reviewModel) await loadReview();
    box.classList.remove('hidden'); box.scrollIntoView({behavior:'smooth', block:'start'});
  } catch(err) { alert(err.message); }
  finally { control.disabled=false; control.textContent='Check or edit (optional)'; }
});
$('#directDownloadBtn').addEventListener('click', (event) => {
  if (state.saving) { event.preventDefault(); return; }
  if (state.reviewModel && state.dirty) { event.preventDefault(); saveReview(true); }
});
function showReady(result) {
  state.processing=false;
  $('#directDownloadBtn').href=`/api/download/${state.jobId}`;
  const s=result.stats || {};
  $('#doneStats').textContent=`${s.questions || 0} questions · ${s.tables || 0} tables · ${s.equations || 0} equations · ${s.diagrams || 0} diagrams`;
  $('#doneStats').textContent += ` · numbered ${s.start_number || 1}–${s.end_number || s.questions || 1} · ${s.font_name || ''} ${s.font_size || ''} pt`;
  if (s.selection_boxes) $('#doneStats').textContent += ` · from ${s.selection_boxes} selection${s.selection_boxes===1?'':'s'}`;
  if (s.annotated_arrows) $('#doneStats').textContent += ` · ${s.annotated_arrows} labelled arrows`;
  if (result.cached_questions) $('#doneStats').textContent += ` · ${result.cached_questions} reused without recognition`;
  showStep(4);
}

function pollStatus() {
  fetch(`/api/status/${state.jobId}`)
    .then((r) => r.json())
    .then((s) => {
      if (s.status === "done") {
        state.processing = false;
        $("#progressBar").style.width = "100%";
        $("#progressStage").textContent = s.stage || "Done";
        showReady(s);
        return;
      }
      if (s.status === "error" || s.status === "cancelled") {
        state.processing = false;
        const errBox = $("#processError");
        errBox.textContent = s.status === 'cancelled' ? 'Conversion stopped. Your question selections are still available.' : 'Error: ' + (s.error || 'conversion failed');
        $('#cancelBtn').hidden=true;
        $('#diagnosticsBtn').href=`/api/diagnostics/${state.jobId}`;
        $('#diagnosticsBtn').hidden=s.status==='cancelled';
        errBox.hidden = false;
        $("#backToSelection").hidden = false;
        return;
      }
      $("#elapsedTime").textContent = `${Math.round(s.elapsed_seconds || 0)} seconds elapsed`;
      $("#progressBar").style.width = (s.progress || 0) + "%";
      $("#progressStage").textContent = s.stage || "Working…";
      state.pollTimer = setTimeout(pollStatus, 700);
    })
    .catch(() => {
      state.pollTimer = setTimeout(pollStatus, 1200);
    });
}

function renderSummary(stats) {
  if (!stats) return;
  $("#summary").replaceChildren();
  [[stats.questions || 0,"Question blocks"],[stats.tables,"Editable tables"],[stats.diagrams || 0,"Diagrams"],[stats.equations || 0,"Word equations"],[stats.words,"Words"]].forEach(([n,label]) => {
    const card = element("div", "stat");
    card.append(element("div", "num", String(n)), element("div", "lbl", label));
    $("#summary").append(card);
  });
  $("#layoutSummary").textContent = "Word layout: " + (stats.page_layouts || []).map((p) => `source page ${p.page}: ${p.columns} column${p.columns === 2 ? "s" : ""}`).join("; ") + ".";
  $("#outputWarnings").replaceChildren();
  (stats.warnings || []).forEach((message) => $("#outputWarnings").append(element("p", "", message)));
}

function element(tag, cls = "", text = null) {
  const e = document.createElement(tag);
  if (cls) e.className = cls;
  if (text !== null) e.textContent = text;
  return e;
}
function button(text, action, cls = "btn ghost small") {
  const b = element("button", cls, text); b.type = "button"; b.addEventListener("click", action); return b;
}
function changed() { state.dirty = true; $("#saveStatus").textContent = "Unsaved corrections — Save & download rebuilds the Word file with these changes."; }
async function api(url, options = {}) {
  const r = await fetch(url, options);
  const j = await r.json();
  if (!r.ok) throw new Error(j.error || "Local request failed");
  return j;
}
async function loadReview() {
  const r = await api(`/api/review/${state.jobId}`);
  state.reviewModel = r.model;
  renderSummary(r.stats); renderReview(); showStep(4);
}

let lastEditor = null;
function editor(value, setter, cls = "review-text") {
  const t = element("textarea", cls); t.value = value; t.rows = Math.min(14, Math.max(2, value.split("\n").length + 1));
  t.spellcheck = false;
  t.addEventListener("focus", () => { lastEditor = t; });
  t.addEventListener("input", () => { setter(t.value); changed(); });
  return t;
}
["CO₂","H₂O","O₂","H⁺","C₃","C₄","NADP⁺","α","β","μ","Δ","→","⇌","²","³","°","×","√"].forEach((text) => {
  const b = button(text, () => {
    if (!lastEditor || !lastEditor.isConnected) { $("#saveStatus").textContent = "Click in a text/table/equation field first, then choose a symbol."; return; }
    const start = lastEditor.selectionStart, end = lastEditor.selectionEnd;
    lastEditor.setRangeText(text, start, end, "end"); lastEditor.dispatchEvent(new Event("input")); lastEditor.focus();
  });
  b.addEventListener("mousedown", (e) => e.preventDefault()); $("#symbolTools").append(b);
});

function renderReview() {
  const model = state.reviewModel;
  $('#reviewStartNumber').value = model.start_number || 1; $('#reviewFontName').value = model.font_name || 'Times New Roman';
  $("#reviewTitle").value = model.title; $("#reviewColumns").value = model.output_columns;
  $("#reviewFontSize").value = model.font_size; $("#keepWrap").checked = model.keep_wrap;
  $("#columnSeparator").checked = model.separator; $("#preserveColumns").checked = model.preserve_source_columns !== false;
  $("#reviewQuestions").replaceChildren();
  model.questions.forEach((q, qi) => {
    const card = element("article", "question-card");
    const title = element("div", "question-title");
    title.append(element("h3", "", `Question ${(Number(model.start_number) || 1) + qi}${q.detected_source_number ? ` (source ${q.detected_source_number})` : ""} · source page ${q.page}`));
    const actions = element("div", "item-actions");
    actions.append(button("↑", () => { if (qi > 0) { [model.questions[qi-1], model.questions[qi]] = [q, model.questions[qi-1]]; changed(); renderReview(); } }),
      button("↓", () => { if (qi < model.questions.length-1) { [model.questions[qi+1], model.questions[qi]] = [q, model.questions[qi+1]]; changed(); renderReview(); } }));
    const del = button("Remove block", () => { if (model.questions.length > 1 && confirm("Remove this block from Word output?")) { model.questions.splice(qi,1); changed(); renderReview(); } });
    del.disabled = model.questions.length <= 1; actions.append(del); title.append(actions); card.append(title);
    const grid = element("div", "question-grid");
    const source = element("div", "source-pane"); source.append(element("strong", "", "Original selection — reference"));
    const im = element("img"); im.src = `/api/asset/${state.jobId}/${q.source_asset}`; im.alt = `Source of block ${qi+1}`; im.loading = "lazy";
    source.append(im, element("p", "muted", q.engine === "mineru" ? "Local MinerU recognition · verify against the original" : q.engine === "ocr" ? "Offline OCR — older result" : q.engine === "native" ? "Native PDF text extraction" : "Diagram picture"));
    grid.append(source);
    const edits = element("div", "edit-pane"); edits.append(element("strong", "", "Editable Word content"));
    (q.warnings || []).forEach((text) => edits.append(element("p", "low-confidence", text)));
    q.items.forEach((item, ii) => {
      const box = element("section", "review-item");
      const head = element("div", "item-head"); head.append(element("span", "item-type", item.type === "image" ? "Diagram picture" : item.type === "equation" ? "Native Word equation" : item.type === "table" ? "Editable table / option grid" : "Editable paragraph"));
      const tools = element("div", "item-actions");
      tools.append(button("↑", () => { if (ii > 0) { [q.items[ii-1],q.items[ii]]=[item,q.items[ii-1]]; changed(); renderReview(); } }),
        button("↓", () => { if (ii < q.items.length-1) { [q.items[ii+1],q.items[ii]]=[item,q.items[ii+1]]; changed(); renderReview(); } }),
        button("×", () => { q.items.splice(ii,1); changed(); renderReview(); }));
      head.append(tools); box.append(head);
      if (item.type === "text") {
        if (item.confidence < 65) box.append(element("p", "low-confidence", "Uncertain recognition: compare with the source before downloading."));
        box.append(editor(item.text, (v) => { item.text = v; }));
        const label = element("label", "check"); const cb = element("input"); cb.type = "checkbox"; cb.checked = !!item.bold;
        cb.addEventListener("change", () => { item.bold = cb.checked; changed(); }); label.append(cb, document.createTextNode(" Bold")); box.append(label);
        box.append(button("Make this an equation", () => { item.type = "equation"; item.latex = item.text.replace(/\n/g," "); delete item.text; changed(); renderReview(); }));
      } else if (item.type === "table") {
        const wrap = element("div", "table-edit-wrap"); const table = element("table", "table-editor");
        item.rows.forEach((row, ri) => { const tr = element("tr"); row.forEach((value, ci) => { const td = element("td"); td.append(editor(value, (v) => { item.rows[ri][ci] = v; }, "cell-editor")); tr.append(td); }); table.append(tr); });
        wrap.append(table); box.append(wrap);
        const controls = element("div", "item-actions");
        controls.append(button("+ Row", () => { if (item.rows.length < 100) { item.rows.push(item.rows[0].map(() => "")); changed(); renderReview(); } }),
          button("+ Column", () => { if (item.rows[0].length < 12) { item.rows.forEach((r) => r.push("")); item.widths = item.rows[0].map(() => 1); changed(); renderReview(); } }),
          button("− Last row", () => { if (item.rows.length > 1) { item.rows.pop(); changed(); renderReview(); } }),
          button("− Last column", () => { if (item.rows[0].length > 1) { item.rows.forEach((r) => r.pop()); item.widths = item.rows[0].map(() => 1); changed(); renderReview(); } }),
          button("Convert to text", () => { item.type = "text"; item.text = item.rows.map((r) => r.join("    ")).join("\n"); delete item.rows; changed(); renderReview(); }));
        const label = element("label", "check"); const cb = element("input"); cb.type = "checkbox"; cb.checked = !!item.border;
        cb.addEventListener("change", () => { item.border = cb.checked; changed(); }); label.append(cb, document.createTextNode(" Borders")); controls.append(label); box.append(controls);
      } else if (item.type === "image") {
        const pic = element("img", "diagram-preview"); pic.src = `/api/asset/${state.jobId}/${item.asset}`; pic.alt = "Retained diagram"; box.append(pic);
        box.append(element("small", "muted", "Only this diagram is an image; surrounding question text remains editable."));
      } else if (item.type === "equation") {
        box.append(element("small", "muted", "LaTeX → native editable Word equation, fully offline. Example: \\frac{a+b}{c} or E=mc^2"));
        const preview = element("div", "equation-preview"); let timer;
        const update = () => {
          clearTimeout(timer); timer = setTimeout(async () => {
            try { const r = await api("/api/equation-preview", { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify({latex:item.latex}) }); preview.innerHTML = r.mathml; }
            catch (err) { preview.textContent = err.message; }
          }, 300);
        };
        box.append(editor(item.latex, (v) => { item.latex = v; update(); }, "latex-editor"), preview);
        box.append(button("Make this ordinary text", () => { item.type = "text"; item.text = item.latex; delete item.latex; changed(); renderReview(); }));
        update();
      }
      edits.append(box);
    });
    const add = element("div", "add-elements");
    add.append(button("+ Paragraph", () => { q.items.push({type:"text",text:"",indent:0,confidence:100}); changed(); renderReview(); }),
      button("+ Table", () => { q.items.push({type:"table",rows:[["",""],["",""]],widths:[1,1],border:false,indent:17}); changed(); renderReview(); }),
      button("+ Equation", () => { q.items.push({type:"equation",latex:"\\frac{a+b}{c}",indent:17}); changed(); renderReview(); }));
    edits.append(add); grid.append(edits); card.append(grid); $("#reviewQuestions").append(card);
  });
}

["reviewTitle","reviewColumns","reviewFontSize","reviewStartNumber","reviewFontName","keepWrap","columnSeparator","preserveColumns"].forEach((id) => $("#"+id).addEventListener("input", () => {
  const m = state.reviewModel; if (!m) return;
  m.start_number = Number($('#reviewStartNumber').value); m.font_name = $('#reviewFontName').value.trim();
  m.title = $("#reviewTitle").value; m.output_columns = $("#reviewColumns").value; m.font_size = Number($("#reviewFontSize").value);
  m.keep_wrap = $("#keepWrap").checked; m.separator = $("#columnSeparator").checked; m.preserve_source_columns = $("#preserveColumns").checked;
  if (Number.isInteger(m.start_number)) {
    $$('#reviewQuestions .question-title h3').forEach((heading, index) => {
      heading.textContent = `Question ${m.start_number+index}${m.questions[index].detected_source_number ? ` (source ${m.questions[index].detected_source_number})` : ""} · source page ${m.questions[index].page}`;
    });
  }
  changed();
}));
async function saveReview(download = false) {
  const model = state.reviewModel; if (!model || state.saving) return;
  state.saving = true; $("#reviewQuestions").inert = true; $(".review-config").inert = true; $("#symbolTools").inert = true;
  model.start_number = Number($('#reviewStartNumber').value); model.font_name = $('#reviewFontName').value.trim();
  model.title = $("#reviewTitle").value; model.output_columns = $("#reviewColumns").value;
  model.font_size = Number($("#reviewFontSize").value); model.keep_wrap = $("#keepWrap").checked; model.separator = $("#columnSeparator").checked; model.preserve_source_columns = $("#preserveColumns").checked;
  $("#reviewError").hidden = true; $("#saveStatus").textContent = "Rebuilding Word locally…";
  $("#downloadBtn").disabled = $("#saveReviewBtn").disabled = true;
  try {
    const r = await api(`/api/review/${state.jobId}`, { method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(model) });
    $('#startNumber').value = r.model.start_number; $('#fontName').value = r.model.font_name; $('#fontSize').value = r.model.font_size;
    showReady({stats:r.stats}); $('#optionalReview').classList.remove('hidden');
    state.reviewModel = r.model; state.dirty = false; renderSummary(r.stats); renderReview();
    $("#saveStatus").textContent = "Saved. The Word file includes your latest corrections.";
    if (download) window.location.href = `/api/download/${state.jobId}?v=${Date.now()}`;
  } catch (err) { $("#reviewError").textContent = err.message; $("#reviewError").hidden = false; $("#saveStatus").textContent = "Not saved — correct the error and try again."; }
  finally { state.saving = false; $("#reviewQuestions").inert = false; $(".review-config").inert = false; $("#symbolTools").inert = false; $("#downloadBtn").disabled = $("#saveReviewBtn").disabled = false; }
}
$("#downloadBtn").addEventListener("click", () => saveReview(true));
$("#saveReviewBtn").addEventListener("click", () => saveReview(false));
$("#backToSelection").addEventListener("click", () => showStep(2));
$("#editSelectionsBtn").addEventListener("click", () => { if (confirm("Reprocessing uses the local CPU engine again and replaces review edits. Continue?")) showStep(2); });
$("#restartBtn").addEventListener("click", () => {
  if (!confirm("Start a new document? Download your Word file first if needed.")) return;
  if (state.pollTimer) clearTimeout(state.pollTimer);
  state.dirty = false; $("#optionalReview").classList.add("hidden");
  state.jobId = null; state.reviewModel = null; state.pages = []; state.selections = {}; state.rangeText = "";
  $('#startNumber').value = '1'; $('#fontName').value = 'Times New Roman'; $('#fontSize').value = '11';
  fileInput.value = ""; $("#outputColumns").value = "auto"; $("#boxKind").value = "text";
  $("#processError").hidden = true;
  $(".dz-inner").replaceChildren(element("div","dz-icon","⬆"),element("strong","","Drop a PDF here"),element("small","","or click to browse"));
  showStep(1);
});
