"""Small standard-library launcher. No dependency scans, installs or OCR imports."""
import json
import os
import socket
import signal
import subprocess
import sys
import time
import urllib.request
import webbrowser
from pathlib import Path

BASE = Path(__file__).resolve().parent


def main():
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    raw=os.environ.get('PAPER2WORD_PORT','5000')
    if not raw.isdigit() or not 1024<=int(raw)<=65535:
        print('Invalid local port. Remove PAPER2WORD_PORT or use a number from 1024 to 65535.')
        return 1
    port=int(raw);url=f'http://127.0.0.1:{port}'
    browser='--no-browser' not in sys.argv
    # Bypass system HTTP proxies for the loopback readiness check.
    opener=urllib.request.build_opener(urllib.request.ProxyHandler({}))
    def is_ready():
        try:
            with opener.open(url+'/api/health',timeout=.4) as response:
                body=json.load(response)
            return body.get('app')=='paper2word' and body.get('version')=='6.4'
        except Exception:return False
    if is_ready():
        print('Paper2Word 6.4 is already open:',url,flush=True)
        if browser:webbrowser.open(url)
        return 0
    try:
        probe=socket.create_connection(('127.0.0.1',port),timeout=.3)
    except OSError:pass
    else:
        probe.close()
        print('Another app or an older Paper2Word is using port',port)
        print('Stop its console with Ctrl+C, then start this version again.')
        return 1
    env=os.environ.copy();env['PYTHONUNBUFFERED']='1'
    env.setdefault('MINERU_HOME',str(BASE/'model_data'))
    print('Opening Paper2Word 6.4. Keep this window open. Ctrl+C stops the app.',flush=True)
    options={'cwd':str(BASE),'env':env}
    if os.name=='nt':options['creationflags']=subprocess.CREATE_NEW_PROCESS_GROUP
    else:options['start_new_session']=True
    process=subprocess.Popen([sys.executable,str(BASE/'app.py')],**options)
    try:
        deadline=time.monotonic()+20
        while time.monotonic()<deadline:
            if process.poll() is not None:
                print('The app could not start. Run SETUP_LOCAL_WINDOWS.bat once, then try again.')
                return 1
            if is_ready():
                print('READY:',url,flush=True)
                if browser:webbrowser.open(url)
                break
            time.sleep(.1)
        else:
            print('Opening is taking longer than expected. Keep this window open and visit',url,flush=True)
        return process.wait()
    except KeyboardInterrupt:
        print('\nStopping Paper2Word…',flush=True)
        return 0
    finally:
        if process.poll() is None:
            if os.name=='nt':
                subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL)
            else:
                process.terminate()
            try:process.wait(timeout=5)
            except subprocess.TimeoutExpired:process.kill();process.wait()


if __name__=='__main__':
    raise SystemExit(main())
