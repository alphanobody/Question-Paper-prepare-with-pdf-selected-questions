@echo off
setlocal
cd /d "%~dp0"
title Paper2Word 6.4 - Local engine setup
echo PAPER2WORD 6.4 - LOCAL CPU ENGINE SETUP
echo No Google key. No cloud recognition.
echo Internet is needed NOW to install packages and download about 0.8 GB of models.
echo Allow several GB of disk space for Python libraries and models.
echo Close browsers and other large applications on an 8 GB computer.
echo.
set "MINERU_HOME=%~dp0model_data"
set "MINERU_TELEMETRY_DISABLED=1"
set "HF_HUB_DISABLE_TELEMETRY=1"
set "MINERU_MODEL_SMALL_BACKEND=onnx"
set "MINERU_MODEL_ONNX_DEVICE=cpu"
set "HF_HUB_OFFLINE="
set "TRANSFORMERS_OFFLINE="
if exist "venv_local\Scripts\python.exe" goto :check_python
py -3.12 -c "import struct; assert struct.calcsize('P') == 8" >nul 2>&1
if not errorlevel 1 (
    set "PY_LAUNCH=py -3.12"
    goto :create_venv
)
py -3.13 -c "import struct; assert struct.calcsize('P') == 8" >nul 2>&1
if not errorlevel 1 (
    set "PY_LAUNCH=py -3.13"
    goto :create_venv
)
py -3.11 -c "import struct; assert struct.calcsize('P') == 8" >nul 2>&1
if not errorlevel 1 (
    set "PY_LAUNCH=py -3.11"
    goto :create_venv
)
py -3.14 -c "import struct; assert struct.calcsize('P') == 8" >nul 2>&1
if not errorlevel 1 (
    set "PY_LAUNCH=py -3.14"
    goto :create_venv
)
python -c "import sys,struct; assert (3,11) <= sys.version_info[:2] < (3,15) and struct.calcsize('P') == 8" >nul 2>&1
if errorlevel 1 goto :need_python
set "PY_LAUNCH=python"
:create_venv
echo Creating venv_local. Existing model_data is reused when available.
%PY_LAUNCH% -m venv venv_local
if errorlevel 1 goto :failed
:check_python
"venv_local\Scripts\python.exe" -c "import sys,struct; assert (3,11) <= sys.version_info[:2] < (3,15) and struct.calcsize('P') == 8" >nul 2>&1
if errorlevel 1 goto :need_python
"venv_local\Scripts\python.exe" -m pip install --upgrade pip
if errorlevel 1 goto :failed
"venv_local\Scripts\python.exe" -m pip install -r requirements.txt
if errorlevel 1 goto :failed
"venv_local\Scripts\python.exe" -m pip install -r requirements_engine.txt
if errorlevel 1 goto :failed
"venv_local\Scripts\mineru-kit.exe" models download --tier basic --small-backend onnx --source huggingface
if errorlevel 1 goto :models_failed
"venv_local\Scripts\mineru-kit.exe" models verify --tier basic --small-backend onnx
if errorlevel 1 goto :failed
"venv_local\Scripts\python.exe" -c "from engine_state import engine_status; assert engine_status()['ready'], engine_status()['message']"
if errorlevel 1 goto :failed
echo.
echo SETUP COMPLETE. Double-click START_WINDOWS.bat.
echo Processing can now run without internet or an API key.
exit /b 0
:models_failed
echo.
echo The model download failed. Check your internet connection and retry setup.
echo No PDF was uploaded. No API key is needed for these public model downloads.
goto :failed
:need_python
echo.
echo Install 64-bit Python 3.12 from https://www.python.org/downloads/windows/
echo Enable the Python launcher during installation, then run this setup again.
echo Python 3.11 to 3.14 is required; Python 3.12 is recommended.
echo If venv_local was created with an unsupported Python, remove only venv_local.
pause
exit /b 1
:failed
echo.
echo Setup did not complete. Copy the error text above, not just the last line.
echo Do not enter any API key. This is a local-only engine.
pause
exit /b 1
