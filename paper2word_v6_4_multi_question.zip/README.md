# Paper2Word 6.4 — aligned Word and automatic question numbering

**Open PDF → select questions → choose columns, start number, font and size → Convert → Download Word.**

Local/no API. The working question selection and lazy page loading from v6 are
retained. This update changes Word formatting and numbering, not the OCR engine.

## v6.4: several questions in one selection

One green box can now include several consecutive complete questions. Include
all their printed main question numbers, full text, options and diagrams.
For example, source **4., 5., 6.** inside one box are separated into three actual
question records, each with its own question preview and Word number. If Start
number is 21, the exported numbers are 21, 22, 23. Subsequent selections continue
that numbering normally.

The app detects printed main-question headings during conversion. For text-layer
PDFs it can use native text; for outlined/scanned selections it performs a small
local OCR-only number-detection pass. It then recognizes each detected question
separately and serially, retaining the low-memory CPU profile. No new model
family or API is required. Both the discovery result and per-question recognition
are cached within the job. This can add some conversion time; it does not load
OCR or pre-render all pages at app opening.

Selection labels now say **selections**, not an assumed question count. Completion
shows the actual number of questions and how many selection boxes produced them.
Optional review shows detected original source numbers where available.

Detection targets clear dotted main headings such as `4.`, `5.`, `6.` and explicit
`Q4`/`Question 4` forms. Parenthesized choices `(1)`, `(a)` and `a)` are not main
headings. Indented numbered steps are excluded by the main-heading margin rule.
Clear source columns are processed in PDF reading order, not click order.

**Limits:** unreadable/missing/nonstandard question numbers, same-margin numbered
substeps, incomplete questions or ambiguous wide boxes can prevent a correct
split. The app keeps an unclear selection together rather than guessing or
losing content; check the final detected count. Include the printed numbers and
use separate boxes per column for an ambiguous layout. This is not a guarantee
of perfect splitting on arbitrary PDF formatting, or of perfect OCR content.
It does not automatically join one question's continuation across different pages.

New file **question_split.py** must be copied with the whole update. Keep your
existing venv_local/model_data; no new model download is required.

## Retained v6.3: final answer choices on new lines

- A standard final four-choice group that OCR has joined to the question is split
  from the stem. Each text answer is a separate Word paragraph, starting on its
  own line. Existing answer tables/grids stay tables/grids below the question.
- Final answer labels `(a), (b), (c), (d)` or `a), b), c), d)` are exported as
  `(1), (2), (3), (4)`. Already numeric choices keep their numeric values.
- This is NOT a global replacement. Earlier statement labels, reaction labels,
  matching-column labels, formulas, question content and answer wording are not
  rewritten by this rule. Q24's `(a), (b), (c), (b), (e)` reaction labels remain.
- The existing main-question Start number feature is independent and unchanged.

Detection is conservative: it requires a complete final four-choice group with
answer text. Incomplete/ambiguous groups, references to (a)/(b) in prose, labels
inside math markup and ambiguous matching-table columns are left unchanged rather
than guessed. If an unusual paper is not detected, share that PDF/Word example;
no universal semantic distinction between identical labels is promised.

See **examples/Choices_format_demo.docx** for a constructed layout example
(not an OCR benchmark). New file **answer_choices.py** must be copied with the rest of the update. No new
engine/model download is required. The change runs during Word export and review
save, not at app opening. Existing OCR errors are not corrected by this feature.

## Retained v6.2: source labels and reaction arrows

A detected answer grid previously could replace the entire recognized question,
flattening other lines' equations. The fallback now works only on the non-math
regions; reaction/equation rows are protected.

For outlined-text PDFs, a conservative source-shape matcher can recover literal
reaction text, labels and scripts using glyph outlines from the selected crop,
labelled by local OCR. It does not impose a logical a/b/c/d/e sequence or silently
correct apparent source typos. Source `(a), (b), (c), (b), (e)` stays that way.
The main question number is still the only number changed by Start number.

Recovered annotated arrows use **editable Word ruby text** (an arrow base and a
small text annotation above it), not screenshots. They are not OMML equation
objects. Other supported equations still use native Word math. Use optional app
review to edit the recovered arrow notation as LaTeX without rerunning OCR;
Word exposes the annotation through its Phonetic Guide feature, where available.
Ruby labels have their own smaller size, as the source does.

The outline matcher is deliberately limited. Raster scans or unmatched/ambiguous
shapes retain the normal OCR/math path and require checking. There is no claim
that arbitrary OCR output or every source label is now infallible.

Open **examples/Q24_editable.docx** and **Q24_preview.pdf** to check the actual
new output on the supplied question. The example was generated by real local
inference and the source-shape matcher, not a manual transcription. It uses
Roboto Condensed 11 pt and starts at 24. Text, scripts, arrows and answer cells
are editable; no question image is used. Font metrics, arrow width, line spacing
and pagination can still differ from the PDF. **Pixel-identical layout has not
been achieved or certified.**

## Controls before conversion

- **Start question number**: enter 21 and four selected questions become
  **21, 22, 23, 24**, even if the source questions are 1, 4, 5, 9. Range 1–9999;
  the final question must also be at most 9999.
- **Order**: PDF reading order — pages ascending, left column top to bottom,
  then right column top to bottom. It is not the order you draw the boxes.
- **Word font**: select a suggestion or type any font installed on your PC.
  Default: Times New Roman. Unavailable fonts will be substituted by Word.
- **Font size**: 7–28 pt; default 11 pt. Text is no longer shrunk separately
  according to each selection box's width. Other supported equations remain native Word math;
  Word may use its specialist math font for mathematical glyphs.
- **Word columns**: Auto, Single column or Double column, as before.

These controls are applied during the first export. You do not need to renumber
or reformat every question after downloading.

## Alignment changes

Question numbers are **real Word automatic numbering**, not typed numbers with
spaces. A hanging indent aligns a wrapped question with its text rather than
under its number. Question body text has a consistent indent; standalone options
have hanging indents and tab stops. Tables use real column widths, not spaces.
Where cell width permits, option labels within tables also have hanging indents.
Very narrow cells wrap normally rather than using an indent wider than the cell.

Text uses named Word paragraph styles based on **Normal**, without per-run font
or size overrides on ordinary body text (small arrow annotations are an exception). This makes later font/size changes much more consistent.
Source hard line breaks are reflowed by default, including inside table cells.
Source-column breaks and whole-question keep-together chains no longer force
questions to jump or leave large avoidable blank areas. Short tables are kept
together where practical; long content may still split naturally.

**Changing font/size must change wrapping, page count and sometimes column
breaks.** It cannot preserve the same physical line positions at every size.
This update maintains structural indentation and editable layout; it does not
promise pixel-identical PDF typography or no blank space at any page break.
If a diagram/table cannot fit in the remaining space, Word must move it.

## After downloading: editing in Word

- To change the starting number: **right-click a question number → Set Numbering
  Value**. Do not replace a number by typing over it as ordinary text. Word can
  update subsequent numbers as a real list.
- To change the font/size throughout the question text: modify the **Normal**
  style in Word's Styles panel, or select the desired text and change its font.
  The question/body/option styles inherit Normal. Mathematical fonts may differ.
- Do not align text using repeated spaces. Preserve the hanging indents and tab
  stops. To change indentation deliberately, modify the relevant P2W style.
- This is an ordinary editable DOCX, not positioned full-question screenshots.

## Optional correction inside the app

Download is available immediately; review is optional. **Check or edit** also
contains start number, font and size fields. Changing these and saving rebuilds
the Word file locally **without running OCR again**. Question labels update to
show the chosen numbers. The original source number is removed from the first
recognized question text; do not add it again manually. Only question numbers
are changed, not option numbers or matching-table entries.

Changing selected boxes/reprocessing replaces optional text corrections. Download
those edits first. Unchanged selection boxes in the same job reuse recognition.

## Update an existing Windows installation

1. In the old app's console, press **Ctrl+C**. Back up your folder.
2. Extract **all** files from this ZIP. Copy them into
   `F:\test\paper2word_app`, replacing app files. Include the new
   `aligned_word.py`, `word_options.py`, `source_outline.py` `answer_choices.py` and new `question_split.py` files.
3. **Keep existing `venv_local` and `model_data` folders. Do not delete them.**
4. Run **START_WINDOWS.bat**. Confirm the heading says **6.4 · MULTI QUESTION**.
   If the browser displays an old page, press Ctrl+F5.

No new recognition engine/model download is required for this update. Normal
starting never runs pip or downloads models. Only if the environment is missing
or incomplete, run SETUP_LOCAL_WINDOWS.bat once, then start again.

### PowerShell 5.1: run each line separately

```powershell
Set-Location -LiteralPath 'F:\test\paper2word_app'
& '.\START_WINDOWS.bat'
```

Only if setup is needed:

```powershell
Set-Location -LiteralPath 'F:\test\paper2word_app'
& '.\SETUP_LOCAL_WINDOWS.bat'
& '.\START_WINDOWS.bat'
```

## First installation

Extract the entire ZIP into a normal folder. Install 64-bit Python 3.12 with the
Python launcher (3.11–3.14 supported). Run SETUP_LOCAL_WINDOWS.bat once with
internet to install libraries and approximately 0.8 GB of model weights, plus
software downloads; allow several GB of disk space. Then run START_WINDOWS.bat.
No API key/account/NVIDIA GPU is required. On low-RAM PCs close other large apps
and select a few complete questions at a time. Not certified for every RAM size.

## Selection and local data

One green box may contain one or several consecutive complete numbered questions, including their options and figures.
Prev/Next preserves selections. Optional diagram/table hints remain inside a
collapsed control; there is no separate crop/header/footer/page-range screen.
Up to 120 pages/100 MB per upload. Only visited page pictures are rendered.

Keep the console open while working; Ctrl+C stops it. Download before stopping;
job navigation does not survive a server restart. PDFs, recognition data and
outputs remain locally in **jobs**. To remove them, stop the app and delete jobs.
Keep **model_data** to avoid downloading model weights again.

## Failures, accuracy and privacy

After a processing error use **Save error details**. Inspect its ZIP before
sharing: logs may contain local paths/document-related messages. It excludes
source PDFs, images and recognition JSON. Share an incorrect DOCX and screenshot
of the desired alignment for a specific formatting issue.

OCR can still misread symbols, words, table cells and option labels. This update
fixes structural formatting/numbering and demonstrated reaction losses, **not all recognition accuracy errors**.
Exact source-identical Word output is not guaranteed. Diagrams remain image
crops; recognized text/tables/supported equations are editable.

The app binds to loopback 127.0.0.1, not the LAN. The worker uses offline CPU ONNX
models, disables telemetry and rejects non-loopback Python socket connections.
This application guard is not an OS firewall/native-library networking audit.
There is no recognition API or cloud fallback. Internet is required for setup,
not intended for normal conversion after setup.

See **VALIDATION.md** for tests and limitations. See **THIRD_PARTY_NOTICES.txt**,
**licenses/** and **fonts/OFL.txt** for software/model/font licensing, including
MinerU's additional attribution/commercial terms. Only Roboto Condensed is bundled;
other selected fonts must be installed/licensed separately on your computer.
