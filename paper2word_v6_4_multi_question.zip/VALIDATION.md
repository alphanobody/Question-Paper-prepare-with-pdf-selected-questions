# v6.4 — multiple questions in one continuous selection

## Fresh real-PDF integration test passed

Source: user-supplied `CH-13. Photosynthesis in Higher Plants-MR-BIO 87 Q.pdf`,
outlined Biology questions without a usable native text layer.

- ONE right-column selection on page 1 containing printed Q5, Q6 and Q7.
- Local OCR-only heading probe detected source numbers **5, 6, 7**.
- Three separate recognition crops, question model records and source previews.
- DOCX XML contained **three main-question numbered paragraphs**, not one.
- Start number **21** produced the three-question range **21–23**.
- Completion stats: **3 questions from 1 selection**.
- First run including heading discovery and recognition: **28.90 seconds** here.
- Re-run with Arial 12, one output column and start number 41 reused all three
  question caches and the heading probe; **2.63 seconds** here.
- Figures are source crops; no whole-question screenshot fallback added.

These are Linux sandbox timings, not promises for the user's Windows CPU.
This test validates question separation and DOCX structure; it does not establish
perfect OCR wording, formula accuracy, visual equivalence or desktop Word layout.

## Additional tests passed

- Constructed printed 4./5./6. headings split into three boundaries.
- Native-text PDF with 4./5./6. splits without an OCR probe.
- Parenthesized choices, decimal values and indented numbered steps excluded.
- Two-column reading order and conservative ambiguous-wide-box fallback.
- Retained choice-only normalization/body preservation and actual saved Q24
  duplicate-label/arrow tests.
- Five font/size/column configurations, automatic numbering/start override,
  tables/equations, review settings and hanging-alignment structure regressions.
- Lazy opening, missing-engine errors, worker cancellation/termination tests.
- Python compile, JavaScript syntax and clean-extraction archive checks.

## Scope and limits

Main-heading detection is a conservative geometric heuristic, not a universal
semantic classifier. Missing/illegible numbers, nonstandard headings or numbered
substeps aligned exactly like main headings may still need separate boxes.
Ambiguous selections are kept together with a warning rather than discarded.
Check detected count and review output. No Windows 8 GB or interactive Microsoft
Word benchmark was performed. Pixel-identical output is not claimed.

The same local CPU engine and model files are used. The new heading pass runs
only during conversion; startup still avoids heavy recognition imports.

---
# Retained v6.3 validation record (historical)

# v6.3 — answer-choice paragraph and label checks

## New behavior

A detected standard final four-answer group is handled separately from the
question body. Inline text choices are split into four Word paragraphs after
the stem. Existing answer tables remain tables below the stem. Final answer
labels (a)/(b)/(c)/(d) and a)/b)/c)/d) map to (1)/(2)/(3)/(4).

The rule is not a global replacement. Earlier statement/reaction labels,
matching labels, formulas and answer wording are not rewritten. Main-question
Start number remains an independent feature, unchanged from v6.1.

## Tests passed

- Inline (a)-(d), a)-d), and numeric (1)-(4) choices separated from the stem.
- Word document XML confirms one stem paragraph followed by four distinct
  answer paragraphs. It is not just visually inserted spaces or soft wrapping.
- Statement labels (a)-(d) in the question stay unchanged when the final
  answer-choice group follows them.
- Formula markup and prose references are not treated as choice labels.
- Incomplete groups, statement-only instructions and ambiguous letter-labelled
  matching-table columns are left unchanged.
- A four-cell table ordered a,c / b,d becomes 1,3 / 2,4 without reordering cells.
- Running normalization twice gives the same result (no duplicate/split drift).
- Actual saved Q24 recognition/source-outline model: all five reaction items
  remain unchanged, including labels a,b,c,b,e and their subscript/arrow data.
  DOCX export still contains eight editable arrow annotations.
- Optional review/font-size change preserves the numeric answer choices.
- Previous export tests pass for five font/size/column/numbering combinations,
  ordinary native equations, real tables and question-prefix edge cases.
- Startup, route validation, error diagnostics, cancellation, native equation and
  heavy-import-free opening regression tests pass. Python compile and JS syntax
  checks pass. Archive packaging verifies CRC and fresh-extraction imports/UI.

## Evidence limits

This update changes export/post-processing, not the recognition worker. Tests
use constructed formatting fixtures and genuine saved local OCR/source-outline
results. No fresh OCR inference or interactive Microsoft Word rendering benchmark
was performed for v6.3. Tests ran on Linux, not the user's Windows hardware.
The new Choices_format_demo.docx is explicitly a constructed layout demonstration.
The retained Q24 DOCX/PDF pair is the actual v6.2 source-label example, unchanged.

Detection is deliberately conservative and structural, not an infallible semantic
classifier. The same a/b/c/d notation can mean statements, subparts, references,
matching labels or answers. Unclear/incomplete groups or labels wholly inside
math markup may be left unchanged rather than guessed. If a particular layout is
not detected, its PDF/Word example is needed for a targeted test. There is no
universal guarantee that arbitrary OCR can always identify MCQ boundaries.

Existing OCR and PDF-vs-Word typography/spacing limits remain. The v6.2 source
reaction path is retained, including its editable ruby arrow annotations; those
arrows are editable text annotations, not OMML equation objects. Other supported
math remains native Word equations. No question screenshot fallback is added.
The earlier hardware/memory limitations still apply. No new models/dependencies
or recognition services are introduced by this export-only update.
