"""Separate and relabel a standard FINAL four-answer block, not the stem.

No global a/b/c/d replacement: earlier statement labels, reaction labels,
matching-column labels, math and ordinary mentions remain untouched. Ambiguous
or incomplete groups are left unchanged rather than guessed.
"""
import copy
import re

# A marker must begin at a whitespace/token boundary, not inside f(a).
MARKER=re.compile(r'(?<!\S)(?:\(([a-dA-D1-4])\)|([a-dA-D1-4])\))')
MATH=re.compile(r'\\\(.*?\\\)|\\\[.*?\\\]|<[^>]*>',re.S)


def _markers(text):
    masked=list(text)
    for m in MATH.finditer(text):masked[m.start():m.end()]=' '*len(m.group())
    return list(MARKER.finditer(''.join(masked)))


def _label(match):return (match[1] or match[2]).lower()


def _has_content(text):
    # A comma/conjunction between references '(a), (b), (c) and (d)' is not
    # the content of an answer choice.
    value=re.sub(r'[^\w]+',' ',text).strip().lower()
    return bool(value) and value not in ('and','or','and or')


def normalize_answer_choices(model):
    changed=0
    for q in model.get('questions',[]):
        changed+=_normalize_question(q)
    return changed


def _normalize_question(q):
    items=_simple_choice_grids(_table_tail_choices(q.get('items',[])));records=[];pieces=[];offset=0
    for index,item in enumerate(items):
        if item.get('type')=='text':
            value=item.get('text','');records.append(dict(item=index,cell=None,start=offset,end=offset+len(value),text=value))
            pieces.append(value+'\n');offset+=len(value)+1
        elif item.get('type')=='table':
            for ri,row in enumerate(item.get('rows',[])):
                for ci,value in enumerate(row):
                    records.append(dict(item=index,cell=(ri,ci),start=offset,end=offset+len(value),text=value))
                    pieces.append(value+'\n');offset+=len(value)+1
        else:
            # Keep math/assets in the body, never search their notation for labels.
            pieces.append('\n');offset+=1
    text=''.join(pieces);matches=_markers(text)
    if len(matches)<4:return 0
    selected=matches[-4:];labels=[_label(m) for m in selected]
    if labels not in (list('abcd'),list('1234')):
        # A four-cell table can be ordered down its columns: a,c / b,d.
        if set(labels) not in (set('abcd'),set('1234')):return 0
        owners=[next((r for r in records if r['start']<=m.start()<r['end']),None) for m in selected]
        if not all(owners) or any(r['cell'] is None for r in owners) or len({r['item'] for r in owners})!=1:return 0
        if any(r['text'][:m.start()-r['start']].strip() for r,m in zip(owners,selected)):return 0
    # A letter-labelled matching-table column is part of the question, not
    # automatically an answer set. Leave that ambiguous structure unchanged.
    if set(labels)==set('abcd'):
        owners=[next((r for r in records if r['start']<=m.start()<r['end']),None) for m in selected]
        if all(owners) and all(r['cell'] is not None for r in owners) and len({r['item'] for r in owners})==1:
            if len({r['cell'][1] for r in owners})==1:
                table=items[owners[0]['item']];col=owners[0]['cell'][1]
                if any(any(str(v).strip() for ci,v in enumerate(row) if ci!=col) for row in table['rows']):return 0
    # A selected question must have a stem before the answer block.
    prefix=text[:selected[0].start()]
    if not re.search(r'[A-Za-z\u0080-\uffff]',prefix):return 0
    # Four statement labels alone after an unfinished statement instruction
    # are not enough evidence of answer choices.
    if labels==list('abcd'):
        tail=prefix.strip().lower()
        if re.search(r'\b(?:read|consider|study)\b[^?]*\b(?:statements|steps|processes|reactions)\s*[:–-]?$',tail) and not re.search(r'\b(?:which|select|choose|correct|incorrect|true|false)\b',tail):
            return 0
    for n,m in enumerate(selected):
        end=selected[n+1].start() if n<3 else len(text)
        if not _has_content(text[m.end():end]):return 0
    locations={}
    for m in selected:
        rec=next((r for r in records if r['start']<=m.start()<r['end']),None)
        if rec is None:return 0
        # Avoid pulling a stem out of the middle of an existing complex table.
        if rec['cell'] is not None and rec['text'][:m.start()-rec['start']].strip():return 0
        key=(rec['item'],rec['cell'])
        label=_label(m);number='abcd'.index(label)+1 if label.isalpha() else int(label)
        locations.setdefault(key,[]).append((m.start()-rec['start'],m.end()-rec['start'],number))
    output=[]
    for index,item in enumerate(items):
        if item.get('type')=='text' and (index,None) in locations:
            spans=locations[(index,None)];value=item['text'];head=value[:spans[0][0]]
            if head.strip():
                # Preserve the stem verbatim; only its paragraph boundary changes.
                before=copy.deepcopy(item);before['text']=head.rstrip();output.append(before)
            for n,(start,end,number) in enumerate(spans):
                stop=spans[n+1][0] if n+1<len(spans) else len(value)
                choice=copy.deepcopy(item)
                choice.update(type='text',text=f'({number}) '+value[end:stop].strip(),answer_choice=True,choice_number=number)
                # Splitting a flattened source paragraph does not make every
                # extracted answer a source-outline-matched reaction line.
                if len(spans)>1 or head.strip():
                    choice.pop('outline_matched',None);choice.pop('source_arrow_labels',None)
                output.append(choice)
        elif item.get('type')=='table' and any(key[0]==index for key in locations):
            table=copy.deepcopy(item);answer_cells=[]
            for (item_index,cell),spans in locations.items():
                if item_index!=index:continue
                ri,ci=cell;value=table['rows'][ri][ci]
                for start,end,number in sorted(spans,reverse=True):value=value[:start]+f'({number}) '+value[end:].lstrip()
                table['rows'][ri][ci]=value;answer_cells.append([ri,ci])
            table['answer_choice_cells']=answer_cells
            populated={(ri,ci) for ri,row in enumerate(table['rows']) for ci,c in enumerate(row) if c.strip()}
            # A complete answer set can be split across text paragraphs AND
            # a two-cell final row. Flatten just those whole-answer cells;
            # do not preserve a stray (3)/(4) mini-grid after (1)/(2) text.
            if populated=={tuple(c) for c in answer_cells} and all(len(_markers(table['rows'][ri][ci]))==1 for ri,ci in populated):
                choices=[]
                for ri,ci in populated:
                    value=table['rows'][ri][ci];marker=_markers(value)[0]
                    number=int(_label(marker))
                    choices.append(dict(type='text',text=value,answer_choice=True,choice_number=number,indent=0,confidence=100))
                output.extend(sorted(choices,key=lambda c:c['choice_number']))
            else:output.append(table)
        else:output.append(item)
    q['items']=output
    q['answer_choices_detected']=True
    return 1


def _table_tail_choices(items):
    """Separate four final answers accidentally absorbed into a matching table.

    Require a preceding uppercase-labelled matching grid and a complete,
    ordered suffix. Ordinary answer grids and reaction/statement rows remain
    untouched. No global label replacement or inferred missing choices.
    """
    if not items or items[-1].get('type')!='table':return items
    table=items[-1];rows=table.get('rows',[])
    for start in range(1,len(rows)):
        body=rows[:start]
        labelled=sum(bool(row and re.match(r'^\s*\([A-H]\)\s*',str(row[0]))) for row in body)
        if labelled<2:continue
        tail='\n'.join(str(cell).strip() for row in rows[start:] for cell in row if str(cell).strip())
        markers=_markers(tail)
        if len(markers)!=4 or tail[:markers[0].start()].strip():continue
        labels=[_label(m) for m in markers]
        if labels not in (list('1234'),list('abcd')):continue
        choices=[]
        for index,marker in enumerate(markers):
            end=markers[index+1].start() if index<3 else len(tail)
            value=tail[marker.end():end].strip()
            if not _has_content(value):break
            choices.append(dict(type='text',text=f'({index+1}) '+value,indent=0,
                                confidence=100,answer_choice=True,choice_number=index+1))
        if len(choices)==4:
            kept=copy.deepcopy(table);kept['rows']=copy.deepcopy(body)
            kept.pop('answer_choice_cells',None)
            return items[:-1]+[kept]+choices
    return items


def _simple_choice_grids(items):
    """Four whole-answer cells become four paragraphs; code/matching grids don't.

    Require exactly four nonempty cells, one complete marker at each cell start,
    and the complete 1-4/a-d set. Headered tables or multi-value code grids are
    never flattened. Mathematical content inside each answer is retained.
    """
    output=[]
    for item in items:
        if item.get('type')!='table':output.append(item);continue
        values=[c.strip() for row in item['rows'] for c in row if c.strip()]
        markers=[_markers(c) for c in values]
        if len(values)!=4 or any(len(m)!=1 or m[0].start()!=0 for m in markers):
            output.append(item);continue
        labels=[_label(m[0]) for m in markers]
        if set(labels) not in (set('1234'),set('abcd')):
            output.append(item);continue
        choices=[]
        for c,ms in zip(values,markers):
            m=ms[0];label=_label(m);n=int(label) if label.isdigit() else 'abcd'.index(label)+1
            if not _has_content(c[m.end():]):break
            choices.append(dict(type='text',text=f'({n}) '+c[m.end():].strip(),answer_choice=True,choice_number=n,indent=0,y=item.get('y',0),confidence=100))
        if len(choices)==4:output.extend(sorted(choices,key=lambda c:c['choice_number']))
        else:output.append(item)
    return output
