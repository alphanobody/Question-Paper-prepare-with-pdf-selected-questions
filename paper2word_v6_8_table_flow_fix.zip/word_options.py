"""Fast export-option validation. Standard library only: safe at UI opening."""
import math
import re


def export_options(data):
    raw=data.get('start_number',1)
    if isinstance(raw,bool) or not re.fullmatch(r'[0-9]{1,4}',str(raw).strip()):
        raise ValueError('Start question number must be a whole number from 1 to 9999.')
    start=int(raw)
    if not 1<=start<=9999:
        raise ValueError('Start question number must be 1–9999.')
    try:size=float(data.get('font_size',11))
    except (TypeError,ValueError):raise ValueError('Choose a font size from 7 to 28 pt.') from None
    if not math.isfinite(size) or not 7<=size<=28:
        raise ValueError('Choose a font size from 7 to 28 pt.')
    font=data.get('font_name','Times New Roman')
    if not isinstance(font,str) or not font.strip() or len(font.strip())>80 or any(ord(c)<32 or c in '<>' for c in font):
        raise ValueError('Enter a valid installed font name (up to 80 characters).')
    return dict(start_number=start,font_size=size,font_name=font.strip())
