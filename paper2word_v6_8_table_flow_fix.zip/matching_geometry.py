"""Conservative source-line reconstruction of explicitly headed matching grids.
No source-specific transcript, answer correction, or fixed page coordinates.
"""
import re
import statistics

HEADER=re.compile(r'^column\s*(?:[il1]{1,3}|[123])\s*$',re.I)
LABEL=re.compile(r'^\s*(?:\([A-Z0-9]{1,3}\)|[A-Z0-9]{1,3}[.)])\s*')


def rows_by_baseline(geometry):
    if not geometry:return []
    height=statistics.median(g['bbox'][3]-g['bbox'][1] for g in geometry)
    rows=[]
    for g in sorted(geometry,key=lambda g:((g['bbox'][1]+g['bbox'][3])/2,g['bbox'][0])):
        cy=(g['bbox'][1]+g['bbox'][3])/2
        if rows and abs(cy-rows[-1][0])<max(2,height*.52):
            rows[-1][1].append(g)
        else:rows.append((cy,[g]))
    return [sorted(row,key=lambda g:g['bbox'][0]) for cy,row in rows]


def recover_matching(geometry,clip):
    """Return items only when two Column headers and labelled rows verify grid.

    Works from original line boxes, NOT space-chunked words: a left cell's long
    OCR box can overlap the right cell by several pixels without becoming prose.
    The trailing code grid is a distinct table with its own bounded widths.
    """
    from offline_layout import word_lines,compile_items
    headers=[g for g in geometry if HEADER.fullmatch(g['text'].strip())]
    pair=None
    for a in headers:
        for b in headers:
            if b['bbox'][0]-a['bbox'][0]<clip.width*.18:continue
            ha=a['bbox'][3]-a['bbox'][1];hb=b['bbox'][3]-b['bbox'][1]
            if abs(sum(a['bbox'][1::2])/2-sum(b['bbox'][1::2])/2)<=max(ha,hb)*.65:
                pair=a,b;break
        if pair:break
    if not pair:return None
    a,b=pair;mid=(a['bbox'][0]+b['bbox'][0])/2
    y0=min(a['bbox'][1],b['bbox'][1]);headerbottom=max(a['bbox'][3],b['bbox'][3])
    before=[g for g in geometry if (g['bbox'][1]+g['bbox'][3])/2<y0]
    after=[g for g in geometry if g not in before and g not in pair and g['bbox'][1]>=headerbottom-2]
    bands=rows_by_baseline(after);body=[];tail=[];labelled=0
    for n,band in enumerate(bands):
        # A compact A B C D / 1 2 3 4 header begins the ANSWER code table.
        short_header=len(band)>=3 and all(re.fullmatch(r'[A-Z1-9]',g['text'].strip()) for g in band)
        answer_row=any(re.match(r'^\s*[1-4]\)',g['text']) for g in band)
        if short_header or answer_row:
            tail=[g for row in bands[n:] for g in row];break
        cells=['','']
        for g in band:
            ci=int(g['bbox'][0]>=mid)
            cells[ci]+=(' ' if cells[ci] else '')+g['text'].strip()
        # OCR can merge just one matching row across the gutter. A
        # visible second label in that row restores the cell boundary; no
        # words/answers are inferred. Require other clearly separated rows.
        if cells[0] and not cells[1] and LABEL.match(cells[0]):
            left_label=LABEL.match(cells[0]).group()
            other=(r'\s+(?=\d{1,2}[.]\s+)' if re.search(r'[A-Z]',left_label) else r'\s+(?=[A-Z][.]\s+)')
            split=re.split(other,cells[0],maxsplit=1)
            if len(split)==2:cells=split
        marked=any(LABEL.match(c) for c in cells if c)
        if marked:labelled+=1
        if body and not marked:
            for ci,c in enumerate(cells):
                if c:body[-1][ci]+='\n'+c
        else:body.append(cells)
    if labelled<3 or not body or not any(r[0] for r in body) or not any(r[1] for r in body):return None
    # Require enough original line coverage that the table isn't inferred from
    # a coincidental mention of Column I/II in a prose question.
    if sum(bool(r[0]) and bool(r[1]) for r in body)<2:return None
    items=compile_items(word_lines(before),clip,[],[])
    items.append(dict(type='table',rows=[[a['text'],b['text']]]+body,widths=[1,1],border=False,
                      indent=0,y=y0,geometry_matching=True))
    if tail:items+=compile_items(word_lines(tail),clip,[],[])
    return items


def attach_picture_choices(items,geometry):
    """Keep four image-only answers with their own printed labels and order.

    Use four actually recognised labels and four distinct nearby source crops;
    never infer absent choices or include question text in an image.
    """
    pictures=[i for i in items if i.get('type')=='image' and i.get('bbox')]
    labels={}
    for g in geometry:
        m=re.fullmatch(r'\s*\(?([1-4])\)\s*',g['text'])
        if m:labels[int(m[1])]=g
    if len(labels)!=4:return items
    assigned={};used=set()
    for n,g in sorted(labels.items()):
        x0,y0,x1,y1=g['bbox'];cy=(y0+y1)/2
        candidates=[p for p in pictures if p['asset'] not in used and p['bbox'][1]-3<=cy<=p['bbox'][3]+3 and -3<=p['bbox'][0]-x1<=50]
        if not candidates:return items
        p=min(candidates,key=lambda p:abs(p['bbox'][0]-x1));assigned[n]=p;used.add(p['asset'])
    # The only editable content to remove must consist solely of bare labels.
    # If the recognised table mixes labels with text, don't discard that text.
    output=[]
    for item in items:
        if item.get('type')=='image' and item['asset'] in used:continue
        if item.get('type') in ('text','table'):
            value=item.get('text','') if item['type']=='text' else ' '.join(c for row in item['rows'] for c in row)
            if re.fullmatch(r'(?:\s*\(?[1-4]\)\s*)+',value):continue
        output.append(item)
    top=min(p['y'] for p in assigned.values())
    for n,p in sorted(assigned.items()):
        output.append(dict(p,picture_choice_number=n,y=top+n*.001))
    return output


def separate_table_stem(items):
    """Move a clear question stem out of a layout model's whole-question table.

    Only leading full-width text rows before a multi-column header qualify.
    Their wording is retained verbatim, not re-recognised or hardcoded.
    """
    if not items or items[0].get('type')!='table':return items
    table=items[0];rows=table.get('rows',[])
    if not rows or not re.match(r'^\s*\d{1,4}[.]\s+\S',rows[0][0]):return items
    n=0
    while n<len(rows) and rows[n] and rows[n][0].strip() and not any(c.strip() for c in rows[n][1:]):n+=1
    if not n or n==len(rows):return items
    text=' '.join(row[0].strip() for row in rows[:n])
    first=dict(type='text',text=text,y=table['y'],indent=0,confidence=100)
    kept=dict(table,rows=rows[n:],y=table['y']+.001)
    return [first,kept]+items[1:]


def recover_arrow_answers(items,geometry):
    """Repair four plain-letter arrow answers merged/reordered as math arrays.

    Only exact recognised 1-4 labels with a complete literal A→B→C-like body,
    high confidence, and a separate stem qualify. No formula simplification,
    chemical interpretation, missing-label inference or transcript replacement.
    """
    found={}
    for g in geometry:
        if g.get('conf',0)<90:continue
        m=re.fullmatch(r'\s*\(?([1-4])\)\s*((?:[A-Z]\s*(?:→|⟶|⇒|->)\s*)+[A-Z][.]?)\s*',g['text'])
        if m:found[int(m[1])]=(g,m[2])
    if set(found)!={1,2,3,4}:return items
    top=min(g['bbox'][1] for g,text in found.values())
    # Avoid removing an OCR block spanning both stem and answers.
    for item in items:
        box=item.get('bbox')
        if box and box[1]<top-2 and box[3]>top+2:return items
    before=[item for item in items if item.get('y',0)<top-2]
    if not before:return items
    # Never discard a source picture in this text-only repair.
    if any(item.get('type')=='image' for item in items if item not in before):return items
    for n,(g,text) in sorted(found.items()):
        before.append(dict(type='text',text=f'({n}) '+text,y=top+n*.001,indent=0,confidence=g['conf'],answer_choice=True,choice_number=n))
    return before
