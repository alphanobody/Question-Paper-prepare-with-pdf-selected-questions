# v6.8 validation — screenshot image-7 and the actual eight-page PDF

## Scope and actual reproduction

Source: `MP 30-11-2026 50Q CELL DIVISION AND EXCRETION1-30-20-50.pdf`.
Screenshot matching question corresponds to printed source Q17 on PDF page 3;
its Word numbering can differ depending on selected questions/start number.
The long cell-cycle statements correspond to source Q22 on PDF page 4.

The v6.7 source was genuinely rerun on question areas from pages 3–4. It reproduced:

- Interleaved source order 11,15,12,16,17,13,14,18 (and interleaving on page 4).
- Repeated RCC separator text recognised as **CC / a / ** and false table cells.
- Q17's header/first A+1 row flattened into prose; later rows became a table,
  while final 5. Diplotene was detached. Its last answer-grid column was overwide.
- Q12 whole-question/merged table errors; Q14 a raw array inside one table cell.
- A low-memory worker termination during ruled-table inference. The bounded
  dynamic-shape 512-pixel table profile subsequently completed the same crop.

This is stronger evidence than a screenshot-only diagnosis or a constructed mock.

## Verified causes and general fixes

1. A compound drawing path contains both central filled rules. Its union width
   is about 14 pt, so the old path-width <2 pt check missed it. Individual long
   vertical segments now establish the measured gutter and column split.
2. The later task sorter fell back to page midpoint instead of the inferred split.
   A slight boundary mismatch made a left-column crop look spanning. The actual
   source split is now retained. Left/right questions no longer interleave.
3. Repeated publisher text in that measured central band contaminated OCR/layout.
   It is excluded before recognition of column crops; no arbitrary text-area
   transcript or source-coordinate constants are substituted.
4. Space chunking and permissive table tests mistook prose and overlapping boxes
   for cells. Explicit Column I/II matching grids use their original line starts,
   visible row labels, independent matching rows and separate answer-code tables.
5. Code widths no longer extend into blank space at the right crop edge. Word
   answer-code tables get a separate narrow number column and balanced data
   columns. The hanging answer indent cannot squeeze the first data word.
6. Four image choices are associated with recognised adjacent labels and exported
   in 1–4 order as labelled picture paragraphs. Source stem pictures stay separate.
7. Clear full-width question-stem rows are moved outside a recognised whole-question
   table. Complete simple answer grids (including mixed text plus a 3/4 mini-grid)
   become answer paragraphs; matching/code grids retain their editable structure.
8. Source Roman statement line starts are preserved; inline Roman mentions are not
   indiscriminately split. Protected native equations are retained.
9. High-confidence complete simple letter-arrow answer groups can replace merged
   math-array proposals with literal source-recognised text in correct 1–4 order.
   No missing labels, factual answers or complex formulas are inferred.

## End-to-end and output checks: PASS

### All eight pages

Real local recognition, API processing/review/download, then Word export:

| PDF page | Selected question count | Printed numbers detected in source order |
|---|---:|---|
| 1 | 5 | 1–5 |
| 2 | 5 | 6–10 |
| 3 | 8 | 11–18 |
| 4 | 8 | 19–26 |
| 5 | 6 | 27–32 |
| 6 | 5 | 41–45 |
| 7 | 13 | 31–43 |
| 8 | 7 | 44–50 |

Total **57 selected question records**, not 57 consecutive source question labels.
This exact supplied PDF has a gap/restart in printed numbering across sections.
One question-content box per page was used; page-1 box starts below its banner,
and only the left-side questions were selected on pages 6/8, excluding answer keys.
No source question transcript was manually inserted into the output or production.
The combined sample renumbers records continuously 1–57 as requested by the app's
start-number feature. Counts demonstrate heading separation/order, NOT perfect OCR.

- 57 native top-level Word question-number paragraphs; no question numbering inside
  tables, floating text tables, or forced page/column breaks.
- Four actual picture-choice labels remain attached to their matching source crops
  and ordered 1–4, including through review/font/layout changes.
- ADH/GFR source Q47's stem is outside its editable two-column grid.
- Simple NaCl arrow-code source Q44 has separate 1–4 answer paragraphs, not 1,2,4,3.
- The mixed text/table final option row in source Q36 becomes four answer paragraphs.
- Source Q14 has editable code cells instead of a literal raw table-array string.
  Supported native equations elsewhere can contain LaTeX arrays internally; those
  are native OMML objects, not displayed raw code.
- Eleven genuine diagram/picture crops and eleven editable tables in combined output.
  The stem plus four diagram answers account for five pictures in source Q8.

### Screenshot's later-page region

Source Q11–Q26: 16 questions, five editable tables, one real graph, native maths.
Exact Q12 and Q17 matching cells and code rows were compared with source. Q17's
final extra right-side row is present; the A/1 first row is split into its cells.
Q22's I/II/III/IV statements are separate body paragraphs, not a false table.
The actual later-page DOCX is provided alongside its two-page PDF rendering.

### Retained prior tests

- Actual first-page Q1–Q5 fresh upload/recognition: five questions, one diagram,
  two editable tables, no forced breaks. All eight stored rotations normalised.
- Actual earlier Biology PDF one-box Q5–Q7: three records, final numbers 21–23;
  cached font/reformat pass also works.
- Actual Q24 repeated (b) source labels and eight annotated arrows preserved.
- Font/size/Single/Double/start-number tests; three full-57-question font/layout
  exports; immutable picture-choice review metadata; simple/mixed answer grids.
- Solutions merge, explicit corresponding numbers, continuation parts, native
  math/table structures, matching file/download and linked-number review locking.
- Boss area/page scope, current/specific/all pages, independent columns, source
  labels/no extra numbering, isolated documents and editable flow.
- Browser pointer/category/selection/group/page-scope/download/review tests pass
  without JS runtime errors. Browser conversion responses are mocked; genuine
  engine recognition was tested separately as described above.
- Lazy startup, missing-engine diagnostics, failed-import recovery, cancellation,
  Python compilation, JS syntax, fresh ZIP extraction and CRC checks.
- Synthetic 0/90/180/270 rotations with offset crop boxes/images/annotations and
  all eight actual pages preserve displayed pixels; original upload hash unchanged.
- Synthetic compound central rules and ordinary justified prose tests; all-column
  anchor evidence required to infer a table, not merely the shared left margin.

## Visual inspection

The final Word files were rendered by LibreOffice Writer **with Math installed**.
The full combined sample is six pages and Q11–Q26 sample two pages. Rendered pages
were inspected, including matching tables, Roman statements, image-only answers,
code grids, later-page ADH/GFR table and plain arrow-code answers. The screenshot's
clipped narrow text columns/false-table gaps are absent in the tested region.
Source column positions and page boundaries are not locked: this is editable Word
reflow, not pixel-identical PDF reproduction. Remaining content can naturally flow
into the next column/page, and final-page blank space is not a forced-layout bug.

## Accuracy and platform limits — do not omit

The samples are genuine AUTOMATIC output, not manually corrected exam papers.
OCR remains imperfect: Q1 In/An versus source 1n/4n, Q14 G2/G1 losing subscript
styling, misspellings, some complex arrow/formula labels and glyphs need review.
Some inline statement breaks may still differ from source when OCR merged them.
The 57/57 count is a heading/order test, not a word/symbol accuracy percentage.
No source-specific semantic correction or answer guessing is used.

Recognition ran serially in a roughly 2-GB Linux sandbox with the same pinned
local models, OCR batch one and bounded ruled-table input. A genuine recognition
pass across the newly selected full-file regions took about 416 seconds, reusing
previously tested page-3/4 caches. Later layout-only passes reused all recognition
caches. These are not fresh Windows timing or minimum-RAM guarantees.

An actual Windows 8-GB desktop and Microsoft Word were not interactively tested.
Word/font substitutions can change line wrapping and pagination. The separate
older multiline-maths screenshot is not certified fixed by this Biology PDF.
The app requires checking output against source before real exam use.
