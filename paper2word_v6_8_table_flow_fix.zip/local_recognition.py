"""Translate genuine local MinerU OCR/layout output into editable Word blocks.

No recognition API, authentication, network inference or source-specific answers.
"""
import json
import math
import os
import re
import subprocess
import sys
import threading
import time
import signal
import hashlib
from pathlib import Path
from html import escape
from html.parser import HTMLParser
from importlib.metadata import version, PackageNotFoundError

import pymupdf as fitz
from offline_layout import rect, contained, source_columns, diagram_regions, equation_xml, word_lines, compile_items, normalize_science
from editable_export import reading_order

BASE = Path(__file__).resolve().parent
ENGINE_LOCK = threading.Lock()
from engine_state import engine_status


class LocalRecognitionError(Exception):
    pass


def rich_content(value, warnings):
    if isinstance(value, str):
        return value
    if not isinstance(value, list):
        return ''
    parts = []
    for span in value:
        if not isinstance(span, dict):
            continue
        typ = span.get('type', '')
        content = span.get('content', '')
        if typ in ('equation_inline', 'equation'):
            latex = str(content)
            try:
                equation_xml(latex)
            except Exception:
                warnings.append('An equation needs checking; its LaTeX is retained as editable text.')
            parts.append('\\(' + latex + '\\)')
        elif isinstance(content, list):
            parts.append(rich_content(content, warnings))
        elif isinstance(content, str):
            # No Markdown processing of literal exam text: retain printed data.
            text = content
            if span.get('bold'):
                text = '<b>' + text + '</b>'
            parts.append(text)
    return ''.join(parts)


class EditableTable(HTMLParser):
    """Decode OCR HTML into a bounded cell grid, preserving merged cells.

    Only text/sub/sup/b/math are recognized; no paths, scripts or remote images.
    """
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows=[];self.grid={};self.merges=[];self.r=-1;self.c=0
        self.cell=None;self.meta=None;self.math_depth=0
    def handle_starttag(self, tag, attrs):
        if tag=='tr':
            self.r+=1;self.c=0
        elif tag in ('td','th'):
            if self.r<0:self.r=0
            while (self.r,self.c) in self.grid:self.c+=1
            a=dict(attrs)
            try:rs=max(1,min(100,int(a.get('rowspan',1))));cs=max(1,min(12,int(a.get('colspan',1))))
            except Exception:rs=cs=1
            if self.r>=100 or self.c+cs>12:raise LocalRecognitionError('A recognized table is too large to rebuild. Try a smaller selection or separate boxes for that area.')
            self.meta=(self.r,self.c,rs,cs);self.cell=[]
        elif self.cell is not None:
            if tag=='br':self.cell.append('\n')
            elif tag in ('sub','sup','b'):self.cell.append('<'+tag+'>')
            elif tag=='math':self.math_depth+=1;self.cell.append('<math>')
            elif self.math_depth:self.cell.append('<'+tag+'>')
    def handle_endtag(self,tag):
        if tag in ('td','th') and self.cell is not None:
            r,c,rs,cs=self.meta
            text=''.join(self.cell).strip()
            # Preserve inline MathML as LaTeX where the OCR uses it in cells.
            text=mathml_cells(text)
            for y in range(r,r+rs):
                for x in range(c,c+cs):self.grid[y,x]=text if (y,x)==(r,c) else ''
            if rs>1 or cs>1:self.merges.append((r,c,r+rs-1,c+cs-1))
            self.c=c+cs;self.cell=None
        elif self.cell is not None:
            if tag in ('sub','sup','b'):self.cell.append('</'+tag+'>')
            elif tag=='math':self.cell.append('</math>');self.math_depth=max(0,self.math_depth-1)
            elif self.math_depth:self.cell.append('</'+tag+'>')
    def handle_data(self,data):
        if self.cell is not None:self.cell.append(escape(data) if self.math_depth else data)
    def result(self):
        self.close()
        if not self.grid:raise LocalRecognitionError('A detected table had no editable cells. Select its region more tightly and retry.')
        nr=max(r for r,c in self.grid)+1;nc=max(c for r,c in self.grid)+1
        return [[self.grid.get((r,c),'') for c in range(nc)] for r in range(nr)],self.merges


def mathml_cells(text):
    # MinerU tables normally carry $...$ or \(...\) text. For unsupported
    # MathML, retain the visible text with a review marker instead of dropping it.
    def fallback(m):
        from html import unescape
        return '[Check equation] '+unescape(re.sub(r'<[^>]+>','',m.group()))
    return re.sub(r'<math>.*?</math>',fallback,text,flags=re.S)


def table_math(text):
    # MinerU's table HTML can emit LaTeX between dollar delimiters.
    return re.sub(r'(?<!\\)\$([^$\n]+)\$',lambda m:'\\('+m[1]+'\\)',text)


def block_box(block, clip):
    values=block.get('bbox',[0,0,1,1])
    if not isinstance(values,list) or len(values)!=4:raise LocalRecognitionError('Invalid local layout coordinates.')
    v=[float(n) for n in values]
    if any(not math.isfinite(n) for n in v):raise LocalRecognitionError('Invalid local layout coordinates.')
    x0,y0,x1,y1=[max(0,min(1,n)) for n in v]
    return fitz.Rect(clip.x0+x0*clip.width,clip.y0+y0*clip.height,clip.x0+x1*clip.width,clip.y0+y1*clip.height)


def parse_local_blocks(result, page, clip, known_pictures, folder, qid, explicit_tables=None, flow_mode=False):
    pages=result.get('pages') or []
    if len(pages)!=1:raise LocalRecognitionError('The local engine returned an unexpected page count for this question.')
    blocks=pages[0].get('blocks',[])
    if not isinstance(blocks,list) or len(blocks)>1000:raise LocalRecognitionError('Invalid local recognition output.')
    images=list(known_pictures);warnings=[];content=[]
    from source_outline import reaction_lines
    try:outlined=reaction_lines(page,clip,result,block_box)
    except (ValueError,RuntimeError,IndexError,ArithmeticError):
        outlined={}
        warnings.append('Source-outline reaction recovery was unavailable; local OCR equations were retained for checking.')
    for block_index,block in enumerate(blocks):
        b=block_box(block,clip);typ=block.get('type','')
        if typ in ('image','chart','seal'):
            if b.get_area()>clip.get_area()*.85:
                warnings.append('A nearly full-question picture proposal was rejected. Mark only the real diagram with a purple box if needed.')
                continue
            if not any(contained(b,old,.6) or contained(old,b,.6) for old in images):images.append(b)
        else:content.append((block,b,block_index))
    items=[];protected=[];protected_boxes=[]
    for block,b,block_index in content:
        if b.is_empty:continue
        if any(contained(b,p,.85) for p in images):continue
        typ=block.get('type','text')
        item=dict(indent=max(0,b.x0-clip.x0),y=b.y0,bbox=list(b))
        if flow_mode:item['flow_role']=typ
        has_math=typ in ('equation','interline_equation') or any(
            isinstance(span,dict) and span.get('type') in ('equation_inline','equation')
            for span in (block.get('content') if isinstance(block.get('content'),list) else []))
        if block_index in outlined:
            item=outlined[block_index];item['bbox']=list(b);items.append(item);protected.append(item);protected_boxes.append(b)
            continue
        if typ=='table':
            body=block.get('content',[])
            html=''.join(p.get('content','') for p in body if isinstance(p,dict) and p.get('type')=='table_body' and isinstance(p.get('content'),str))
            parser=EditableTable();parser.feed(html);rows,merges=parser.result()
            rows=[[table_math(c) for c in row] for row in rows]
            if merges:warnings.append('This table contains merged cells. Verify their arrangement against the source; the editable review uses a rectangular grid.')
            item.update(type='table',rows=rows,widths=[1]*len(rows[0]),border=False)
            # Preserve captions/footnotes outside the table body as editable text.
            for child in body:
                if child.get('type')!='table_body':
                    t=rich_content(child.get('content',[]),warnings)
                    if t:items.append(dict(type='text',text=t,indent=item['indent'],y=block_box(child,clip).y0,bbox=list(block_box(child,clip)),confidence=100))
        elif typ in ('equation','interline_equation'):
            text=rich_content(block.get('content',[]),warnings)
            if text.startswith('\\(') and text.endswith('\\)'):text=text[2:-2]
            try:
                equation_xml(text);item.update(type='equation',latex=text)
            except Exception:
                item.update(type='text',text='[Equation needs checking] '+text,confidence=0)
                warnings.append('A displayed equation could not be converted; its original notation is retained for correction.')
        else:
            text=rich_content(block.get('content',[]),warnings)
            if not text.strip():continue
            item.update(type='text',text=text,bold=typ in ('doc_title','paragraph_title'),confidence=100)
        items.append(item)
        if has_math:protected.append(item);protected_boxes.append(b)
    # Source-geometry fallback for a layout model that missed matching/option
    # columns, and for the optional blue table regions selected by the user.
    geometry=[];edge_fragments=0
    for item in result.get('local_geometry',[]):
        b=block_box(item,clip)
        if b.is_empty or any(contained(b,p,.5) for p in images):continue
        if b.width<=5 and b.height<=5 and min(abs(b.x0-clip.x0),abs(clip.x1-b.x1))<=5:
            center=(b.tl+b.br)/2
            if not any(box.contains(center) for _,box,_ in content):
                edge_fragments+=1;continue
        # A matching/answer grid is not permission to flatten other lines'
        # native equations. Remove protected math rows from the fallback input.
        if any(p.contains((b.tl+b.br)/2) or contained(b,p,.55) for p in protected_boxes):continue
        text=str(item.get('text','')).strip()
        if text:geometry.append(dict(text=normalize_science(text),bbox=list(b),conf=float(item.get('confidence',50))))
    if edge_fragments:warnings.append('Tiny edge fragments outside recognised content were omitted from geometry fallback; check source margins.')
    if geometry and not flow_mode:
        from matching_geometry import recover_matching
        matching=None if explicit_tables else recover_matching(geometry,clip)
        candidate=matching or compile_items(word_lines(geometry),clip,[],explicit_tables or [])
        original_tables=sum(i['type']=='table' for i in items)
        candidate_tables=sum(i['type']=='table' for i in candidate)
        # Never replace correctly recognized inline math just to reflow prose.
        # Recover only missed tables, with a prominent warning to check cells.
        roman_labels={re.match(r'^\s*([IVX]{1,6})[.]\s+',g['text'])[1] for g in geometry if re.match(r'^\s*([IVX]{1,6})[.]\s+',g['text'])}
        roman_geometry={'I','II','III'}<=roman_labels and not protected
        broken_tables=any(i['type']=='table' and any(re.search(r'\\begin\{(?:array|tabular)\}',c) for row in i['rows'] for c in row) for i in items)
        if matching is not None or roman_geometry or (broken_tables and candidate_tables>0) or (original_tables==0 and candidate_tables>0) or (explicit_tables and candidate_tables>0):
            items=sorted(protected+candidate,key=lambda item:item['y'])
            for i in items:
                if i['type']=='table':i['border']=False
            warnings.append('Source paragraph/table structure recovered from local text-line geometry; existing math/reaction lines were preserved. Verify text and table cells against the source.')
    if outlined:
        warnings.append('Reaction text, source labels and scripts recovered by matching source vector outlines to local OCR. Editable Word arrow annotations are retained. Unusual glyphs still need checking.')
    for i,b in enumerate(images):
        if b.is_empty:continue
        name=f'{qid}_diagram{i+1}.png'
        page.get_pixmap(dpi=250,clip=b,alpha=False).save(Path(folder)/'assets'/name)
        items.append(dict(type='image',asset=name,width=b.width,height=b.height,indent=max(0,b.x0-clip.x0),y=b.y0,bbox=list(b)))
    if flow_mode:
        from boss_mode import recover_manual_tables,order_flow_items
        items,extra=recover_manual_tables(items,geometry,explicit_tables or [])
        warnings.extend(extra)
        items,split=order_flow_items(items,page,clip,geometry)
        for item in items:item['flow_source_columns']=2 if split else 1
        return items,list(dict.fromkeys(warnings))
    if not flow_mode:
        from matching_geometry import attach_picture_choices,separate_table_stem,recover_arrow_answers
        items=recover_arrow_answers(items,[dict(text=g.get('text',''),bbox=list(block_box(g,clip)),conf=g.get('confidence',0)) for g in result.get('local_geometry',[])])
        items=attach_picture_choices(items,geometry)
        items=separate_table_stem(sorted(items,key=lambda i:i['y']))
        # Preserve source Roman statement starts as separate body paragraphs.
        # Only actual OCR line starts qualify; inline mentions stay untouched.
        rebuilt=[]
        for item in items:
            text=item.get('text','')
            labels=re.findall(r'(?:^|\n)\s*([IVX]{1,6})[.]\s+',text)
            if item.get('type')=='text' and len(labels)>=2 and labels[:2]==['I','II']:
                parts=re.split(r'\n(?=\s*[IVX]{1,6}[.]\s+)',text)
                for n,part in enumerate(parts):
                    if part.strip():rebuilt.append(dict(item,text=part.strip(),y=item['y']+n*.001))
            else:rebuilt.append(item)
        items=rebuilt
    if not items:raise LocalRecognitionError('No editable content found. Select a complete question and retry.')
    return sorted(items,key=lambda i:i['y']),list(dict.fromkeys(warnings))


def check_cancel(job):
    if job and job.get('cancel') and job['cancel'].is_set():
        raise LocalRecognitionError('Conversion stopped by user.')


def stop_worker(process):
    if process.poll() is not None:
        return
    if os.name == 'nt':
        subprocess.run(['taskkill','/PID',str(process.pid),'/T','/F'],
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
            creationflags=subprocess.CREATE_NO_WINDOW, timeout=10)
    else:
        try:os.killpg(process.pid, signal.SIGTERM)
        except ProcessLookupError:return
    try:process.wait(timeout=3)
    except subprocess.TimeoutExpired:
        if os.name != 'nt':
            try:os.killpg(process.pid, signal.SIGKILL)
            except ProcessLookupError:pass
        else:process.kill()
        process.wait(timeout=5)


def recognize_crop(input_pdf,output_json,log_path,job=None,detect_only=False):
    env=os.environ.copy()
    env.setdefault('MINERU_HOME',str(BASE/'model_data'))
    Path(output_json).unlink(missing_ok=True)
    options=dict(env=env, stdin=subprocess.DEVNULL, stderr=subprocess.STDOUT)
    if os.name=='nt':options['creationflags']=subprocess.CREATE_NO_WINDOW | subprocess.CREATE_NEW_PROCESS_GROUP
    else:options['start_new_session']=True
    with Path(log_path).open('w',encoding='utf-8') as log:
        command=[sys.executable,str(BASE/'local_worker.py'),str(input_pdf),str(output_json)]
        if detect_only:command.append('--detect-questions')
        process=subprocess.Popen(command,stdout=log,**options)
        if job is not None:job["worker_process"]=process
        started=time.monotonic()
        try:
            while process.poll() is None:
                check_cancel(job)
                if time.monotonic()-started>(240 if detect_only else 900):
                    raise LocalRecognitionError('Local question detection exceeded 4 minutes. Try a smaller selection.' if detect_only else 'This question exceeded 15 minutes. Try a smaller selection after closing other large apps.')
                time.sleep(.2)
            check_cancel(job)
        except BaseException:
            stop_worker(process)
            raise
        finally:
            if job is not None:job.pop("worker_process",None)
    with Path(log_path).open('a',encoding='utf-8') as log:
        log.write('\nLOCAL_WORKER_EXIT_CODE: '+str(process.returncode)+'\n')
    if process.returncode!=0 or not Path(output_json).is_file():
        detail=''
        for line in reversed(Path(log_path).read_text(encoding='utf-8',errors='replace').splitlines()[-40:]):
            if 'LOCAL_RECOGNITION_ERROR:' in line:
                detail=' '+line.split('LOCAL_RECOGNITION_ERROR:',1)[1].strip()[:240]
                break
        raise LocalRecognitionError('Local recognition stopped (worker exit '+str(process.returncode)+').'+detail+' If memory is low, close other large apps. Use Save error details below. No cloud fallback was used.')
    data=json.loads(Path(output_json).read_text(encoding='utf-8'))
    if not isinstance(data,dict) or not isinstance(data.get('pages'),list):
        raise LocalRecognitionError('The local engine returned incomplete output. Use Save error details below.')
    return data


def analyze_local(job,selections,output_columns):
    info=engine_status()
    if not info['ready']:raise LocalRecognitionError(info['message'])
    # Serializes jobs across tabs, while still allowing Cancel while queued.
    job['stage']='Waiting for the local CPU engine…'
    while not ENGINE_LOCK.acquire(timeout=.2):
        check_cancel(job)
    try:
        check_cancel(job)
        return _analyze_local(job,selections,output_columns)
    finally:
        ENGINE_LOCK.release()



def native_lines(page,clip):
    lines=[]
    for block in page.get_text('dict',clip=clip).get('blocks',[]):
        if block.get('type')!=0:continue
        for line in block.get('lines',[]):
            text=''.join(span.get('text','') for span in line.get('spans',[])).strip()
            if text:lines.append(dict(text=text,bbox=list(line['bbox']),confidence=100))
    return lines


def selection_geometry(job,pdf,pno,clip,selection_index,work,require_headings=True):
    """Cached small geometry probe, with no formula/layout/table model load."""
    from question_split import HEADING
    page=pdf[pno-1];lines=native_lines(page,clip)
    enough_native=sum(len(i['text']) for i in lines)>=40 and (not require_headings or any(HEADING.match(i['text']) for i in lines))
    if not enough_native:
        signature={'engine':'4.2.3-question-probe-tiled-300-v3','page':pno,'clip':[round(v,4) for v in clip]}
        digest=hashlib.sha256(json.dumps(signature,sort_keys=True).encode()).hexdigest()
        cache=work/'cache';cache.mkdir(exist_ok=True)
        cached=cache/('probe_'+digest+'.json');probe=None
        if cached.is_file():
            try:
                probe=json.loads(cached.read_text(encoding='utf-8'))
                if not probe.get('question_probe') or not isinstance(probe.get('local_geometry'),list):probe=None
            except (ValueError,OSError,AttributeError):probe=None
        if probe is None:
            prefix='selection'+str(selection_index)+'_numbers'
            input_pdf=work/(prefix+'.pdf');output_json=work/(prefix+'.json')
            with fitz.open() as crop:
                target=crop.new_page(width=clip.width,height=clip.height)
                target.show_pdf_page(target.rect,pdf,pno-1,clip=clip);crop.save(input_pdf)
            probe=recognize_crop(input_pdf,output_json,work/(prefix+'.log'),job,detect_only=True)
            cached.write_text(json.dumps(probe,ensure_ascii=False),encoding='utf-8')
            input_pdf.unlink(missing_ok=True);output_json.unlink(missing_ok=True)
        lines=[dict(text=i.get('text',''),bbox=list(block_box(i,clip)),confidence=i.get('confidence',0),heading_only=bool(i.get('heading_only'))) for i in probe.get('local_geometry',[])]
    return lines


def plan_selection(job,pdf,pno,clip,split,selection_index,work):
    from question_split import split_selection
    lines=selection_geometry(job,pdf,pno,clip,selection_index,work)
    if split is None:
        from boss_mode import infer_split
        split=infer_split(list(clip),[line for line in lines if not line.get('heading_only')])
    parts,warnings=split_selection(list(clip),lines,split)
    if len(parts)>1 and split is not None and clip.x0<split-12 and clip.x1>split+12:
        for part in parts:
            part['source_columns']=2;part['source_split']=split
    if len(parts)>1:
        warnings.append(f'One selection was automatically split into {len(parts)} questions using printed main-question headings. Check the detected count against the PDF.')
    return parts,warnings

def _analyze_local(job,selections,output_columns):
    folder=Path(job['dir']);(folder/'assets').mkdir(exist_ok=True)
    work=folder/'recognition';work.mkdir(exist_ok=True)
    model=dict(version=6.8,recognition_provider='MinerU 4.2.3 · local ONNX CPU',title=Path(job['filename']).stem,
        output_columns=output_columns,font_size=11,keep_wrap=False,separator=True,preserve_source_columns=False,questions=[],
        warnings=['Local neural recognition — no API key or document upload. Check every question against its original.',
                  'Source columns and question structure are reconstructed. Exact typography, line breaks and pagination are not guaranteed.',
                  'Supported recognized LaTeX becomes native Word equations. Diagrams remain source-image crops. Tables and text remain editable.'])
    tasks=[]
    with fitz.open(folder/'source.pdf') as pdf:
        if any(pdf[int(p)-1].rotation for p,rs in selections.items() if rs):
            raise LocalRecognitionError('This PDF still has stored page rotation. Reopen the original PDF using this updated app before selecting areas.')
        for pno,selected in sorted((int(p),rs) for p,rs in selections.items() if rs):
            page=pdf[pno-1];ncols,split=source_columns(page)
            mains=[r for r in selected if r.get('kind','text')=='text']
            children=[r for r in selected if r.get('kind','text')!='text']
            if not split and any(r['x']+r['w']<=.53 for r in mains) and any(r['x']>=.47 for r in mains):ncols,split=2,page.rect.width/2
            for q in reading_order([dict(bbox=list(rect(r,page)),region=r) for r in mains],split):tasks.append((pno,ncols,q['region'],children))
        if not tasks:raise LocalRecognitionError('Draw a green box around one or more complete questions.')
        planned=[];selection_counts=[]
        for index,(pno,ncols,region,children) in enumerate(tasks):
            check_cancel(job)
            page=pdf[pno-1];clip=rect(region,page);_,split=source_columns(page)
            job['stage']=(f'Preparing Boss Mode area/page {index+1}/{len(tasks)}, page {pno}…' if job.get('document_category')=='boss' else f'Preparing solution part {index+1}/{len(tasks)}, page {pno}…' if job.get('document_category')=='solutions' else f'Finding question numbers in selection {index+1}/{len(tasks)}, page {pno}…')
            job['progress']=int(15*index/len(tasks))
            if job.get('document_category')=='boss':
                from boss_mode import plan_boss_regions
                lines=selection_geometry(job,pdf,pno,clip,index+1,work,require_headings=False)
                protected=[rect(r,page) for r in children if r.get('kind') in ('table','diagram')]
                parts,split_warnings=plan_boss_regions(page,clip,lines,split,protected)
            elif job.get('document_category')=='solutions':
                # Every drag is a continuation part, NEVER an inferred question.
                parts=[dict(bbox=list(clip),source_number=None)]
                split_warnings=[]
            else:
                parts,split_warnings=plan_selection(job,pdf,pno,clip,split,index+1,work)
            selection_counts.append(len(parts))
            for part in parts:
                planned.append(dict(page=pno,ncols=part.get('source_columns',ncols),clip=fitz.Rect(part['bbox']),children=children,
                    selection=index+1,source_split=part.get('source_split'),boss_reading_index=len(planned),source_number=part['source_number'],solution_number=region.get('solution_number'),split_warnings=split_warnings))
        # Re-sort actual questions rather than parent boxes: source reading order.
        ordered=[]
        for pno in sorted({t['page'] for t in planned}):
            page=pdf[pno-1];_,split=source_columns(page)
            if not split:
                split=next((t['source_split'] for t in planned if t['page']==pno and t.get('source_split')),None)
            if not split and any(t['ncols']==2 for t in planned if t['page']==pno):split=page.rect.width/2
            candidates=[dict(bbox=list(t['clip']),task=t) for t in planned if t['page']==pno]
            if job.get('document_category')=='boss':ordered.extend(sorted((e['task'] for e in candidates),key=lambda t:t['boss_reading_index']))
            else:ordered.extend(e['task'] for e in reading_order(candidates,split))
        job['detected_questions']=len(ordered)
        start=int(job.get('export_options',{}).get('start_number',1))
        if job.get('document_category') not in ('solutions','boss') and start+len(ordered)-1>9999:
            raise LocalRecognitionError(f'Detected {len(ordered)} questions. The final number would exceed 9999; choose a lower starting number.')
        model['selection_question_counts']=selection_counts
        if job.get('document_category')=='boss':model['boss_source_selections']=len(tasks)
        for index,task in enumerate(ordered):
            check_cancel(job)
            pno=task['page'];ncols=task['ncols'];children=task['children'];clip=task['clip']
            page=pdf[pno-1];qid=f'q{index+1}'
            # A repeated publisher watermark between two printed rules is NOT
            # question content. Exclude only the measured rule band, never a
            # guessed margin or text at arbitrary hardcoded coordinates.
            from offline_layout import source_gutter
            gutter=source_gutter(page)
            if gutter and clip.width<page.rect.width*.65:
                lo,hi=gutter
                if clip.x0<lo<clip.x1 and clip.x1<=hi+2:clip.x1=lo-.25
                elif clip.x0>=lo-2 and clip.x0<hi<clip.x1:clip.x0=hi+.25
            job['stage']=f"Local CPU: {'Boss area/page' if job.get('document_category')=='boss' else 'solution part' if job.get('document_category')=='solutions' else 'question'} {index+1}/{len(ordered)}, page {pno}. Reading text, formulas and tables…"
            job['progress']=15+int(70*index/len(ordered))
            preview=qid+'_source.jpg';page.get_pixmap(dpi=155,clip=clip,alpha=False).save(folder/'assets'/preview)
            children=[r for r in children if task['solution_number'] is None or r.get('solution_number')==task['solution_number']]
            explicit=[rect(r,page) for r in children if r.get('kind')=='diagram' and contained(rect(r,page),clip,.7)]
            tables=[rect(r,page) for r in children if r.get('kind')=='table' and contained(rect(r,page),clip,.7)]
            pictures=[r for r in diagram_regions(page,clip,explicit) if not any(contained(r,t,.5) for t in tables)]
            # Reuse successful recognition for unchanged boxes in THIS job.
            # Layout/export changes do not require loading all models again.
            signature={'engine':'4.2.3-onnx-cpu-lowmem-v1','page':pno,
                       'clip':[round(v,4) for v in clip]}
            digest=hashlib.sha256(json.dumps(signature,sort_keys=True).encode()).hexdigest()
            cache=work/'cache';cache.mkdir(exist_ok=True)
            cached=cache/(digest+'.json')
            input_pdf=work/(qid+'.pdf');output_json=work/(qid+'.json')
            result=None
            if cached.is_file():
                try:
                    result=json.loads(cached.read_text(encoding='utf-8'))
                    if not isinstance(result,dict) or not result.get('pages'):result=None
                except (ValueError,OSError):pass
            if result is not None:
                job['cached_questions']=job.get('cached_questions',0)+1
                job['stage']=f'Reusing selected question {index+1}/{len(ordered)} — no recognition rerun'
            else:
                with fitz.open() as crop:
                    target=crop.new_page(width=clip.width,height=clip.height)
                    target.show_pdf_page(target.rect,pdf,pno-1,clip=clip)
                    crop.save(input_pdf)
                result=recognize_crop(input_pdf,output_json,work/(qid+'.log'),job)
                cached.write_text(json.dumps(result,ensure_ascii=False),encoding='utf-8')
            items,warnings=parse_local_blocks(result,page,clip,pictures,folder,qid,tables,flow_mode=job.get('document_category')=='boss')
            warnings=list(dict.fromkeys(task['split_warnings']+warnings))
            model['questions'].append(dict(id=qid,page=pno,solution_number=task['solution_number'],source_selection=task['selection'],detected_source_number=task['source_number'],source_columns=ncols,source_width=clip.width,source_height=clip.height,
                source_column=int((clip.x0+clip.x1)/2>page.rect.width/2) if ncols==2 else 0,
                source_asset=preview,engine='mineru',items=items,warnings=warnings))
            input_pdf.unlink(missing_ok=True)
            output_json.unlink(missing_ok=True)
    model['warnings']=list(dict.fromkeys(model['warnings']+[warning for q in model['questions'] for warning in q.get('warnings',[])]))
    if job.get('document_category')=='solutions':
        from solutions import merge_solution_parts
        merge_solution_parts(model)
    return model
