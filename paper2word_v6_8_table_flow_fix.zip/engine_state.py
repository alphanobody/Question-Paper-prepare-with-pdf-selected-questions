"""Fast engine readiness: standard library ONLY; never imports OCR/PDF libraries."""
import os
from pathlib import Path
from importlib.metadata import version, PackageNotFoundError

BASE = Path(__file__).resolve().parent
ENGINE_VERSION = '4.2.3'
REQUIRED = [
    'Layout/PP-DocLayoutV2/inference.onnx',
    'MFR/pp_formulanet_plus_m/PP-FormulaNet_plus-M.onnx',
    'MFR/pp_formulanet_plus_m/PP-FormulaNet_plus-M_inference.yml',
    'OCR/paddleocr/ch_PP-OCRv6_tiny_det_infer.onnx',
    'OCR/paddleocr/ch_PP-OCRv6_small_rec_infer.onnx',
    'Table/slanet-plus.onnx', 'Table/unet.onnx',
    'Table/PP-LCNet_x1_0_table_cls.onnx',
]


def model_home():
    return Path(os.environ.get('MINERU_HOME', str(BASE / 'model_data')))


def engine_status():
    try:
        installed = version('mineru')
    except (PackageNotFoundError, OSError):
        installed = None
    models = model_home() / 'models' / 'MinerU-4_models_onnx'
    missing = [p for p in REQUIRED if not (models / p).is_file()]
    ready = installed == ENGINE_VERSION and not missing
    return dict(engine='MinerU 4.2.3 / local ONNX CPU', installed=installed,
                models_ready=not missing, ready=ready, api_required=False,
                message='Local engine ready' if ready else
                'The app can open PDFs, but the recognition engine is not ready. Close this app, run SETUP_LOCAL_WINDOWS.bat once, then restart. No API key is needed.')
