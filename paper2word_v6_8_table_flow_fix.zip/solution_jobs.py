"""Serial local recognition and separate, independently reviewable documents."""
import json
import shutil
import threading
import uuid
from pathlib import Path


def _has_main(selections):
    return any(r.get('kind', 'text') == 'text' for rs in selections.values() for r in rs)


def _save_model(job, model, columns, export_docx):
    from aligned_word import normalize_question_numbers
    model.update(job.get('export_options', {}))
    model.update(output_columns=columns, keep_wrap=False, preserve_source_columns=False)
    normalize_question_numbers(model)
    if job['cancel'].is_set():
        from local_recognition import LocalRecognitionError
        raise LocalRecognitionError('Conversion stopped by user.')
    folder = Path(job['dir'])
    out = folder / 'result.docx'
    stats = export_docx(model, folder, out)
    for name in ('original_model.json', 'review_model.json'):
        (folder / name).write_text(json.dumps(model, ensure_ascii=False, indent=2), encoding='utf-8')
    job.update(model=model, original_model=model, docx=str(out), stats=stats)


def build_documents(job_id, job, selections, columns, registry, analyze_local, export_docx):
    solutions = job.get('solutions', {})
    has_questions = _has_main(selections)
    has_solutions = _has_main(solutions)
    documents = []
    if has_questions:
        job['document_category'] = 'questions'
        model = analyze_local(job, selections, columns)
        model['document_category'] = 'questions'
        start = job['export_options'].get('start_number', 1)
        available = set(range(start, start + len(model['questions'])))
        from solutions import validate_solution_selections
        requested = set(validate_solution_selections(solutions))
        unmatched = requested - available
        if unmatched:
            from local_recognition import LocalRecognitionError
            raise LocalRecognitionError('Solution question number(s) '+', '.join(map(str, sorted(unmatched)))+' do not match the exported questions '+str(start)+'–'+str(start+len(model['questions'])-1)+'. Use the final WORD question number (including Start number), not a different printed PDF number.')
        if has_solutions:
            model['linked_numbering_locked'] = True
            missing = sorted(available - requested)
            if missing:
                model['warnings'].append('No solution selected for Word question(s): '+', '.join(map(str, missing))+'. No blank or invented solution is inserted.')
        _save_model(job, model, columns, export_docx)
        documents.append(dict(category='questions', label='Questions', job_id=job_id, stats=job['stats']))
    if has_solutions:
        if has_questions:
            # Separate folder avoids q1 source/diagram filenames overwriting questions.
            folder = Path(job['dir']) / 'solutions'
            folder.mkdir(exist_ok=True)
            source = folder / 'source.pdf'
            if not source.exists():
                try:source.hardlink_to(Path(job['dir']) / 'source.pdf')
                except OSError:shutil.copyfile(Path(job['dir']) / 'source.pdf', source)
            child_id = uuid.uuid4().hex
            target = dict(dir=str(folder), filename=job['filename'], page_count=job['page_count'],
                          status='processing', progress=0, stage='Recognizing solution parts…',
                          error=None, docx=None, stats=None, cancel=job['cancel'],
                          preview_lock=threading.Lock(), lock=threading.Lock(),
                          export_options=dict(job['export_options']), document_category='solutions', parent_id=job_id)
            registry[child_id] = target
            job.setdefault('child_ids', []).append(child_id)
        else:
            child_id, target = job_id, job
            target['document_category'] = 'solutions'
        job.update(stage='Recognizing solution parts locally; joining by question number…', progress=50)
        model = analyze_local(target, solutions, job['solution_columns'])
        model['title'] += ' — Solutions'
        _save_model(target, model, job['solution_columns'], export_docx)
        if target is not job:target.update(status='done', progress=100, stage='Solutions ready')
        documents.append(dict(category='solutions', label='Solutions', job_id=child_id, stats=target['stats']))
    boss = job.get('boss')
    if boss:
        if documents:
            folder = Path(job['dir']) / 'boss'
            folder.mkdir(exist_ok=True)
            source = folder / 'source.pdf'
            if not source.exists():
                try:source.hardlink_to(Path(job['dir']) / 'source.pdf')
                except OSError:shutil.copyfile(Path(job['dir']) / 'source.pdf', source)
            boss_id = uuid.uuid4().hex
            target = dict(dir=str(folder), filename=job['filename'], page_count=job['page_count'],
                          status='processing', progress=0, stage='Recognizing Boss Mode content…',
                          error=None, docx=None, stats=None, cancel=job['cancel'],
                          preview_lock=threading.Lock(), lock=threading.Lock(),
                          export_options=dict(job['export_options']), document_category='boss', parent_id=job_id)
            registry[boss_id] = target
            job.setdefault('child_ids', []).append(boss_id)
        else:
            boss_id, target = job_id, job
            target['document_category'] = 'boss'
        job.update(stage='Boss Mode: recognising selected areas/pages as editable content…', progress=65)
        model = analyze_local(target, boss['selections'], boss['output_columns'])
        from boss_mode import finish_boss_model
        finish_boss_model(model, boss)
        model['title'] += ' — Boss Mode'
        _save_model(target, model, boss['output_columns'], export_docx)
        if target is not job:target.update(status='done', progress=100, stage='Boss Mode ready')
        documents.append(dict(category='boss', label='Boss Mode', job_id=boss_id, stats=target['stats']))
    if job['cancel'].is_set():
        from local_recognition import LocalRecognitionError
        raise LocalRecognitionError('Conversion stopped by user.')
    job.update(documents=documents, status='done', progress=100,
               stage='Ready — separate Word files: '+', '.join(d['label'] for d in documents))
