# Paper2Word 6.8 — matching-table and column-flow repair

**Update for the actual Cell Division PDF and image-7 screenshot.**
The earlier v6.7 rotation patch did not fix all later-page table/column failures.
This release repairs their underlying geometry and Word-table layout rules.

## Update on your Windows computer

1. Stop the old app with **Ctrl+C** in its console; close its browser tab.
2. Extract **ALL** ZIP files into `F:\test\paper2word_app`, replacing old files.
3. **KEEP `venv_local` and `model_data`**. This update needs no new models.
4. Run `START_WINDOWS.bat`. Confirm **6.8 · TABLE & FLOW FIX**.
5. **Open the ORIGINAL PDF again and redraw selections.** Previous exported
   Word files and old conversion results do not repair themselves.

PowerShell 5.1 — copy these as two separate commands:

```powershell
Set-Location -LiteralPath 'F:\test\paper2word_app'
& '.\START_WINDOWS.bat'
```

New/updated `matching_geometry.py`, `pdf_geometry.py`, `offline_layout.py`,
`local_recognition.py`, `local_worker.py`, `answer_choices.py`, `aligned_word.py`
and the app/template/static files must be copied. Do not replace only app.py.

For a fresh installation, use `SETUP_LOCAL_WINDOWS.bat` once. That first setup
needs internet to install pinned libraries and download local engine models.
Normal conversion is local CPU inference; no recognition API/key/cloud fallback.
Internet setup and models are not embedded in this small source-code ZIP.

## What was wrong and what changed

- **Compound centre divider:** the PDF stores both centre rules in a single
  drawing object about 14 points wide. Earlier code only accepted paths narrower
  than 2 points, missing the real divider. It then read the repeated RCC watermark
  between the rules as content and could infer false tables. The new code measures
  individual long vertical segments, detects the actual divider band and excludes
  only that measured band from column recognition crops.
- **Column reading order:** inferred crop boundaries and the later sorting divider
  could differ slightly. A left-column crop was then mistaken for a spanning
  heading, interleaving left/right questions. Sorting now retains the actual split.
- **Matching table rows:** explicitly headed Column I/II grids are reconstructed
  from original OCR line positions, not collapsed spacing chunks. A merged first
  A/1 row is separated using visible labels; blank/extra final rows are retained.
- **Answer-code widths:** compact A/B/C/D or 1/2/3/4/5 grids use actual inter-column
  spacing, not blank space extending to the whole crop edge. Word gets a dedicated
  narrow answer-number column, so its hanging indent cannot squeeze the first
  DATA cell (for example, Metaphase) into a few letters.
- **False tables:** aligned left margins alone no longer count as table evidence.
  All column anchors and actual labels/headers are checked.
- **Paragraphs and answers:** Roman statements retain separate source line starts;
  complete whole-answer grids become four ordered answer paragraphs. Mixed text
  answers plus a final two-cell (3)/(4) row are also separated. Matching-body labels
  and multi-value answer-code grids are not renumbered or flattened.
- **Image answers:** four recognised labels next to four real answer pictures stay
  paired and ordered 1–4; their labels and images share Word answer paragraphs.
  The question's own diagram remains separate. No question text is rasterised.
- **Whole-question table:** a clear source question stem absorbed into leading
  full-width table rows is moved outside the grid, preserving its wording.
- **Malformed table array text:** when a table model emits a whole LaTeX array
  inside one table cell, a verified source-geometry grid replaces that broken
  structure. Supported native equations elsewhere remain untouched.
- **Simple arrow-code answers:** complete high-confidence 1–4 sequences such as
  P → Q → S are retained as literal editable text in answer order when a formula
  model instead merged/reordered them as an array. No missing labels are invented.
- **Low RAM:** serial regions, OCR batch size one, and a bounded 512-pixel profile
  for the dynamic-shape ruled-table model. Same models/weights; no extra download.

## Verified on your PDF

Actual upload/local recognition/Word export, not a manually transcribed mock:

- Page-1 one-box Q1–Q5 still gives five questions and one real cell-cycle diagram.
- Source pages 3–4 give Q11–Q26 in correct column order, five editable tables,
  one genuine graph, 16 native numbered question leads and no forced breaks.
- Q17's Column I/II body, A–D code grid and final 5. Diplotene row were checked.
  Q22's I/II/III/IV statements are separate body paragraphs, not a narrow table.
- Question areas on all eight pages gave **57 selected question records**, with
  per-page counts **5, 5, 8, 8, 6, 5, 13, 7**. Answer-key tables were not selected.
  The supplied PDF's printed numbering has gaps/restarts across sections; the
  combined sample uses new continuous Word numbers 1–57. This is not a claim that
  the source itself contains printed questions 1–57 consecutively.
- The actual DOCX was rendered with LibreOffice Writer+Math and visually inspected.
  The six-page combined sample is editable Word reflow, NOT source pagination.
- Regression checks cover Questions/Solutions/Boss Mode, pointer selections,
  numbering/fonts/columns, linked solutions, native math, rotation and cancellation.

See `VALIDATION.md` for evidence and limits. Examples include the screenshot's
later-page questions and the full selected-question output with PDF renderings.

## Questions — existing selections retained

1. Open your PDF. Choose **Questions** in Selection category.
2. Drag one box around one or several COMPLETE questions, including their main
   numbers and complete answers. You can span both source columns; left column
   reads top-to-bottom before the right. Use Prev/Next to add other pages.
3. Choose Questions Word columns **Auto / Single / Double**, font, size and
   **Starting question number** before Convert.
4. Click Convert. Check the detected count, optionally Review, then Download.

Avoid overlapping boxes: they duplicate content. Do not include publisher banners,
footers or answer keys unless wanted. On PDF pages 6 and 8, the question content
is on the left and answer keys on the right: select the left questions only.
Optional diagram/table boxes mark missed structures, not whole-question screenshots.
Questions/Solutions do not add a page-range/crop/header/footer workflow.

## Solutions — separate matching Word file

Choose Solutions, explicitly enter the corresponding **final Word question
number**, and draw its solution part. Select continuation parts on either column
or later pages under the same number, then finish the group. Solutions merge into
one heading per chosen final number and download as a separate document. Internal
step labels remain as source text; they do not become new questions. Linked
question numbering is locked in review to avoid silently breaking correspondence.

## Boss Mode — selected areas OR pages without boxes

Boss Mode creates its own unnumbered editable-flow Word document. Source numbers
and labels remain text; no additional question numbering or answer relabelling.

- **Selected areas:** choose Boss Mode → Selected areas, draw areas across pages,
  choose its independent Auto/Single/Double columns, then Convert.
- **Whole pages:** choose Boss Mode → Whole pages — no boxes needed. Select
  Current page, Specific pages (e.g. `1-3, 5`) or All pages, then Convert.
  Current page is the viewer page when Convert is clicked. Page scope exists
  **only in Boss Mode**, never in Questions or Solutions.

Switching categories retains their separate selections. Boss whole-page mode
ignores stored area boxes without deleting them. Switch back to Selected areas
to use them. Included categories download as separate Word files. One PDF per run.
Whole-page headers/footers remain body content. Tiles are processing units, not
forced Word pages. All modes use local CPU recognition and supported native math.

## Important limits

This fixes the verified geometry/table/flow bugs; it is **not a promise of perfect
OCR, scientific transcription or pixel-identical Word layout on every PDF**.
The samples are genuine automatic output, not manually corrected answers.
Q1 still recognises two cells as In/An instead of 1n/4n; Q14's G2/G1 can lose source
subscript styling, and some spellings/formula glyphs need review. Check against
the original before using an exam. No scientific/semantic answers are guessed.

Fonts and Microsoft Word may paginate differently from LibreOffice. Output flows
through the selected Word columns; it does not lock each source question to its
original page or position. Large fonts and long cells naturally wrap. A single
remaining question/option can continue into the next column/page, by design.

The earlier separate multiline-maths screenshot is not certified fixed by this
Biology test. Windows desktop Word and an actual Windows 8-GB machine were not
interactively benchmarked. Recognition ran in a Linux sandbox with about 2 GB RAM;
that is evidence of this test run, not a universal hardware-performance guarantee.
Selections are session-only: download before opening another PDF or restarting.
Reprocessing replaces optional review edits. Keep your source and review output.
