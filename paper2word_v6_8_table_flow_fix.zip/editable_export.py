"""Editable-first PDF region export. Not a mathematical OCR engine.

Native text stays text, with source emphasis and script positioning. Raster and
vector diagrams are embedded as pictures; scanned formula recognition is limited
by Tesseract. Word columns reflow and do not promise pixel-identical pagination.
"""
import io
import re
import shutil
from collections import Counter, defaultdict
from pathlib import Path

import pymupdf as fitz
import pytesseract
from PIL import Image
from docx.shared import Pt, Inches, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.section import WD_SECTION_START
from docx.enum.text import WD_ALIGN_PARAGRAPH

NEW_ITEM = re.compile(r"^(?:\d{1,3}[.)]\s*|Q\s*\d+\b|\([a-hA-HivxIVX]{1,4}\)\s*|[a-dA-D][.)]\s+)")


def warn(stats, message):
    if message not in stats['warnings']:
        stats['warnings'].append(message)


def configure_tesseract():
    """Find common Windows installations without needing a PATH edit."""
    if shutil.which('tesseract'):
        return
    import os
    candidates = [Path(os.environ.get('TESSERACT_CMD', ''))]
    for env, tail in [('ProgramFiles', 'Tesseract-OCR/tesseract.exe'),
                      ('LOCALAPPDATA', 'Programs/Tesseract-OCR/tesseract.exe'),
                      ('LOCALAPPDATA', 'Tesseract-OCR/tesseract.exe'),
                      ('ProgramFiles(x86)', 'Tesseract-OCR/tesseract.exe')]:
        if os.environ.get(env):
            candidates.append(Path(os.environ[env]) / tail)
    for candidate in candidates:
        if candidate.is_file():
            pytesseract.pytesseract.tesseract_cmd = str(candidate)
            return


def clean_text(s):
    # Retain Unicode science symbols and avoid XML-invalid control characters.
    return ''.join(c for c in s if c in '\t\n' or (ord(c) >= 32 and ord(c) not in (0xfffe, 0xffff)))


def intersection(a, b):
    r = fitz.Rect(a) & fitz.Rect(b)
    return r.get_area() if not r.is_empty else 0


def inside(a, b, fraction=.6):
    return intersection(a, b) >= fraction * max(fitz.Rect(a).get_area(), .01)


def column_split(page, clip=None):
    """Conservative source column detection from a central whitespace gutter."""
    clip = fitz.Rect(clip or page.rect)
    lines = [fitz.Rect(ln['bbox']) for b in page.get_text('dict', clip=clip)['blocks']
             if b.get('type') == 0 for ln in b.get('lines', [])
             if sum(len(s.get('text', '').strip()) for s in ln.get('spans', [])) >= 5]
    if len(lines) < 6:
        return None
    for ratio in (.5, .48, .52):
        mid = clip.x0 + ratio * clip.width
        gap = clip.width * .012
        left = [r for r in lines if r.x1 < mid + gap and r.x0 < mid - clip.width * .15]
        right = [r for r in lines if r.x0 > mid - gap and r.x1 > mid + clip.width * .15]
        crossing = [r for r in lines if r.x0 < mid - gap and r.x1 > mid + gap]
        if len(left) >= 3 and len(right) >= 3 and len(crossing) <= max(3, len(lines) * .15):
            lo, hi = min(r.y0 for r in left), max(r.y1 for r in left)
            if any(r.y1 > lo and r.y0 < hi for r in right):
                return mid
    return None


def reading_order(items, split):
    """Wide headings separate horizontal bands; read left then right per band."""
    if not split:
        return sorted(items, key=lambda e: (e['bbox'][1], e['bbox'][0]))
    spanning = sorted([e for e in items if e['bbox'][0] < split - 8 and e['bbox'][2] > split + 8],
                      key=lambda e: e['bbox'][1])
    remaining = [e for e in items if e not in spanning]
    ordered = []
    for wide in spanning:
        before = [e for e in remaining if e['bbox'][1] < wide['bbox'][1]]
        ordered += sorted(before, key=lambda e: (e['bbox'][0] >= split, e['bbox'][1], e['bbox'][0]))
        remaining = [e for e in remaining if e not in before]
        ordered.append(wide)
    return ordered + sorted(remaining, key=lambda e: (e['bbox'][0] >= split, e['bbox'][1], e['bbox'][0]))


class Writer:
    def __init__(self, doc, stats):
        self.doc, self.stats, self.columns = doc, stats, None
        sec = doc.sections[0]
        sec.page_width, sec.page_height = Inches(8.27), Inches(11.69)
        sec.top_margin = sec.bottom_margin = Inches(.6)
        sec.left_margin = sec.right_margin = Inches(.6)
        for name in ('Normal', 'Heading 1', 'Heading 2', 'Heading 3', 'Caption'):
            style = doc.styles[name]
            style.font.name = 'Cambria'
            style.font.size = Pt(11)
            style.font.color.rgb = RGBColor(0, 0, 0)
            style.paragraph_format.space_after = Pt(5)
            style.paragraph_format.line_spacing = 1.08
        self.width = 500

    def layout(self, n):
        n = int(n)
        if n == self.columns:
            return
        sec = self.doc.sections[0] if self.columns is None else self.doc.add_section(WD_SECTION_START.CONTINUOUS)
        cols = sec._sectPr.find(qn('w:cols'))
        if cols is None:
            cols = OxmlElement('w:cols')
            sec._sectPr.append(cols)
        for child in list(cols):
            cols.remove(child)
        cols.set(qn('w:num'), str(n))
        cols.set(qn('w:space'), '360')  # quarter-inch gutter
        cols.set(qn('w:equalWidth'), '1')
        self.columns = n
        self.width = ((sec.page_width - sec.left_margin - sec.right_margin) / 12700 - (18 if n == 2 else 0)) / n

    def text(self, lines, body_size, heading=False):
        p = self.doc.add_paragraph(style='Normal')
        p.paragraph_format.widow_control = True
        p.paragraph_format.keep_together = True
        if heading:
            p.paragraph_format.keep_with_next = True
            p.paragraph_format.space_before = Pt(6)
        previous = ''
        for i, line in enumerate(lines):
            if i and previous and not previous.endswith((' ', '\u00ad')):
                p.add_run(' ')
            spans = line['spans']
            base_span = max(spans, key=lambda s: (s.get('size', body_size), len(s.get('text', ''))))
            baseline = base_span.get('origin', (0, line['bbox'][3]))[1]
            base_size = base_span.get('size', body_size)
            for s in spans:
                text = clean_text(s.get('text', '')).replace('\u00ad', '')
                if not text:
                    continue
                if '\ufffd' in text or any(0xe000 <= ord(c) <= 0xf8ff for c in text):
                    warn(self.stats, 'Some PDF characters have missing or custom font mappings. Check scientific symbols against the original.')
                run = p.add_run(text)
                run.font.name = 'Cambria'
                run.font.color.rgb = RGBColor(0, 0, 0)
                flags, font = s.get('flags', 0), s.get('font', '').lower()
                run.bold = heading or bool(flags & 16) or 'bold' in font
                run.italic = bool(flags & 2) or 'italic' in font or 'oblique' in font
                size = s.get('size', body_size)
                output_size = max(8, min(16, 11 * size / max(body_size, 1)))
                script = size < base_size * .88
                y = s.get('origin', (0, baseline))[1]
                if flags & 1 or (script and y < baseline - base_size * .12):
                    run.font.superscript = True
                    output_size = 11
                elif script and y > baseline + base_size * .08:
                    run.font.subscript = True
                    output_size = 11
                run.font.size = Pt(output_size)
                if not run.font.superscript and not run.font.subscript and abs(y - baseline) > base_size * .15:
                    # Retain native baseline shifts missed by a font flag.
                    position = OxmlElement('w:position')
                    position.set(qn('w:val'), str(round(2 * (baseline - y) * 11 / max(body_size, 1))))
                    run._element.get_or_add_rPr().append(position)
            previous = ''.join(s.get('text', '') for s in spans).rstrip()
        if heading:
            p.paragraph_format.space_after = Pt(5)
        self.stats['paragraphs'] += 1
        self.stats['words'] += len(p.text.split())

    def picture(self, page, rect):
        rect = fitz.Rect(rect) & page.rect
        if rect.is_empty:
            return
        pix = page.get_pixmap(dpi=220, clip=rect, alpha=False)
        p = self.doc.add_paragraph()
        p.alignment = WD_ALIGN_PARAGRAPH.CENTER
        p.add_run().add_picture(io.BytesIO(pix.tobytes('png')), width=Pt(min(rect.width, self.width)))
        self.stats['diagrams'] += 1

    def table(self, rows):
        if not rows:
            return
        n = max(len(r) for r in rows)
        table = self.doc.add_table(rows=0, cols=n)
        table.style = 'Table Grid'
        table.autofit = False
        for column in table.columns:
            column.width = Pt(self.width / n)
        for values in rows:
            cells = table.add_row().cells
            for i, value in enumerate(values):
                cells[i].width = Pt(self.width / n)
                cells[i].text = clean_text(str(value or '')).replace('\n', ' ')
                for p in cells[i].paragraphs:
                    for r in p.runs:
                        r.font.color.rgb = RGBColor(0, 0, 0)
                        r.font.size = Pt(10)
        self.stats['tables'] += 1


def _diagram_regions(page, clip, tables):
    candidates = []
    for im in page.get_image_info():
        r = fitz.Rect(im['bbox']) & clip
        # A page-sized scanned background must never replace the editable page.
        if not r.is_empty and r.width > 15 and r.height > 15 and r.get_area() < .8 * clip.get_area():
            candidates.append(r)
    # Cluster vector strokes (circuits, graphs, geometry, chemical structures).
    drawings = []
    for drawing in page.get_drawings():
        r = fitz.Rect(drawing['rect'])
        if not inside(r, clip, .95) or any(inside(r, t, .6) for t in tables):
            continue
        if r.width > clip.width * .9 and r.height > clip.height * .8:
            continue
        if max(r.width, r.height) < 2:
            continue
        drawings.append(r + (-2, -2, 2, 2))
    while drawings:
        group = drawings.pop(0)
        changed = True
        while changed:
            changed = False
            for r in drawings[:]:
                if (group + (-7, -7, 7, 7)).intersects(r):
                    group |= r
                    drawings.remove(r)
                    changed = True
        if group.width >= 24 and group.height >= 20:
            candidates.append((group + (-5, -5, 5, 5)) & clip)
    # Merge intersecting image/vector regions and remove table regions.
    merged = []
    for r in candidates:
        if any(inside(r, t, .5) for t in tables):
            continue
        for old in merged:
            if old.intersects(r):
                old |= r
                break
        else:
            merged.append(fitz.Rect(r))
    return merged


def native_elements(page, clip, stats):
    table_elements, table_rects = [], []
    try:
        for t in page.find_tables(clip=clip).tables:
            r = fitz.Rect(t.bbox)
            rows = t.extract()
            if len(rows) < 2 or max((len(row) for row in rows), default=0) < 2:
                continue
            if not any(str(c or '').strip() for row in rows for c in row):
                continue
            table_rects.append(r)
            table_elements.append({'type': 'table', 'bbox': tuple(r), 'rows': rows})
    except Exception:
        warn(stats, 'Table detection could not complete in one region; inspect its text layout.')
    diagrams = _diagram_regions(page, clip, table_rects)
    elements = table_elements + [{'type': 'image', 'bbox': tuple(r)} for r in diagrams]
    weights = Counter()
    # Full-page baseline avoids mistaking a selected title for body text.
    for block in page.get_text('dict')['blocks']:
        if block.get('type') != 0:
            continue
        for line in block.get('lines', []):
            for span in line.get('spans', []):
                weights[round(span.get('size', 11), 1)] += len(span.get('text', '').strip())
    body = weights.most_common(1)[0][0] if weights else 11
    for block in page.get_text('dict', clip=clip)['blocks']:
        if block.get('type') != 0:
            continue
        for line in block.get('lines', []):
            # Exclude words already represented in a diagram or real table.
            spans = [s for s in line.get('spans', []) if s.get('text', '')
                     and not any(inside(s['bbox'], r, .65) for r in table_rects + diagrams)]
            if spans:
                rect = fitz.Rect(spans[0]['bbox'])
                for s in spans[1:]:
                    rect |= fitz.Rect(s['bbox'])
                elements.append({'type': 'line', 'bbox': tuple(rect), 'spans': spans, 'block': block['number']})
    return elements, body


def emit_elements(writer, page, elements, body, split=None):
    pending, last, last_heading = [], None, False
    def flush():
        nonlocal pending
        if pending:
            writer.text(pending, body, last_heading)
            pending = []
    for e in reading_order(elements, split):
        if e['type'] != 'line':
            flush()
            if e['type'] == 'image':
                writer.picture(page, e['bbox'])
            else:
                writer.table(e['rows'])
            last = None
            continue
        text = ''.join(s.get('text', '') for s in e['spans']).strip()
        # Font sizes alone are not enough for equations: short, large body
        # expressions should remain editable text, not coloured Word headings.
        size = max(s.get('size', body) for s in e['spans'])
        heading = size >= body * 1.2 and len(text) < 140
        new_para = last is None or heading != last_heading or NEW_ITEM.match(text)
        if last is not None:
            r, prev = fitz.Rect(e['bbox']), fitz.Rect(last['bbox'])
            height = max(body, prev.height)
            if r.y0 - prev.y1 > height * .9 or r.y0 < prev.y0 - height * .5:
                new_para = True
            if split and (r.x0 >= split) != (prev.x0 >= split):
                new_para = True
        if new_para:
            flush()
        pending.append(e)
        last, last_heading = e, heading
    flush()


def export_native(writer, page, clip):
    elements, body = native_elements(page, clip, writer.stats)
    emit_elements(writer, page, elements, body, column_split(page, clip))


def ocr_elements(page, clip, stats):
    configure_tesseract()
    pix = page.get_pixmap(dpi=260, clip=clip, alpha=False)
    image = Image.frombytes('RGB', (pix.width, pix.height), pix.samples)
    try:
        # Tesseract's layout segmentation avoids concatenating left/right text
        # into one line. Do not binarize aggressively or discard low-confidence
        # punctuation, which previously deleted scientific symbols.
        psm = 6 if clip.width < page.rect.width * .7 else 3
        data = pytesseract.image_to_data(image, config=f'--psm {psm}', output_type=pytesseract.Output.DICT)
    except pytesseract.TesseractNotFoundError as exc:
        raise RuntimeError('Tesseract OCR is not installed or cannot be found. Install Tesseract for Windows, then restart the app.') from exc
    groups = defaultdict(list)
    low = 0
    for i, word in enumerate(data['text']):
        word = (word or '').strip()
        if not word:
            continue
        conf = float(data['conf'][i])
        if conf < 0:
            continue
        if conf < 65:
            low += 1
        key = (data['block_num'][i], data['par_num'][i], data['line_num'][i])
        groups[key].append(i)
    scale_x, scale_y = clip.width / pix.width, clip.height / pix.height
    elements = []
    for key, indices in groups.items():
        indices.sort(key=lambda i: data['left'][i])
        x0 = min(data['left'][i] for i in indices)
        y0 = min(data['top'][i] for i in indices)
        x1 = max(data['left'][i] + data['width'][i] for i in indices)
        y1 = max(data['top'][i] + data['height'][i] for i in indices)
        rect = (clip.x0 + x0 * scale_x, clip.y0 + y0 * scale_y, clip.x0 + x1 * scale_x, clip.y0 + y1 * scale_y)
        text = ' '.join(data['text'][i].strip() for i in indices)
        elements.append({'type': 'line', 'bbox': rect, 'block': key[0],
                         'spans': [{'text': text, 'size': 11, 'flags': 0, 'bbox': rect}]})
    if low:
        stats['low_confidence_words'] += low
    warn(stats, 'Scanned text used ordinary OCR. Verify maths, Greek letters, charges, subscripts and superscripts; editable Word equations are not reconstructed.')
    warn(stats, 'Diagrams embedded in scanned page images are not automatically isolated reliably. Compare with the original PDF.')
    if not elements:
        warn(stats, 'One selected scanned region produced no readable text. It may be a diagram or equation only.')
    return elements


def export_scanned(writer, page, clip, elements=None):
    elements = elements if elements is not None else ocr_elements(page, clip, writer.stats)
    # OCR blocks carry column segmentation. Infer a gutter from their bounds.
    mid = clip.x0 + clip.width / 2
    left = sum(e['bbox'][2] < mid + 3 for e in elements)
    right = sum(e['bbox'][0] > mid - 3 for e in elements)
    split = mid if left >= 3 and right >= 3 else None
    emit_elements(writer, page, elements, 11, split)
    return split
