@echo off
setlocal
cd /d "%~dp0"
title Paper2Word 6.8 - Simple Local
set "MINERU_HOME=%~dp0model_data"
set "MINERU_TELEMETRY_DISABLED=1"
set "HF_HUB_DISABLE_TELEMETRY=1"
set "MINERU_MODEL_SMALL_BACKEND=onnx"
set "MINERU_MODEL_ONNX_DEVICE=cpu"
if not exist "app.py" goto :missing
if not exist "launch.py" goto :missing
if not exist "matching_geometry.py" goto :missing
if not exist "pdf_geometry.py" goto :missing
if not exist "venv_local\Scripts\python.exe" goto :setup_needed
"venv_local\Scripts\python.exe" launch.py
if errorlevel 1 goto :failed
exit /b 0
:setup_needed
echo First run: double-click SETUP_LOCAL_WINDOWS.bat once.
echo Normal starting does not install libraries or download models.
pause
exit /b 1
:missing
echo Extract ALL files from the ZIP before starting.
:failed
echo Read the message above. If libraries are missing, run SETUP_LOCAL_WINDOWS.bat.
pause
exit /b 1
