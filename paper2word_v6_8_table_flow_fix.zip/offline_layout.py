"""Offline, reviewable question-block recognition and native Word reconstruction.

No network calls. OCR results are deliberately exposed for correction rather
than described as exact. Pictures are retained pictures; entered LaTeX becomes
native Word OMML. This is not an automatic specialist mathematical OCR model.
"""
import io
import json
import math
import re
import statistics
from collections import defaultdict
from pathlib import Path

import pymupdf as fitz
import pytesseract
from PIL import Image, ImageDraw
from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml import OxmlElement, parse_xml
from docx.oxml.ns import qn
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.section import WD_SECTION_START
from editable_export import configure_tesseract, column_split, reading_order

FONT = 'Roboto Condensed'
SUB = str.maketrans('0123456789+-=()', '₀₁₂₃₄₅₆₇₈₉₊₋₌₍₎')
SUPER = str.maketrans('0123456789+-=()', '⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻⁼⁽⁾')
UNSUB = {chr(v): chr(k) for k, v in SUB.items()}
UNSUPER = {chr(v): chr(k) for k, v in SUPER.items()}
QUESTION = re.compile(r'^\s*\d{1,3}[.]\s*')
NEWPARA = re.compile(r'^\s*(?:\d{1,3}[.]\s*|\([1-9a-hA-HivxIVX]{1,4}\)|Statement\s+[IVX]+\b|Identify\b|Here\b|Select\b)')
MATHNS = 'http://schemas.openxmlformats.org/officeDocument/2006/math'


def rect(region, page):
    w, h = page.rect.width, page.rect.height
    return fitz.Rect(region['x']*w, region['y']*h, (region['x']+region['w'])*w, (region['y']+region['h'])*h) & page.rect


def contained(a, b, fraction=.85):
    a, b = fitz.Rect(a), fitz.Rect(b)
    return (a & b).get_area() >= a.get_area()*fraction if a.get_area() else False


def normalize_science(text):
    # Conservative, visible in the review editor. No spelling or factual fixes.
    text = re.sub(r'\b(CO|H|O|C|NH|CH)([2346])\b', lambda m: m[1]+m[2].translate(SUB), text)
    text = re.sub(r'\bH\+(?=\s|$|[,.)])', 'H⁺', text)
    return text


def glyph_text(span, baseline=None, size=None):
    text = span.get('text','')
    s = span.get('size',11)
    y = span.get('origin',(0,baseline or 0))[1]
    if span.get('flags',0)&1 or (baseline is not None and size and s < size*.88 and y < baseline-size*.12):
        return text.translate(SUPER)
    if baseline is not None and size and s < size*.88 and y > baseline+size*.08:
        return text.translate(SUB)
    return text


def local_words(page, clip, images, job):
    """Return text with page-coordinate boxes, using native text when possible."""
    words = []
    native = page.get_text('dict', clip=clip)
    native_chars = sum(len(s.get('text','').strip()) for b in native['blocks'] if b.get('type')==0
                       for ln in b.get('lines',[]) for s in ln.get('spans',[]))
    if native_chars >= 12:
        for b in native['blocks']:
            if b.get('type') != 0:
                continue
            for ln in b.get('lines',[]):
                spans = ln.get('spans',[])
                if not spans:
                    continue
                base=max(spans,key=lambda s:s.get('size',0))
                for s in spans:
                    if any(contained(s['bbox'], r, .5) for r in images):
                        continue
                    # Character boxes provide accurate gaps without losing
                    # native superscripts/subscripts or Unicode symbols.
                raw = page.get_text('rawdict',clip=fitz.Rect(ln['bbox']))
                # Use native words for geometry and native line spans for
                # scripts. Match character extents to each word box.
                for w in page.get_text('words',clip=fitz.Rect(ln['bbox'])):
                    r=fitz.Rect(w[:4])
                    if any(contained(r, pic, .5) for pic in images):
                        continue
                    parts=[]
                    for sb in raw['blocks']:
                        if sb.get('type')!=0:continue
                        for sl in sb.get('lines',[]):
                            for sp in sl.get('spans',[]):
                                chars=[c for c in sp.get('chars',[]) if r.x0-.5 <= (c['bbox'][0]+c['bbox'][2])/2 <= r.x1+.5]
                                if chars:
                                    cp=dict(sp);cp['text']=''.join(c['c'] for c in chars)
                                    parts.append(glyph_text(cp,base.get('origin',(0,0))[1],base.get('size',11)))
                    text=''.join(parts).strip() or w[4]
                    words.append({'text':text,'bbox':list(r),'conf':100})
        # Native clipped word extraction may visit overlapping lines twice.
        unique={ (tuple(round(x,2) for x in w['bbox']), w['text']): w for w in words }
        return list(unique.values()), 'native'
    configure_tesseract()
    pix=page.get_pixmap(dpi=300,clip=clip,alpha=False)
    img=Image.frombytes('RGB',(pix.width,pix.height),pix.samples)
    draw=ImageDraw.Draw(img)
    sx,sy=pix.width/clip.width,pix.height/clip.height
    for r in images:
        rr=fitz.Rect(r)&clip
        if not rr.is_empty:
            draw.rectangle(((rr.x0-clip.x0)*sx-2,(rr.y0-clip.y0)*sy-2,(rr.x1-clip.x0)*sx+2,(rr.y1-clip.y0)*sy+2),fill='white')
    job['stage']='Reading selected question locally with Tesseract…'
    try:
        data=pytesseract.image_to_data(img,config='--psm 6 -c preserve_interword_spaces=1',output_type=pytesseract.Output.DICT)
    except pytesseract.TesseractNotFoundError as exc:
        raise RuntimeError('Tesseract is required for scanned/outlined PDFs. Install it locally and restart. Common Windows installation folders are detected automatically.') from exc
    for i,t in enumerate(data['text']):
        if not t.strip():continue
        conf=float(data['conf'][i])
        if conf<0:continue
        x,y,w,h=(data[k][i] for k in ('left','top','width','height'))
        r=[clip.x0+x/sx,clip.y0+y/sy,clip.x0+(x+w)/sx,clip.y0+(y+h)/sy]
        if any(contained(r, p, .5) for p in images):continue
        words.append({'text':normalize_science(t.strip()),'bbox':r,'conf':round(conf,1)})
    return words,'ocr'


def word_lines(words):
    if not words:return []
    med=statistics.median(w['bbox'][3]-w['bbox'][1] for w in words)
    groups=[]
    for word in sorted(words,key=lambda w:((w['bbox'][1]+w['bbox'][3])/2,w['bbox'][0])):
        cy=(word['bbox'][1]+word['bbox'][3])/2
        eligible=[g for g in groups[-3:] if abs(g['cy']-cy)<max(2.5,med*.48)]
        if eligible:
            g=min(eligible,key=lambda g:abs(g['cy']-cy));g['words'].append(word)
            g['cy']=sum((x['bbox'][1]+x['bbox'][3])/2 for x in g['words'])/len(g['words'])
        else:groups.append({'cy':cy,'words':[word]})
    lines=[]
    for g in sorted(groups,key=lambda g:g['cy']):
        ws=sorted(g['words'],key=lambda w:w['bbox'][0]);chunks=[]
        for w in ws:
            # 10pt or a little over a typical word space identifies option
            # grids. Stable row geometry below distinguishes these from prose.
            gap=w['bbox'][0]-chunks[-1]['bbox'][2] if chunks else 0
            if not chunks or gap>max(9,med*1.12):
                chunks.append({'text':w['text'],'bbox':list(w['bbox'])})
            else:
                c=chunks[-1];c['text']+=' '+w['text'];c['bbox'][2]=w['bbox'][2];c['bbox'][1]=min(c['bbox'][1],w['bbox'][1]);c['bbox'][3]=max(c['bbox'][3],w['bbox'][3])
        r=[min(w['bbox'][0] for w in ws),min(w['bbox'][1] for w in ws),max(w['bbox'][2] for w in ws),max(w['bbox'][3] for w in ws)]
        text=' '.join(w['text'] for w in ws)
        # A separated printed question number is not a two-column table.
        if len(chunks)>1 and re.fullmatch(r'\d{1,3}[.]',chunks[0]['text']):
            chunks[1]['text']=chunks[0]['text']+' '+chunks[1]['text'];chunks[1]['bbox'][0]=chunks[0]['bbox'][0];chunks.pop(0)
        lines.append({'bbox':r,'text':text,'chunks':chunks,'confidence':min(w['conf'] for w in ws),'words':ws})
    return lines


def source_gutter(page):
    """Find actual long central rules, including compound filled outlines.

    A publisher may store two rules in ONE path with a 14pt union rectangle.
    Testing only the path rectangle width (<2pt) misses both real rules.
    """
    xs=[];bounds=page.rect
    for drawing in page.get_drawings():
        r=fitz.Rect(drawing['rect'])
        if r.width>bounds.width*.05 or r.height<bounds.height*.4:continue
        if abs((r.x0+r.x1)/2-bounds.width/2)>bounds.width*.08:continue
        for part in drawing.get('items',[]):
            if part[0]=='l':
                a,b=part[1:3]
                if abs(a.x-b.x)<1 and abs(a.y-b.y)>bounds.height*.4:xs.append((a.x+b.x)/2)
            elif part[0]=='re':
                box=fitz.Rect(part[1])
                if box.width<2 and box.height>bounds.height*.4:xs.extend([box.x0,box.x1])
    if not xs or max(xs)-min(xs)>bounds.width*.05:return None
    return min(xs),max(xs)


def source_columns(page):
    native=column_split(page)
    if native:return 2,native
    gutter=source_gutter(page)
    if gutter:return 2,sum(gutter)/2
    return 1,None


def diagram_regions(page, clip, explicit):
    pictures=[fitz.Rect(r) for r in explicit]
    for info in page.get_image_info():
        r=fitz.Rect(info['bbox'])&clip
        if not r.is_empty and r.width>15 and r.height>15 and r.get_area()<clip.get_area()*.85:
            if not any(contained(r,p,.7) for p in pictures):pictures.append(r)
    # Vector drawings, but never cluster glyph outlines or a page background.
    paths=[]
    for d in page.get_drawings():
        r=fitz.Rect(d['rect'])
        if not contained(r,clip,.98) or r.get_area()>clip.get_area()*.8:continue
        if max(r.width,r.height)<20:continue
        if r.height<1 and r.width>clip.width*.8:continue
        if r.width<1 and r.height>clip.height*.8:continue
        paths.append(r+(-2,-2,2,2))
    while paths:
        group=paths.pop(0);again=True
        while again:
            again=False
            for r in paths[:]:
                if (group+(-8,-8,8,8)).intersects(r):group|=r;paths.remove(r);again=True
        if group.width>28 and group.height>28 and not any(contained(group,p,.6) for p in pictures):
            pictures.append((group+(-5,-5,5,5))&clip)
    return pictures


def make_table(lines, clip, manual=False):
    candidates=[ln for ln in lines if len(ln['chunks'])>=2]
    if not candidates:
        return {'type':'table','rows':[[ln['text']] for ln in lines] or [['',''],['','']], 'widths':[1], 'border':manual,'indent':0}
    first=next((ln for ln in candidates if re.match(r'^\(?[1-9]\)',ln['text'])),candidates[0])
    header=candidates[0]
    centered=(len(header['chunks'])>=3 and all(re.fullmatch(r'[A-Z1-9]',c['text'].strip()) for c in header['chunks'])) or (len(header['chunks'])>len(first['chunks']) and all(len(c['text'])<15 for c in header['chunks']))
    if centered:
        centers=[(c['bbox'][0]+c['bbox'][2])/2 for c in header['chunks']]
        anchors=[[] for _ in centers];assigned=[]
        for ln in lines:
            cells=['']*len(centers);used=0
            for word in ln.get('words',ln['chunks']):
                # Tiny low-confidence punctuation between cells is a common
                # Tesseract artefact, not a missing mathematical operator.
                if word.get('conf',100)<40 and re.fullmatch(r'[—_=]+',word['text']):continue
                x=(word['bbox'][0]+word['bbox'][2])/2
                col=min(range(len(centers)),key=lambda i:abs(x-centers[i]))
                cells[col]+=(' ' if cells[col] else '')+word['text'];used|=1<<col
                anchors[col].append(word['bbox'][0])
            assigned.append((ln,cells,used))
        positions=[min(a) if a else clip.x0 for a in anchors]
        rows=[]
        for ln,cells,used in assigned:
            if len(ln['chunks'])==1 and rows and not NEWPARA.match(ln['text']):
                for i,text in enumerate(cells):
                    if text:rows[-1][i]+='\n'+text
            else:rows.append(cells)
        widths=[max(15,(positions[i+1] if i+1<len(positions) else x+statistics.median([b-a for a,b in zip(positions,positions[1:])] or [30]))-x) for i,x in enumerate(positions)]
        return {'type':'table','rows':rows,'widths':widths,'border':manual,'indent':max(0,positions[0]-clip.x0),'header_center':True}
    anchors=[c['bbox'][0] for c in first['chunks']][:8]
    rows=[]
    for ln in lines:
        cells=['']*len(anchors)
        for chunk in ln['chunks']:
            x=chunk['bbox'][0]
            col=max([i for i,a in enumerate(anchors) if x>=a-4] or [0])
            cells[col]+=(' ' if cells[col] else '')+chunk['text']
        continuation=len(ln['chunks'])==1 and rows and not NEWPARA.match(ln['text'])
        if continuation:
            for i,text in enumerate(cells):
                if text:rows[-1][i]+='\n'+text
        else:rows.append(cells)
    widths=[max(15,(anchors[i+1] if i+1<len(anchors) else a+statistics.median([y-x for x,y in zip(anchors,anchors[1:])] or [30]))-a) for i,a in enumerate(anchors)]
    return {'type':'table','rows':rows,'widths':widths,'border':manual,'indent':max(0,anchors[0]-clip.x0)}


def compile_items(lines, clip, pictures, tables):
    """Detect aligned option/matching rows and coherent text paragraphs."""
    events=[]
    for r,asset in pictures:events.append({'y':r.y0,'type':'image','asset':asset,'width':r.width,'height':r.height,'indent':max(0,r.x0-clip.x0)})
    for r in tables:
        group=[ln for ln in lines if contained(ln['bbox'],r,.5)]
        events.append({'y':r.y0,**make_table(group,r,manual=True),'indent':max(0,r.x0-clip.x0)})
    lines=[ln for ln in lines if not any(contained(ln['bbox'],r,.5) for r in tables)]
    i=0
    while i<len(lines):
        ln=lines[i];chunks=ln['chunks']
        # Avoid treating ordinary justified prose with one large space as a
        # table: require a numbered option or compatible multi-column rows.
        is_grid=len(chunks)>=2 and not QUESTION.match(ln['text'])
        stable=False
        if is_grid and i+1<len(lines):
            nxt=lines[i+1]
            # Matching starts at the LEFT edge alone prove nothing: justified
            # prose shares that edge too. Require ALL column anchors and an
            # actual row label/header before inferring an unruled table.
            labelled=bool(re.match(r'^\s*(?:\(?[A-Za-z0-9ivxIVX]{1,6}[.)]|Column\b)',chunks[0]['text']))
            stable=labelled and len(nxt['chunks'])==len(chunks) and all(abs(a['bbox'][0]-b['bbox'][0])<max(6,clip.width*.025) for a,b in zip(chunks,nxt['chunks']))
        header_grid=is_grid and len(chunks)>=3 and all(re.fullmatch(r'\(?[A-Z1-9ivx]{1,4}\)?[.)]?',c['text'].strip()) for c in chunks)
        matching_row=is_grid and re.match(r'^\(?[1-9]\)',chunks[0]['text']) and len(chunks[0]['text'].split())<=5 and all(len(c['text'])<30 for c in chunks[1:]) and stable
        option_grid=is_grid and sum(bool(re.match(r'^\(?[1-9a-dA-D]\)',c['text'])) for c in chunks)>=2
        if is_grid and (stable or option_grid or header_grid or matching_row):
            group=[ln];n=len(chunks);j=i+1
            while j<len(lines):
                cur=lines[j];prev=lines[j-1]
                if QUESTION.match(cur['text']) or cur['bbox'][1]-prev['bbox'][3]>18:break
                if any(prev['bbox'][3]<r.y0<cur['bbox'][1] for r,_ in pictures):break
                if len(cur['chunks'])>=2 and len(cur['chunks'])!=n and not (header_grid and len(cur['chunks'])<n):break
                if len(cur['chunks'])==1 and NEWPARA.match(cur['text']):break
                if len(cur['chunks'])==1 and cur['bbox'][0]<chunks[0]['bbox'][0]-4 and not header_grid:break
                group.append(cur);j+=1
                # An options-only row followed by normal prose is not a table
                # spanning the next question's stem.
                if option_grid and (j>=len(lines) or len(lines[j]['chunks'])<2):break
            events.append({'y':ln['bbox'][1],**make_table(group,clip)})
            i=j;continue
        # Group source-wrapped lines into one editable paragraph, preserving
        # their wrapping by default; the review screen can turn that off.
        group=[ln];j=i+1
        while j<len(lines):
            nxt=lines[j];prev=lines[j-1]
            if NEWPARA.match(nxt['text']) or len(nxt['chunks'])>1 or nxt['bbox'][1]-prev['bbox'][3]>9:break
            if any(prev['bbox'][3]<r.y0<nxt['bbox'][1] for r,_ in pictures):break
            if any(prev['bbox'][3]<r.y0<nxt['bbox'][1] for r in tables):break
            group.append(nxt);j+=1
        events.append({'y':ln['bbox'][1],'type':'text','text':'\n'.join(g['text'] for g in group),
                       'indent':max(0,ln['bbox'][0]-clip.x0),'bold':False,
                       'confidence':round(min(g['confidence'] for g in group),1)})
        i=j
    return sorted(events,key=lambda e:e['y'])


def analyze(job, selections, pages, output_columns):
    folder=Path(job['dir']);assets=folder/'assets';assets.mkdir(exist_ok=True)
    model={'version':3,'title':Path(job['filename']).stem,'output_columns':output_columns,
           'font_size':10.5,'keep_wrap':True,'separator':True,'preserve_source_columns':True,'questions':[],
           'warnings':['Offline OCR is not specialist math recognition. Check scientific symbols and all low-confidence text against each source crop.',
                       'Diagrams are pictures. Native Word equations are generated from LaTeX that you enter or confirm in review.',
                       'Word layout is reconstructed, not pixel-identical. Automatic table and diagram detection can need correction.']}
    regions={int(p):rs for p,rs in selections.items() if rs}
    with fitz.open(folder/'source.pdf') as pdf:
        tasks=[]
        for pno in sorted(regions) if regions else pages:
            pg=pdf[pno-1];ncols,split=source_columns(pg)
            selected=regions.get(pno,[])
            mains=[r for r in selected if r.get('kind','text')=='text']
            children=[r for r in selected if r.get('kind','text')!='text']
            if not selected:
                # Whole paper fallback, one source column per block. Draw
                # individual question boxes for better OCR segmentation.
                w,h=pg.rect.width,pg.rect.height
                bounds=[fitz.Rect(w*.05,h*.10,split-3,h*.92),fitz.Rect(split+3,h*.10,w*.95,h*.92)] if split else [fitz.Rect(w*.05,h*.10,w*.95,h*.92)]
                mains=[{'x':r.x0/w,'y':r.y0/h,'w':r.width/w,'h':r.height/h,'kind':'text'} for r in bounds]
            for child in children:
                cr=rect(child,pg)
                if not any(contained(cr,rect(q,pg),.7) for q in mains):
                    mains.append(child)
            for q in reading_order([{'bbox':list(rect(r,pg)),'region':r} for r in mains],split):
                tasks.append((pno,ncols,q['region'],children))
        for index,(pno,ncols,region,children) in enumerate(tasks):
            job['progress']=int(85*index/max(1,len(tasks)))
            job['stage']=f'Analyzing selected block {index+1}/{len(tasks)} on page {pno}'
            pg=pdf[pno-1];clip=rect(region,pg);qid=f'q{index+1}'
            preview=qid+'_source.jpg'
            pg.get_pixmap(dpi=155,clip=clip,alpha=False).save(assets/preview)
            explicit_diagrams=[rect(r,pg) for r in children if r.get('kind')=='diagram' and contained(rect(r,pg),clip,.7)]
            explicit_tables=[rect(r,pg) for r in children if r.get('kind')=='table' and contained(rect(r,pg),clip,.7)]
            if region.get('kind')=='diagram':explicit_diagrams=[clip]
            if region.get('kind')=='table':explicit_tables=[clip]
            # Native ruled tables should remain editable tables, not become
            # vector-diagram pictures. Outlined pages use OCR geometry instead.
            if len(pg.get_text().strip()) >= 25:
                try:
                    for table in pg.find_tables(clip=clip).tables:
                        tr=fitz.Rect(table.bbox)
                        if table.row_count>=2 and table.col_count>=2 and not any(contained(tr,t,.8) for t in explicit_tables):explicit_tables.append(tr)
                except Exception:
                    pass
            pics=diagram_regions(pg,clip,explicit_diagrams)
            pics=[r for r in pics if not any(contained(r,t,.6) for t in explicit_tables)]
            picture_events=[]
            for j,r in enumerate(pics):
                asset=f'{qid}_diagram{j+1}.png'
                pg.get_pixmap(dpi=250,clip=r,alpha=False).save(assets/asset)
                picture_events.append((r,asset))
            words,engine=local_words(pg,clip,pics,job) if region.get('kind')!='diagram' else ([], 'picture')
            lines=word_lines(words)
            items=compile_items(lines,clip,picture_events,explicit_tables)
            if not items:
                items=[{'type':'text','text':'','indent':0,'confidence':0,'bold':False}]
            model['questions'].append({'id':qid,'page':pno,'source_columns':ncols,
                 'source_width':clip.width,'source_height':clip.height,'source_asset':preview,
                 'source_column':int((clip.x0+clip.x1)/2>pg.rect.width/2) if ncols==2 else 0,
                 'engine':engine,'items':items,'warnings':[] if words else ['No editable text recognised in this block. Add/correct text in review.']})
    if not model['questions']:raise ValueError('No question blocks to process.')
    return model


def equation_xml(latex):
    if not isinstance(latex,str) or not latex.strip() or len(latex)>4000:
        raise ValueError('Enter a non-empty LaTeX equation (maximum 4000 characters).')
    from latex2mathml.converter import convert
    import mathml2omml
    mathml=convert(latex)
    omml=mathml2omml.convert(mathml)
    math=parse_xml(f'<root xmlns:m="{MATHNS}">{omml}</root>')[0]
    # A standalone ionic charge is a literal sign, not an incomplete unary
    # operation. The flag avoids placeholder glyphs in LibreOffice while
    # retaining a native editable Word superscript equation.
    for exponent in math.findall('.//' + qn('m:sup')):
        value=''.join(n.text or '' for n in exponent.findall('.//' + qn('m:t'))).strip()
        if value in ('+', '-', '−', '±', '∓'):
            for run in exponent.findall('.//' + qn('m:r')):
                properties=run.find(qn('m:rPr'))
                if properties is None:
                    properties=OxmlElement('m:rPr');run.insert(0,properties)
                if properties.find(qn('m:lit')) is None:properties.insert(0,OxmlElement('m:lit'))
    return math,mathml


def _plain_native_text(p,text,font,size,bold=False):
    # Plain characters, Unicode scientific scripts, or explicit sub/sup/b tags.
    from html import unescape
    script=None
    for token in re.split(r'(<sub>|</sub>|<sup>|</sup>|<b>|</b>)',text):
        if token=='<sub>':script='sub';continue
        if token=='<sup>':script='sup';continue
        if token in ('</sub>','</sup>'):script=None;continue
        if token=='<b>':bold=True;continue
        if token=='</b>':bold=False;continue
        text=unescape(token)
        groups=[]
        for char in text:
            typ=script or ('sub' if char in UNSUB else 'sup' if char in UNSUPER else None)
            char=UNSUB.get(char,UNSUPER.get(char,char)) if typ else char
            if groups and groups[-1][0]==typ:groups[-1][1]+=char
            else:groups.append([typ,char])
        for typ,t in groups:
            t=''.join(c for c in t if c in '\n\t' or ord(c)>=32)
            run=p.add_run(t)
            if font is not None:run.font.name=font
            if size is not None:run.font.size=Pt(size)
            run.font.color.rgb=RGBColor(0,0,0);run.bold=bold
            if typ=='sub':run.font.subscript=True
            if typ=='sup':run.font.superscript=True


def native_text(p,text,font,size,bold=False):
    """Mixed ordinary scientific text + native inline Word equations."""
    for part in re.split(r'(\\\(.*?\\\)|\\\[.*?\\\])', text, flags=re.S):
        if not part:
            continue
        if (part.startswith('\\(') and part.endswith('\\)')) or (part.startswith('\\[') and part.endswith('\\]')):
            try:
                math,_=equation_xml(part[2:-2])
                p._p.append(math)
                continue
            except Exception:
                # Never delete unconvertible notation or turn an entire
                # question into a screenshot. Keep the original LaTeX editable.
                pass
        _plain_native_text(p,part,font,size,bold)


def export_docx(model, folder, path):
    from aligned_word import export_docx as aligned_export
    return aligned_export(model, folder, path)


def validate_model(data, original):
    """Only text/layout edits are accepted. Never accept client file paths."""
    if not isinstance(data,dict):raise ValueError('Invalid review data')
    import copy
    model=copy.deepcopy(original)
    model['title']=str(data.get('title',model['title']))[:200]
    cols=str(data.get('output_columns',model['output_columns']))
    if cols not in ('auto','1','2'):raise ValueError('Choose a valid column layout')
    model['output_columns']=cols
    from word_options import export_options
    model.update(export_options({**model, **data}))
    model['keep_wrap']=bool(data.get('keep_wrap',False))
    model['separator']=bool(data.get('separator',True))
    model['preserve_source_columns']=bool(data.get('preserve_source_columns',False))
    incoming=data.get('questions',[])
    if not isinstance(incoming,list) or not 1<=len(incoming)<=500:raise ValueError('Keep 1–500 question blocks')
    lookup={q['id']:q for q in original['questions']};seen=set();output=[]
    for q in incoming:
        qid=q.get('id')
        if qid not in lookup or qid in seen:raise ValueError('Invalid or duplicate question ID')
        seen.add(qid);safe=copy.deepcopy(lookup[qid]);safe['items']=[]
        allowed={i['asset']:i for i in lookup[qid]['items'] if i['type']=='image'}
        if not isinstance(q.get('items'),list) or len(q['items'])>500:raise ValueError('Too many elements')
        for item in q['items']:
            typ=item.get('type')
            out={'type':typ,'indent':min(100,max(0,float(item.get('indent',0))))}
            if not math.isfinite(out['indent']):raise ValueError('Invalid indentation')
            if typ=='text':
                text=item.get('text','')
                if not isinstance(text,str) or len(text)>30000:raise ValueError('Text is too long')
                out.update(text=text,bold=bool(item.get('bold')),confidence=item.get('confidence',100))
                if item.get('answer_choice') and item.get('choice_number') in (1,2,3,4):
                    out.update(answer_choice=True,choice_number=int(item['choice_number']))
                if item.get('outline_matched'):out['outline_matched']=True
                if 'option_gap_em' in item:
                    gap=float(item['option_gap_em'])
                    if not math.isfinite(gap) or not 1<=gap<=3.5:raise ValueError('Invalid option label indentation')
                    out['option_gap_em']=gap
            elif typ=='table':
                rows=item.get('rows')
                if not isinstance(rows,list) or not 1<=len(rows)<=100:raise ValueError('Table needs 1–100 rows')
                if any(not isinstance(r,list) or not 1<=len(r)<=12 or any(not isinstance(c,str) or len(c)>4000 for c in r) for r in rows):raise ValueError('Invalid table cells')
                n=max(len(r) for r in rows)
                widths=item.get('widths') or [1]*n
                if not isinstance(widths,list) or len(widths)!=n:widths=[1]*n
                widths=[float(w) for w in widths]
                if any(not math.isfinite(w) or w<=0 or w>1000 for w in widths):raise ValueError('Invalid table widths')
                out.update(rows=rows,widths=widths,border=bool(item.get('border')),header_center=bool(item.get('header_center')))
            elif typ=='equation':
                latex=item.get('latex','');equation_xml(latex);out['latex']=latex
            elif typ=='image':
                if item.get('asset') not in allowed:raise ValueError('Invalid image reference')
                out=copy.deepcopy(allowed[item['asset']])
            else:raise ValueError('Unknown question element')
            if original.get('document_category')=='boss':
                em=float(item.get('flow_indent_em',0))
                if not math.isfinite(em) or not 0<=em<=40:raise ValueError('Invalid Boss Mode paragraph indentation')
                out['flow_indent_em']=em
                source_width=float(item.get('flow_source_width',safe.get('source_width',250)))
                if not math.isfinite(source_width) or not 1<=source_width<=10000:raise ValueError('Invalid Boss Mode source width')
                out['flow_source_width']=source_width
            safe['items'].append(out)
        output.append(safe)
    if original.get('linked_numbering_locked'):
        if [q['id'] for q in output]!=[q['id'] for q in original['questions']]:
            raise ValueError('Question order/count is locked to linked solutions. Change selections and reconvert to change numbering.')
        if model['start_number']!=original['start_number']:
            raise ValueError('Starting number is locked to linked solutions. Change selections and solution links to renumber.')
    if original.get('document_category')=='solutions':
        output.sort(key=lambda q:q['solution_number'])
        model['start_number']=original['start_number']
        model['preserve_source_columns']=False
    if original.get('document_category')=='boss':
        model['preserve_source_columns']=False
        model['start_number']=original.get('start_number',1)
    model['questions']=output
    return model


def reaction_text(p,text,font=None,size=11):
    """Editable Word ruby keeps a literal arrow label above its own arrow.

    Ruby is standard Word text (phonetic-guide structure), not an image. Unlike
    the MathML converter's stacked limits, its base shares the text baseline.
    """
    def attr(tag,value):
        e=OxmlElement(tag);e.set(qn('w:val'),str(value));return e
    pattern=r'(\\\(\\xrightarrow\{.*?\}\\\))'
    for part in re.split(pattern,text,flags=re.S):
        if not part:continue
        if part.startswith('\\(') and 'xrightarrow' in part:
            label=re.sub(r'^.*?xrightarrow\{|\}\\\)$','',part)
            label=re.sub(r'\\(?:quad|qquad)|\\[;,! ]','',label).strip()
            if not re.fullmatch(r'[A-Za-z0-9+−-]{1,6}',label):
                native_text(p,part,None,None);continue
            ruby=OxmlElement('w:ruby');props=OxmlElement('w:rubyPr')
            props.append(attr('w:rubyAlign','center'))
            props.append(attr('w:hps',round(size)))
            props.append(attr('w:hpsRaise',round(size*.9)))
            props.append(attr('w:hpsBaseText',round(size*2)))
            props.append(attr('w:lid','en-US'));ruby.append(props)
            rt=OxmlElement('w:rt');run=OxmlElement('w:r');rp=OxmlElement('w:rPr')
            rp.append(attr('w:sz',round(size)));run.append(rp)
            t=OxmlElement('w:t');t.text=label;run.append(t);rt.append(run);ruby.append(rt)
            base=OxmlElement('w:rubyBase');run=OxmlElement('w:r');rp=OxmlElement('w:rPr')
            rp.append(attr('w:w',285));run.append(rp)
            t=OxmlElement('w:t');t.text='→';run.append(t);base.append(run);ruby.append(base)
            outer=OxmlElement('w:r');outer.append(ruby);p._p.append(outer)
        else:native_text(p,part,None,None)
