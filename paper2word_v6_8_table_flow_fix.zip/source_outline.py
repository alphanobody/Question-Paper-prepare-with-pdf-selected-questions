"""Conservative source-outline recovery for editable reaction lines.

Uses literal local OCR as labels for glyph shapes *in the selected PDF crop*.
It does not use a question transcript, filename rule or a science/label sequence
correction. Applicable only to outlined-text PDFs, not arbitrary raster scans.
If shape evidence is insufficient it returns no replacement for that line.
"""
import math
import re
import statistics
from html import escape


def _path(shape):
    commands=[];last=None
    for it in shape['items']:
        kind=it[0]
        if kind=='l':
            if last!=it[1]:commands.append(f'M {it[1].x} {it[1].y}')
            commands.append(f'L {it[2].x} {it[2].y}');last=it[2]
        elif kind=='c':
            if last!=it[1]:commands.append(f'M {it[1].x} {it[1].y}')
            commands.append('C '+' '.join(f'{p.x} {p.y}' for p in it[2:]));last=it[-1]
        elif kind=='re':
            r=it[1];commands.append(f'M {r.x0} {r.y0} L {r.x1} {r.y0} L {r.x1} {r.y1} L {r.x0} {r.y1} Z');last=None
        else:return None
    return ' '.join(commands)


def _raster(fitz,np,shape):
    r=shape['rect'];path=_path(shape)
    if not path:return None
    svg=f'<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="{r.x0} {r.y0} {r.width} {r.height}" preserveAspectRatio="none"><path d="{path}" fill="black"/></svg>'
    with fitz.open(stream=svg.encode(),filetype='svg') as doc:
        pix=doc[0].get_pixmap(alpha=False)
        return (255-np.frombuffer(pix.samples,dtype=np.uint8).reshape(64,64,3).mean(2))/255


def reaction_lines(page,clip,result,block_box):
    """Return {block_index: text item} for strongly matched reaction lines only."""
    blocks=(result.get('pages') or [{}])[0].get('blocks') or []
    candidates=[]
    for index,b in enumerate(blocks):
        spans=b.get('content')
        if b.get('type')!='text' or not isinstance(spans,list):continue
        if any(s.get('type')=='equation_inline' and ('xrightarrow' in str(s.get('content')) or 'overset' in str(s.get('content'))) for s in spans if isinstance(s,dict)):
            candidates.append(index)
    if not candidates:return {}
    import pymupdf as fitz
    import numpy as np
    shapes=[s for s in page.get_drawings() if clip.contains(s['rect']) and .15<s['rect'].width<clip.width and .15<s['rect'].height<clip.height]
    if not 12<=len(shapes)<=1500:return {}
    entries=[]
    for shape in shapes:
        r=shape['rect']
        if shape.get('type')!='f' or (shape.get('fill') and min(shape['fill'])>.9):continue
        shaft=r.width>6 and r.height<1.1
        a=None if shaft else _raster(fitz,np,shape)
        if not shaft and a is None:continue
        entries.append(dict(r=r,img=a,shaft=shaft))
    if len(entries)<12:return {}
    # Only count-matched OCR boxes become reference glyphs. In particular a
    # dropped subscript changes the count, so it cannot poison the glyph bank.
    bank=[]
    scripts=str.maketrans('₀₁₂₃₄₅₆₇₈₉⁰¹²³⁴⁵⁶⁷⁸⁹⁺⁻','01234567890123456789+-')
    for geom in result.get('local_geometry',[]):
        if float(geom.get('confidence',0))<80:continue
        box=block_box(geom,clip)
        chosen=sorted([e for e in entries if not e['shaft'] and box.contains((e['r'].tl+e['r'].br)/2)],key=lambda e:e['r'].x0)
        text=re.sub(r'\s','',str(geom.get('text',''))).translate(scripts)
        if not text or len(chosen)!=len(text):continue
        for char,e in zip(text,chosen):
            bank.append((char,e['img'],e['r'].width/e['r'].height))
    if len(bank)<20 or not any(c=='→' for c,*_ in bank):return {}
    # Bound memory/time on unusually complex vector pages.
    bank=bank[:800]
    for e in entries:
        if e['shaft']:e.update(c='_',err=0,margin=1);continue
        r=e['r'];ratio=r.width/r.height;scores={}
        for char,a,rat in bank:
            score=float(np.mean(np.abs(e['img']-a)))+.12*abs(math.log(ratio/rat))
            scores[char]=min(scores.get(char,float('inf')),score)
        ordered=sorted((score,char) for char,score in scores.items())
        e.update(c=ordered[0][1],err=ordered[0][0],margin=ordered[1][0]-ordered[0][0])
    replacements={}
    for index in candidates:
        box=block_box(blocks[index],clip)+(-.5,-.5,.5,.5)
        row=[dict(e) for e in entries if box.contains((e['r'].tl+e['r'].br)/2)]
        glyphs=[e for e in row if not e['shaft']]
        if len(glyphs)<4 or max(e['err'] for e in glyphs)>.12:continue
        # Do not silently replace an ambiguous shape by a guessed character.
        if any(e['margin']<.002 for e in glyphs):continue
        text,metrics=_compose(row)
        if text and re.match(r'^\([a-zA-Z]\)\s',text):
            replacements[index]=dict(type='text',text=text,indent=max(0,box.x0-clip.x0),y=box.y0,
                 bold=False,confidence=round(100*(1-max(e['err'] for e in glyphs)),1),
                 outline_matched=True,option_gap_em=metrics['option_gap_em'],source_arrow_labels=metrics['arrow_labels'])
    return replacements


def _compose(row):
    """Combine source strokes/labels into labelled arrow notation for editable Word export."""
    ordinary=[e for e in row if not e['shaft'] and e['c']!='→']
    if not ordinary:return None,{}
    height=statistics.median(e['r'].height for e in ordinary if e['r'].height>4.5)
    used=set();tokens=[];labels=[]
    arrows=[(i,e) for i,e in enumerate(row) if e.get('c')=='→']
    for index,arrow in arrows:
        r=arrow['r'];parts=[];left=r.x0
        # Extended arrows are often two thin filled rectangles + one head.
        changed=True
        while changed:
            changed=False
            for j,e in enumerate(row):
                s=e['r']
                if j in parts or not e['shaft']:continue
                if abs((s.y0+s.y1-r.y0-r.y1)/2)<1.5 and s.x1>=left-1.2 and s.x1<=r.x1+1 and s.x0<left:
                    parts.append(j);left=s.x0;changed=True
        bar_y=statistics.mean((row[j]['r'].y0+row[j]['r'].y1)/2 for j in parts) if parts else (r.y0+r.y1)/2
        supers=[]
        for j,e in enumerate(row):
            s=e['r'];cx=(s.x0+s.x1)/2
            if j==index or j in used or e['shaft'] or e['c']=='→':continue
            if left<=cx<=r.x1 and bar_y-12<=s.y0 and s.y1<=bar_y-1 and s.height<height*.9:
                supers.append(j)
        label=''.join(row[j]['c'] for j in sorted(supers,key=lambda j:row[j]['r'].x0))
        if parts and not label:return None,{} # Never flatten a missed arrow label.
        if label and not re.fullmatch(r'[A-Za-z0-9+−-]{1,6}',label):return None,{}
        used.add(index);used.update(parts);used.update(supers)
        if label:
            # Deliberate spaces set a modest stretch, not a screenshot/shape.
            latex=r'\xrightarrow{\;'+label+r'\;}'
            value=chr(92)+'('+latex+chr(92)+')';labels.append(label)
        else:value='→'
        tokens.append(dict(x0=left,x1=r.x1,text=value,math=True,r=r))
    remaining=[e for i,e in enumerate(row) if i not in used and not e['shaft']]
    # Baseline is the modal bottom of full-sized glyphs; descenders are a minority.
    buckets={}
    for e in remaining:
        if e['r'].height<height*.8:continue
        key=round(e['r'].y1*2)/2;buckets[key]=buckets.get(key,0)+1
    if not buckets:return None,{}
    baseline=max(buckets,key=buckets.get)
    for e in remaining:
        r=e['r'];kind=None
        if r.height<height*.85:
            if r.y1>baseline+1:kind='sub'
            elif r.y1<baseline-height*.3:kind='sup'
        char=escape(e['c'])
        if kind:char=f'<{kind}>{char}</{kind}>'
        tokens.append(dict(x0=r.x0,x1=r.x1,text=char,math=False,script=kind,r=r))
    tokens.sort(key=lambda t:t['x0'])
    out=[];previous=None
    for t in tokens:
        if previous and not t.get('script'):
            gap=t['x0']-previous['x1']
            if t['math'] or previous['math'] or gap>max(1.65,height*.25):out.append(' ')
        out.append(t['text']);previous=t
    text=''.join(out).strip()
    # Source label-to-body distance controls the hanging indent, scaled in ems.
    label_end=next((i for i,t in enumerate(tokens) if t['text']==')'),None)
    gap=1.6
    if label_end is not None and label_end+1<len(tokens):
        gap=(tokens[label_end+1]['x0']-tokens[0]['x0'])/max(1,height)*.70
    return text,dict(option_gap_em=max(1,min(3.5,gap)),arrow_labels=labels)
