"""Explicit solution grouping. No semantic boundary guessing for continuations."""
import copy


def validate_solution_selections(selections):
    if not isinstance(selections, dict):
        raise ValueError('Invalid solution selections.')
    numbers = set()
    for regions in selections.values():
        for r in regions:
            n = r.get('solution_number')
            if isinstance(n, bool) or not isinstance(n, int) or not 1 <= n <= 9999:
                raise ValueError('Choose a solution question number from 1 to 9999 for every solution box.')
            if r.get('kind', 'text') == 'text':
                numbers.add(n)
    for regions in selections.values():
        for r in regions:
            if r['solution_number'] not in numbers:
                raise ValueError('Each solution needs a main selection; diagram/table boxes alone are not enough.')
    if len(numbers) > 500:
        raise ValueError('Select at most 500 solutions per conversion.')
    return sorted(numbers)


def merge_solution_parts(model):
    """Input parts are already in page/left-column/right-column reading order."""
    groups = {}
    for part in model['questions']:
        number = part['solution_number']
        if number not in groups:
            q = copy.deepcopy(part)
            q.update(items=[dict(type='text', text='Solution', confidence=100, indent=0)],
                     warnings=[], source_parts=[], number_normalized=True)
            groups[number] = q
        q = groups[number]
        q['items'].extend(copy.deepcopy(part['items']))
        q['warnings'].extend(part.get('warnings', []))
        q['source_parts'].append(dict(page=part['page'], asset=part['source_asset'],
                                      source_column=part.get('source_column', 0)))
    model['questions'] = [groups[n] for n in sorted(groups)]
    for q in model['questions']:
        q['warnings'] = list(dict.fromkeys(q['warnings']))
    model['document_category'] = 'solutions'
    model['start_number'] = min(groups) if groups else 1
    model['solution_numbers'] = sorted(groups)
    model['warnings'].append('Solution parts are joined in PDF reading order: pages ascending, left column then right column. Original numbered steps and labels are preserved. Source prefixes, if retained, can be edited in review.')
    return model
