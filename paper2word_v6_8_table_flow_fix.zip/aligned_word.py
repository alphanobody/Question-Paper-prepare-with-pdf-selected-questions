"""Word-native numbering and reflow, independent of OCR crop coordinates.

Paragraph indents and real table columns replace visual space alignment. Font
sizes are exact requested points, not rescaled for different selection widths.
"""
import re
from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.style import WD_STYLE_TYPE
from docx.enum.text import WD_ALIGN_PARAGRAPH, WD_BREAK
from docx.enum.section import WD_SECTION_START
from word_options import export_options

SOURCE_NUMBER=re.compile(r'^\s*(?:(?:Q(?:uestion)?\.?\s*)?\d{1,6}[.)](?!\d)\s*|\(\d{1,6}\)\s*|Q(?:uestion)?\.?\s*\d{1,6}\s*(?:[:.)-]\s*)?)',re.I)
OPTION=re.compile(r'^\s*(\((?:\d{1,3}|[a-hA-H]|[ivxIVX]{1,7})\)|[a-dA-D][.)]|[IVX]{1,6}[.])\s*')


def normalize_question_numbers(model):
    """Strip only the source question prefix, once, never option/table numbers."""
    if model.get('document_category') in ('solutions','boss'):return
    for q in model['questions']:
        if q.get('number_normalized'):continue
        items=q['items']
        # The printed number may occupy its own OCR text block.
        while items and items[0]['type']=='text':
            text=items[0].get('text','')
            if not text.strip():items.pop(0);continue
            match=SOURCE_NUMBER.match(text)
            if match:
                q['original_number']=match.group(0).strip()
                remaining=text[match.end():].lstrip()
                if remaining:items[0]['text']=remaining
                else:items.pop(0)
            elif re.fullmatch(r'\s*\d{1,6}\s*',text):
                q['original_number']=text.strip();items.pop(0)
            break
        q['number_normalized']=True


def element(tag,**attrs):
    e=OxmlElement(tag)
    for k,v in attrs.items():e.set(qn('w:'+k),str(v))
    return e


def add_numbering(doc,start,indent):
    root=doc.part.numbering_part.element
    abstract_id=max([int(n.get(qn('w:abstractNumId'))) for n in root.findall(qn('w:abstractNum'))]+[-1])+1
    num_id=max([int(n.get(qn('w:numId'))) for n in root.findall(qn('w:num'))]+[0])+1
    abstract=element('w:abstractNum',abstractNumId=abstract_id)
    abstract.append(element('w:multiLevelType',val='singleLevel'))
    level=element('w:lvl',ilvl=0)
    for name,val in [('start',start),('numFmt','decimal'),('suff','tab'),('lvlText','%1.'),('lvlJc','left')]:
        level.append(element('w:'+name,val=val))
    properties=element('w:pPr');tabs=element('w:tabs')
    tabs.append(element('w:tab',val='num',pos=round(indent*20)));properties.append(tabs)
    properties.append(element('w:ind',left=round(indent*20),hanging=round(indent*20)))
    level.append(properties);abstract.append(level)
    # All abstract definitions must precede the concrete num definitions.
    first=root.find(qn('w:num'))
    if first is None:root.append(abstract)
    else:root.insert(root.index(first),abstract)
    num=element('w:num',numId=num_id);num.append(element('w:abstractNumId',val=abstract_id))
    override=element('w:lvlOverride',ilvl=0);override.append(element('w:startOverride',val=start));num.append(override)
    root.append(num)
    return num_id


def set_number(p,num_id):
    prop=p._p.get_or_add_pPr();num=element('w:numPr')
    num.append(element('w:ilvl',val=0));num.append(element('w:numId',val=num_id));prop.append(num)


def set_style(doc,name,indent=0,first=0):
    style=doc.styles.add_style(name,WD_STYLE_TYPE.PARAGRAPH)
    style.base_style=doc.styles['Normal'];pf=style.paragraph_format
    pf.alignment=WD_ALIGN_PARAGRAPH.LEFT
    pf.left_indent=Pt(indent);pf.first_line_indent=Pt(first)
    pf.space_before=Pt(0);pf.space_after=Pt(0)
    pf.keep_with_next=False;pf.keep_together=False;pf.widow_control=True
    return style


def export_docx(model,folder,path):
    if model.get('document_category')=='boss':
        from boss_word import export_boss_docx
        return export_boss_docx(model,folder,path)
    from offline_layout import native_text,equation_xml,reaction_text
    options=export_options(model);model.update(options);normalize_question_numbers(model)
    from answer_choices import normalize_answer_choices
    if model.get('document_category')!='solutions':normalize_answer_choices(model)
    size=options['font_size'];font=options['font_name'];start=options['start_number']
    count=len(model['questions'])
    is_solution=model.get('document_category')=='solutions'
    numbers=[int(q['solution_number']) for q in model['questions']] if is_solution else list(range(start,start+count))
    if not numbers or min(numbers)<1 or max(numbers)>9999:raise ValueError('Invalid document numbering.')
    if not is_solution and start+count-1>9999:raise ValueError('Question numbering exceeds 9999. Choose a lower start number.')
    # Enough room for the widest generated number; applies identically to all
    # questions, regardless of source indentation/crop width.
    gutter=max(22,(len(str(max(numbers)))+1)*size*.62)
    option_gutter=max(22,size*2.5)
    doc=Document();doc.core_properties.title=model['title']
    doc.core_properties.subject='Editable numbered questions; compare recognition with the PDF.'
    sec=doc.sections[0];sec.page_width=Pt(595.32);sec.page_height=Pt(841.92)
    sec.top_margin=sec.bottom_margin=Pt(38);sec.left_margin=sec.right_margin=Pt(38)
    normal=doc.styles['Normal'];normal.font.name=font;normal.font.size=Pt(size)
    normal.font.color.rgb=RGBColor(0,0,0)
    fonts=normal.element.get_or_add_rPr().rFonts
    for script in ('ascii','hAnsi','eastAsia','cs'):fonts.set(qn('w:'+script),font)
    for attr in ('asciiTheme','hAnsiTheme','eastAsiaTheme','csTheme'):
        fonts.attrib.pop(qn('w:'+attr),None)
    normal.paragraph_format.line_spacing=1.12;normal.paragraph_format.space_after=Pt(0)
    normal.paragraph_format.keep_with_next=False
    # Also update Word's document defaults so math and new paragraphs inherit.
    defaults=doc.styles.element.find(qn('w:docDefaults'))
    if defaults is not None:
        rdefault=defaults.find(qn('w:rPrDefault'))
        if rdefault is not None:
            rp=rdefault.find(qn('w:rPr'))
            if rp is not None:
                for tag in ('sz','szCs'):
                    e=rp.find(qn('w:'+tag))
                    if e is None:e=element('w:'+tag);rp.append(e)
                    e.set(qn('w:val'),str(round(size*2)))
    set_style(doc,'P2W Question',gutter,-gutter)
    set_style(doc,'P2W Body',gutter)
    option_style=set_style(doc,'P2W Option',gutter+option_gutter,-option_gutter)
    option_style.paragraph_format.tab_stops.add_tab_stop(Pt(gutter+option_gutter))
    answer_style=set_style(doc,'P2W Answer',gutter+option_gutter,-option_gutter)
    answer_style.paragraph_format.tab_stops.add_tab_stop(Pt(gutter+option_gutter))
    set_style(doc,'P2W Table')
    table_gutter=max(18,size*2.1)
    table_option=set_style(doc,'P2W Table Option',table_gutter,-table_gutter)
    table_option.paragraph_format.tab_stops.add_tab_stop(Pt(table_gutter))
    caption=set_style(doc,'P2W Heading');caption.font.size=Pt(10)
    if model.get('title'):
        hp=sec.header.paragraphs[0];hp.style=caption;hp.alignment=WD_ALIGN_PARAGRAPH.RIGHT
        native_text(hp,model['title'],None,None)
    num_id=add_numbering(doc,start,gutter)
    stats=dict(pages=len({q['page'] for q in model['questions']}),questions=count,tables=0,diagrams=0,paragraphs=0,words=0,equations=0,
               page_layouts=[],low_confidence_words=0,warnings=list(model.get('warnings',[])),
               start_number=min(numbers),end_number=max(numbers),font_name=font,font_size=size)
    if is_solution:stats['pages']=len({p['page'] for q in model['questions'] for p in q.get('source_parts',[dict(page=q['page'])])})
    stats['document_category']=model.get('document_category','questions')
    stats['solution_numbers']=numbers if is_solution else []
    stats['solutions']=count if is_solution else 0
    stats['selection_question_counts']=list(model.get('selection_question_counts',[]))
    stats['selection_boxes']=len(stats['selection_question_counts'])
    current=None;previous=None
    for q in model['questions']:
        if is_solution:num_id=add_numbering(doc,int(q['solution_number']),gutter)
        cols=q['source_columns'] if model.get('output_columns','auto')=='auto' else int(model['output_columns'])
        if cols!=current:
            section=doc.sections[0] if current is None else doc.add_section(WD_SECTION_START.CONTINUOUS)
            cp=section._sectPr.find(qn('w:cols'))
            if cp is None:cp=element('w:cols');section._sectPr.append(cp)
            cp.set(qn('w:num'),str(cols));cp.set(qn('w:space'),'240')
            cp.set(qn('w:sep'),'1' if cols==2 and model.get('separator',True) else '0');current=cols
        source_pages=[p['page'] for p in q.get('source_parts',[])] or [q['page']]
        for source_page in source_pages:
            if not any(p['page']==source_page for p in stats['page_layouts']):stats['page_layouts'].append(dict(page=source_page,columns=cols))
        # Opt-in legacy source grouping only. New exports flow continuously.
        if previous and cols==2 and model.get('preserve_source_columns',False) and q['source_columns']==2:
            if previous['page']==q['page'] and previous.get('source_column')==0 and q.get('source_column')==1:
                doc.add_paragraph().add_run().add_break(WD_BREAK.COLUMN)
        previous=q
        width=(519.32-(12 if cols==2 else 0))/cols
        available=max(30,width-gutter)
        source_scale=min(1,available/max(1,q.get('source_width',width)-17))
        question_paras=[];first=True;last_was_table=False
        for item in q['items']:
            kind=item['type']
            if first and kind!='text':
                lead=doc.add_paragraph(style='P2W Question');set_number(lead,num_id)
                lead.paragraph_format.keep_with_next=True;question_paras.append(lead);first=False
            if kind=='text':
                text=item.get('text','').strip()
                if not text:continue
                if not model.get('keep_wrap',False):text=re.sub(r'(?<!\n)\n(?!\n)',' ',text)
                # Source PDFs often use spaces/tabs as visual alignment. These
                # are not stable under font changes; use paragraph/tab settings.
                text=re.sub(r'[ \t]{2,}',' ',text)
                p=doc.add_paragraph(style='P2W Question' if first else 'P2W Body')
                if first:set_number(p,num_id);first=False
                else:
                    match=OPTION.match(text)
                    if match:
                        p.style='P2W Answer' if item.get('answer_choice') else 'P2W Option';text=match[1]+'\t'+text[match.end():]
                        if item.get('option_gap_em'):
                            gap=max(size,min(size*3.5,float(item['option_gap_em'])*size))
                            p.paragraph_format.left_indent=Pt(gutter+gap)
                            p.paragraph_format.first_line_indent=Pt(-gap)
                            p.paragraph_format.tab_stops.add_tab_stop(Pt(gutter+gap))
                if item.get('outline_matched'):
                    reaction_text(p,text,font,size)
                else:native_text(p,text,None,None,bool(item.get('bold')))
                question_paras.append(p);stats['paragraphs']+=1;stats['words']+=len(text.split())
                if item.get('confidence',100)<65:stats['low_confidence_words']+=1
                last_was_table=False
            elif kind=='table':
                rows=item['rows'];n=max(len(r) for r in rows)
                raw=(list(item.get('widths') or [])+[1]*n)[:n]
                # In a multi-value answer-code grid, the answer NUMBER must
                # not consume a hanging-indent gutter inside the first DATA
                # column (which squeezes e.g. Metaphase into a few letters).
                # Render a dedicated narrow label column; keep model cells
                # and source-code values unchanged for editable review.
                if n>=3 and len(rows)==5 and all(len(r)==n for r in rows):
                    markers=[re.match(r'^\s*\(([1-4])\)\s*(.+)$',r[0],re.S) for r in rows[1:]]
                    if all(markers) and [m[1] for m in markers]==list('1234'):
                        rows=[['']+rows[0]]+[[f'({m[1]})',m[2]]+r[1:] for m,r in zip(markers,rows[1:])]
                        label_width=min(size*2,available*.12);weight=sum(raw)
                        raw=[label_width]+[(available-label_width)/n]*n;n+=1
                table=doc.add_table(rows=0,cols=n);table.autofit=False
                if item.get('border'):table.style='Table Grid'
                total=sum(raw)
                props=table._tbl.tblPr
                props.append(element('w:tblInd',w=round(gutter*20),type='dxa'))
                tw=props.find(qn('w:tblW'))
                if tw is not None:tw.set(qn('w:type'),'dxa');tw.set(qn('w:w'),str(round(available*20)))
                margins=element('w:tblCellMar')
                for side in ('top','bottom','left','right'):margins.append(element('w:'+side,w=0,type='dxa'))
                props.append(margins)
                for col,weight in zip(table.columns,raw):col.width=Pt(available*weight/total)
                for ri,values in enumerate(rows):
                    cells=table.add_row().cells
                    for ci,cell in enumerate(cells):
                        cell.width=Pt(available*raw[ci]/total);p=cell.paragraphs[0];p.style='P2W Table'
                        if ri==0 and item.get('header_center'):p.alignment=WD_ALIGN_PARAGRAPH.CENTER
                        content=values[ci] if ci<len(values) else ''
                        if not model.get('keep_wrap',False):content=re.sub(r'(?<!\n)\n(?!\n)',' ',content)
                        marker=OPTION.match(content)
                        if marker and available*raw[ci]/total>=size*4:
                            p.style='P2W Table Option';content=marker[1]+'\t'+content[marker.end():]
                            if all(re.match(r'^\(\d{1,2}\)',str(v).strip()) for row in rows for v in row if str(v).strip()):
                                gap=max(12,size*1.3)
                                p.paragraph_format.left_indent=Pt(gap);p.paragraph_format.first_line_indent=Pt(-gap)
                                p.paragraph_format.tab_stops.add_tab_stop(Pt(gap))
                        native_text(p,content,None,None);stats['words']+=len(content.split())
                        # Small tables should not strand a single row in the
                        # previous column. Large tables remain splittable.
                        if len(rows)<=8 and sum(len(str(v)) for row in rows for v in row)<1200:
                            p.paragraph_format.keep_with_next=ri<len(rows)-1
                stats['tables']+=1;last_was_table=True
            elif kind=='image':
                p=doc.add_paragraph(style='P2W Answer' if item.get('picture_choice_number') else 'P2W Body')
                if item.get('picture_choice_number'):native_text(p,f"({int(item['picture_choice_number'])})\t",None,None)
                picture_width=min(float(item.get('width',150))*source_scale,available)
                p.add_run().add_picture(str(Path(folder)/'assets'/item['asset']),width=Pt(picture_width))
                question_paras.append(p);stats['diagrams']+=1;last_was_table=False
            elif kind=='equation':
                p=doc.add_paragraph(style='P2W Body');math,_=equation_xml(item['latex']);p._p.append(math)
                question_paras.append(p);last_was_table=False
        if first:
            p=doc.add_paragraph(style='P2W Question');set_number(p,num_id);question_paras.append(p)
        # Keep only the question lead with its next element, not every item in
        # the block. Tall questions/options can flow to the next column/page.
        if question_paras and len(q['items'])>1:question_paras[0].paragraph_format.keep_with_next=True
        if last_was_table:
            # Word needs a separator after a trailing table; keep it minimal.
            end=doc.add_paragraph();end.paragraph_format.line_spacing=Pt(1);end.paragraph_format.space_after=Pt(5)
        elif question_paras:question_paras[-1].paragraph_format.space_after=Pt(6)
    stats['annotated_arrows']=len(doc._element.findall('.//'+qn('w:ruby')))
    stats['equations']=len(doc._element.findall('.//'+qn('m:oMath')))
    temp=Path(path).with_suffix('.tmp.docx');doc.save(temp)
    if font=='Roboto Condensed':
        from font_embed import embed_fonts
        embed_fonts(temp)
    temp.replace(path)
    return stats
