"""Embed redistributable OFL font files in Word documents; no network access."""
from pathlib import Path
import zipfile, uuid
from lxml import etree
from docx.oxml.ns import qn
ROOT = Path(__file__).resolve().parent / 'fonts'
FONT = 'Roboto Condensed'

def embed_fonts(path):
    """Embed OFL-licensed static fonts as OOXML obfuscated font parts."""
    ns={'w':'http://schemas.openxmlformats.org/wordprocessingml/2006/main',
        'r':'http://schemas.openxmlformats.org/officeDocument/2006/relationships'}
    relns='http://schemas.openxmlformats.org/package/2006/relationships'
    ctns='http://schemas.openxmlformats.org/package/2006/content-types'
    with zipfile.ZipFile(path) as z:files={n:z.read(n) for n in z.namelist()}
    ft=etree.fromstring(files['word/fontTable.xml'])
    f=next((x for x in ft if x.get(qn('w:name'))==FONT),None)
    if f is None:f=etree.SubElement(ft,qn('w:font'));f.set(qn('w:name'),FONT)
    relpath='word/_rels/fontTable.xml.rels'
    rels=etree.fromstring(files[relpath]) if relpath in files else etree.Element('{'+relns+'}Relationships',nsmap={None:relns})
    for kind,label in [('Regular','Regular'),('Bold','Bold')]:
        data=bytearray((ROOT/f'RobotoCondensed-{label}.ttf').read_bytes())
        key=uuid.uuid4();xor=key.bytes[::-1]
        for i in range(32):data[i]^=xor[i%16]
        name=f'fonts/RobotoCondensed-{label}.odttf';rid='rIdFont'+kind
        files['word/'+name]=bytes(data)
        rel=etree.SubElement(rels,'{'+relns+'}Relationship')
        rel.set('Id',rid);rel.set('Type',ns['r']+'/font');rel.set('Target',name)
        embed=etree.SubElement(f,qn('w:embed'+kind));embed.set(qn('r:id'),rid)
        embed.set(qn('w:fontKey'),'{'+str(key).upper()+'}')
    files['word/fontTable.xml']=etree.tostring(ft,xml_declaration=True,encoding='UTF-8',standalone=True)
    files[relpath]=etree.tostring(rels,xml_declaration=True,encoding='UTF-8',standalone=True)
    ct=etree.fromstring(files['[Content_Types].xml'])
    etree.SubElement(ct,'{'+ctns+'}Default',Extension='odttf',ContentType='application/vnd.openxmlformats-officedocument.obfuscatedFont')
    files['[Content_Types].xml']=etree.tostring(ct,xml_declaration=True,encoding='UTF-8',standalone=True)
    settings=etree.fromstring(files['word/settings.xml'])
    etree.SubElement(settings,qn('w:embedTrueTypeFonts'))
    files['word/settings.xml']=etree.tostring(settings,xml_declaration=True,encoding='UTF-8',standalone=True)
    with zipfile.ZipFile(path,'w',zipfile.ZIP_DEFLATED) as z:
        for n,b in files.items():z.writestr(n,b)
