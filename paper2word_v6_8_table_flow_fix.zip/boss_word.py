"""Boss Mode editable-flow exporter. No generated question numbering or screenshots."""
import re
from pathlib import Path
from docx import Document
from docx.shared import Pt, RGBColor
from docx.oxml.ns import qn
from docx.enum.section import WD_SECTION_START
from aligned_word import element, set_style
from word_options import export_options

LABEL = re.compile(r'^\s*((?:\([0-9a-zA-ZivxIVX]{1,6}\)|\d{1,6}[.)]|[a-zA-Z][.)]))\s+')


def export_boss_docx(model, folder, path):
    from offline_layout import native_text, equation_xml, reaction_text
    options = export_options(model); model.update(options)
    font = options['font_name']; size = options['font_size']
    doc = Document(); doc.core_properties.title = model.get('title', '')
    doc.core_properties.subject = 'Boss Mode: editable source content in Word reading order.'
    section = doc.sections[0]; section.page_width = Pt(595.32); section.page_height = Pt(841.92)
    section.top_margin = section.bottom_margin = Pt(38)
    section.left_margin = section.right_margin = Pt(38)
    normal = doc.styles['Normal']; normal.font.name = font; normal.font.size = Pt(size)
    normal.font.color.rgb = RGBColor(0,0,0)
    fonts = normal.element.get_or_add_rPr().rFonts
    for script in ('ascii','hAnsi','eastAsia','cs'):fonts.set(qn('w:'+script),font)
    for script in ('asciiTheme','hAnsiTheme','eastAsiaTheme','csTheme'):fonts.attrib.pop(qn('w:'+script),None)
    defaults=doc.styles.element.find(qn('w:docDefaults'))
    if defaults is not None:
        rd=defaults.find(qn('w:rPrDefault'))
        rp=rd.find(qn('w:rPr')) if rd is not None else None
        if rp is not None:
            for tag in ('sz','szCs'):
                e=rp.find(qn('w:'+tag))
                if e is None:e=element('w:'+tag);rp.append(e)
                e.set(qn('w:val'),str(round(size*2)))
    normal.paragraph_format.line_spacing = 1.12
    normal.paragraph_format.space_after = Pt(0)
    normal.paragraph_format.keep_with_next = False
    for name in ('P2W Body','P2W Option','P2W Table'):set_style(doc,name)
    stats = dict(document_category='boss', pages=len({q['page'] for q in model['questions']}),
                 questions=0, blocks=len(model['questions']), tables=0, diagrams=0,
                 paragraphs=0, words=0, equations=0, low_confidence_words=0, page_layouts=[],
                 warnings=list(model.get('warnings',[])), font_name=font, font_size=size,
                 selection_boxes=len(model.get('selection_question_counts',[])),
                 boss_input=model.get('boss_input','areas'), boss_pages=model.get('boss_pages',[]))
    current = None
    for block in model['questions']:
        columns = block['source_columns'] if model.get('output_columns','auto')=='auto' else int(model['output_columns'])
        if columns != current:
            sec = doc.sections[0] if current is None else doc.add_section(WD_SECTION_START.CONTINUOUS)
            cp = sec._sectPr.find(qn('w:cols'))
            if cp is None:cp=element('w:cols');sec._sectPr.append(cp)
            cp.set(qn('w:num'),str(columns));cp.set(qn('w:space'),'240')
            cp.set(qn('w:sep'),'1' if columns==2 and model.get('separator',True) else '0')
            current=columns
        if not any(p['page']==block['page'] for p in stats['page_layouts']):
            stats['page_layouts'].append(dict(page=block['page'],columns=columns))
        width=(519.32-(12 if columns==2 else 0))/columns
        for item in block['items']:
            kind=item['type']; indent=min(width*.4,max(0,float(item.get('flow_indent_em',0))*size))
            available=max(30,width-indent)
            def paragraph():
                p=doc.add_paragraph(style='P2W Body')
                p.paragraph_format.left_indent=Pt(indent)
                p.paragraph_format.first_line_indent=Pt(0)
                return p
            if kind=='text':
                text=item.get('text','').strip()
                if not text:continue
                if not model.get('keep_wrap',False):text=re.sub(r'(?<!\n)\n(?!\n)',' ',text)
                text=re.sub(r'[ \t]{2,}',' ',text)
                p=paragraph(); match=LABEL.match(text)
                if match:
                    gap=max(size*1.5,(len(match[1])+1)*size*.56)
                    p.style='P2W Option';p.paragraph_format.left_indent=Pt(indent+gap)
                    p.paragraph_format.first_line_indent=Pt(-gap)
                    p.paragraph_format.tab_stops.add_tab_stop(Pt(indent+gap))
                    text=match[1]+'\t'+text[match.end():]
                if item.get('outline_matched'):reaction_text(p,text,font,size)
                else:native_text(p,text,None,None,bool(item.get('bold')))
                # Keep a short recognised heading with its following paragraph,
                # but never bind a whole page/area into an unbreakable block.
                if item.get('bold') and len(text)<160:p.paragraph_format.keep_with_next=True
                stats['paragraphs']+=1;stats['words']+=len(text.split())
                if item.get('confidence',100)<65:stats['low_confidence_words']+=1
            elif kind=='equation':
                p=paragraph();math,_=equation_xml(item['latex']);p._p.append(math)
            elif kind=='image':
                p=paragraph()
                source_width=max(1,float(item.get('flow_source_width',block.get('source_width',width))))
                scale=min(1,available/source_width)
                picture_width=min(available,max(1,float(item.get('width',150))*scale))
                p.add_run().add_picture(str(Path(folder)/'assets'/item['asset']),width=Pt(picture_width))
                stats['diagrams']+=1
            elif kind=='table':
                rows=item['rows'];n=max(len(r) for r in rows)
                table=doc.add_table(rows=0,cols=n);table.autofit=False
                if item.get('border'):table.style='Table Grid'
                raw=(list(item.get('widths') or [])+[1]*n)[:n];total=sum(raw)
                props=table._tbl.tblPr;props.append(element('w:tblInd',w=round(indent*20),type='dxa'))
                tw=props.find(qn('w:tblW'))
                if tw is not None:tw.set(qn('w:type'),'dxa');tw.set(qn('w:w'),str(round(available*20)))
                margins=element('w:tblCellMar')
                for side in ('top','bottom','left','right'):margins.append(element('w:'+side,w=0,type='dxa'))
                props.append(margins)
                for col,weight in zip(table.columns,raw):col.width=Pt(available*weight/total)
                for values in rows:
                    cells=table.add_row().cells
                    for ci,cell in enumerate(cells):
                        cell.width=Pt(available*raw[ci]/total)
                        p=cell.paragraphs[0];p.style='P2W Table'
                        text=values[ci] if ci<len(values) else ''
                        if not model.get('keep_wrap',False):text=re.sub(r'(?<!\n)\n(?!\n)',' ',text)
                        native_text(p,text,None,None);stats['words']+=len(text.split())
                stats['tables']+=1
    stats['annotated_arrows']=len(doc._element.findall('.//'+qn('w:ruby')))
    stats['equations']=len(doc._element.findall('.//'+qn('m:oMath')))
    temp=Path(path).with_suffix('.tmp.docx');doc.save(temp)
    if font=='Roboto Condensed':
        from font_embed import embed_fonts
        embed_fonts(temp)
    temp.replace(path)
    return stats
