"""Paper2Word 6.8 — lightweight opening, lazy previews, local conversion.
No OCR/PDF/export libraries are imported until their corresponding action.
"""

import uuid
import json
import re
import math
import threading
import time
import traceback
import platform
import sys
import io
import os
import signal
import atexit
import zipfile
from pathlib import Path

from flask import (
    Flask, request, jsonify, send_file, abort,
)

# --------------------------------------------------------------------------
# Configuration
# --------------------------------------------------------------------------
# Resolve paths relative to this script so the app works on any OS / location.
BASE = Path(__file__).resolve().parent
JOBS_DIR = BASE / "jobs"
STATIC_DIR = BASE / "static"
TEMPLATE_DIR = BASE / "templates"
JOBS_DIR.mkdir(parents=True, exist_ok=True)

PREVIEW_DPI = 150   # resolution for on-screen page thumbnails
OCR_DPI = 260       # resolution used for OCR of scanned pages
MAX_PAGES = 120     # safety cap on rendered pages

app = Flask(__name__, static_folder=str(STATIC_DIR), template_folder=str(TEMPLATE_DIR))
app.config["MAX_CONTENT_LENGTH"] = 100 * 1024 * 1024

# In-memory job registry. Each job:
#   {dir, filename, page_count, status, progress, stage, error, docx, stats}
JOBS = {}


# --------------------------------------------------------------------------
# Small helpers
# --------------------------------------------------------------------------


def parse_pages(spec, total):
    """Parse '1-3, 5, 8-10' (or a list) into a sorted, unique, in-range list."""
    if isinstance(spec, list):
        nums = [int(x) for x in spec if str(x).strip().isdigit()]
    else:
        nums = []
        for part in str(spec or "").split(","):
            part = part.strip()
            if not part:
                continue
            if "-" in part:
                a, _, b = part.partition("-")
                try:
                    lo, hi = int(a), int(b)
                except ValueError:
                    continue
                nums += range(lo, hi + 1)
            elif part.isdigit():
                nums.append(int(part))
    return sorted({n for n in nums if 1 <= n <= total})


# --------------------------------------------------------------------------
# Background processing
# --------------------------------------------------------------------------
def _real_selections(selections):
    """Pages that actually have at least one drawn rectangle."""
    return {int(str(p)): v for p, v in selections.items() if v}


def run_processing(job_id, pages, crops, selections, output_columns):
    job = JOBS.get(job_id)
    if not job:
        return
    try:
        from offline_layout import export_docx
        from local_recognition import analyze_local
        from solution_jobs import build_documents
        build_documents(job_id, job, selections, output_columns, JOBS, analyze_local, export_docx)
    except Exception as exc:
        recognition_module = sys.modules.get("local_recognition")
        recognition_error = getattr(recognition_module, "LocalRecognitionError", ())
        (Path(job['dir'])/'error.log').write_text(traceback.format_exc(), encoding='utf-8')
        if job.get('cancel') and job['cancel'].is_set():
            job.update(status="cancelled", error=None, stage="Conversion stopped. You can change selections and try again.")
        else:
            message = str(exc) if isinstance(exc, recognition_error) else ("Local conversion failed (" + type(exc).__name__ + "). Use Save error details below; no document was uploaded to a service.")
            job.update(status="error", error=message, stage="Local conversion stopped")
    finally:
        for child_id in job.get('child_ids', []):
            child=JOBS.get(child_id)
            if child and child.get('status')=='processing':child.update(status=job['status'],error=job.get('error'),stage=job.get('stage'))
        job['finished_at'] = time.monotonic()


# --------------------------------------------------------------------------
# Routes
# --------------------------------------------------------------------------
@app.route("/")
def index():
    return send_file(str(TEMPLATE_DIR / "index.html"))


@app.route("/api/upload", methods=["POST"])
def upload():
    f = request.files.get("file")
    if not f:
        return jsonify(error="No file uploaded"), 400
    name = f.filename or "document.pdf"
    if not name.lower().endswith(".pdf"):
        return jsonify(error="Please upload a PDF file"), 400

    job_id = uuid.uuid4().hex
    job_dir = JOBS_DIR / job_id
    (job_dir / "pages").mkdir(parents=True, exist_ok=True)
    pdf_path = job_dir / "source.pdf"
    f.save(str(pdf_path))

    # Metadata only. Render no previews until the browser requests a page.
    # Opening a 120-page PDF no longer waits for 120 full-page JPEGs.
    import pymupdf as fitz
    try:
        from pdf_geometry import normalize_page_rotations
        rotation_normalized=normalize_page_rotations(pdf_path)
        with fitz.open(str(pdf_path)) as doc:
            if doc.needs_pass:
                return jsonify(error="This PDF is password-protected. Use an unlocked copy."), 400
            n = min(doc.page_count, MAX_PAGES)
            if not n:
                return jsonify(error="The PDF has no pages."), 400
            pages = []
            for i in range(n):
                size = doc.load_page(i).rect
                pages.append({"n": i+1, "url": f"/api/page/{job_id}/{i+1}",
                              "width": round(size.width*PREVIEW_DPI/72),
                              "height": round(size.height*PREVIEW_DPI/72)})
    except Exception:
        return jsonify(error="Could not read this PDF. It may be damaged or unsupported."), 400

    JOBS[job_id] = {
        "dir": str(job_dir),
        "filename": name,
        "page_count": n,
        "rotation_normalized": rotation_normalized,
        "status": "ready",
        "progress": 0,
        "stage": "",
        "error": None,
        "docx": None,
        "stats": None,
        "preview_lock": threading.Lock(),
        "cancel": threading.Event(),
    }
    return jsonify(job_id=job_id, filename=name, page_count=n, pages=pages, rotation_normalized=rotation_normalized)


@app.route("/api/page/<job_id>/<int:n>")
def page_img(job_id, n):
    job = JOBS.get(job_id)
    if not job or not 1 <= n <= job['page_count']:
        abort(404)
    p = Path(job['dir']) / 'pages' / f'{n}.jpg'
    with job['preview_lock']:
        if not p.exists():
            import pymupdf as fitz
            with fitz.open(str(Path(job['dir'])/'source.pdf')) as source:
                pix = source[n-1].get_pixmap(dpi=PREVIEW_DPI, alpha=False)
                temp = p.with_suffix('.part')
                temp.write_bytes(pix.tobytes('jpeg', jpg_quality=82))
                temp.replace(p)
    return send_file(str(p), mimetype="image/jpeg")


@app.route("/api/process", methods=["POST"])
def process():
    data = request.get_json(force=True, silent=True) or {}
    if not isinstance(data, dict):
        return jsonify(error="Invalid process request"), 400
    job_id = data.get("job_id")
    job = JOBS.get(job_id)
    if not job:
        return jsonify(error="Invalid job"), 400

    pages = parse_pages(data.get("pages") or f"1-{job['page_count']}", job["page_count"])
    if not pages:
        return jsonify(error="No valid pages selected"), 400

    from boss_mode import boss_settings
    try:
        boss = boss_settings(data.get('boss'), job['page_count'])
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    boss_selections = boss['selections'] if boss else {}
    crops = data.get("crops") or {}
    selections = data.get("selections") or {}
    solutions = data.get("solutions") or {}
    solution_columns = str(data.get("solution_columns", data.get("output_columns", "auto")))
    output_columns = str(data.get("output_columns", "auto"))
    if output_columns not in ("auto", "1", "2") or solution_columns not in ("auto", "1", "2"):
        return jsonify(error="Choose Auto, Single column or Double column"), 400
    if job.get("status") == "processing":
        return jsonify(error="This document is already processing"), 409
    try:
        if not isinstance(selections, dict) or not isinstance(solutions, dict):
            raise ValueError()
        for p, regions in list(selections.items())+list(solutions.items())+list(boss_selections.items()):
            if not str(p).isdigit() or not 1 <= int(p) <= job["page_count"] or not isinstance(regions, list):
                raise ValueError()
            for r in regions:
                for k in ("x", "y", "w", "h"):
                    v = float(r[k])
                    if not math.isfinite(v) or not 0 <= v <= 1:
                        raise ValueError()
                    r[k] = v
                if r["w"] <= 0 or r["h"] <= 0 or r["x"]+r["w"] > 1.002 or r["y"]+r["h"] > 1.002:
                    raise ValueError()
                if r.get("kind", "text") not in ("text", "diagram", "table"):
                    raise ValueError()
    except (ValueError, TypeError, KeyError, AttributeError):
        return jsonify(error="Invalid selection. Check the page and draw the boxes again."), 400
    if not any(r.get("kind", "text") == "text" for rs in list(selections.values())+list(solutions.values())+list(boss_selections.values()) for r in rs):
        return jsonify(error="Select Questions, Solutions, or Boss Mode areas/pages before starting local recognition."), 400
    from word_options import export_options
    try:
        from solutions import validate_solution_selections
        validate_solution_selections(solutions)
        word_settings=export_options(data)
        if word_settings['start_number']+sum(r.get('kind','text')=='text' for rs in selections.values() for r in rs)-1>9999:
            raise ValueError('Question numbering exceeds 9999. Choose a lower start number.')
    except ValueError as exc:
        return jsonify(error=str(exc)), 400
    from engine_state import engine_status
    info = engine_status()
    if not info["ready"]:
        return jsonify(error=info["message"]), 503
    job["lock"] = threading.Lock()
    job["cancel"].clear()
    job["started_at"] = time.monotonic()
    job.pop("finished_at", None)
    job["cached_questions"] = 0
    job.pop("detected_questions", None)
    job["pages"] = pages
    job["selections"] = selections
    job["output_columns"] = output_columns
    job["export_options"] = word_settings
    job["boss"] = boss
    job["solutions"] = solutions
    job["solution_columns"] = solution_columns
    job.pop("documents", None)
    for child_id in job.pop("child_ids", []):
        JOBS.pop(child_id, None)
    job["error"] = None
    job["model"] = None
    job["original_model"] = None
    job["docx"] = None
    job["stats"] = None
    job["status"] = "processing"
    job["progress"] = 0
    job["stage"] = "Starting the local CPU engine…"
    try:
        threading.Thread(
            target=run_processing,
            args=(job_id, pages, crops, selections, output_columns),
            daemon=True,
        ).start()
    except Exception:
        job.update(status="error", error="Could not start local processing. Close other programs and retry.")
        return jsonify(error=job["error"]), 500
    return jsonify(status="started", recognition="local", api_required=False)


@app.route("/api/health")
def health():
    return jsonify(app="paper2word", version="6.8", ready=True)


@app.route("/api/cancel/<job_id>", methods=["POST"])
def cancel(job_id):
    job=JOBS.get(job_id)
    if not job:
        return jsonify(error="Invalid job"), 404
    job['cancel'].set()
    return jsonify(status="stopping")


@app.route("/api/diagnostics/<job_id>")
def diagnostics(job_id):
    job=JOBS.get(job_id)
    if not job:
        abort(404)
    from engine_state import engine_status
    report={"app_version":"6.8", "python":sys.version, "os":platform.platform(),
            "engine":engine_status(), "status":job['status'], "error":job['error']}
    out=io.BytesIO()
    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as bundle:
        bundle.writestr('status.json',json.dumps(report, ensure_ascii=False, indent=2))
        for p in [Path(job['dir'])/'error.log', *sorted((Path(job['dir'])/'recognition').glob('*.log')), *sorted((Path(job['dir'])/'solutions'/'recognition').glob('*.log')), *sorted((Path(job['dir'])/'boss'/'recognition').glob('*.log'))]:
            if p.is_file():
                # Fixed local log paths only. Never include the source PDF or
                # recognition JSON in a diagnostics download.
                bundle.writestr('logs/'+str(p.relative_to(Path(job['dir']))).replace('\\','/'),p.read_bytes()[-100000:])
    out.seek(0)
    return send_file(out, mimetype='application/zip', as_attachment=True, download_name='Paper2Word_error_details.zip')


@app.route("/api/engine")
def engine_info():
    from engine_state import engine_status
    return jsonify(engine_status())


@app.route("/api/status/<job_id>")
def status(job_id):
    job = JOBS.get(job_id)
    if not job:
        return jsonify(error="Invalid job"), 404
    return jsonify(
        status=job["status"],
        progress=job["progress"],
        stage=job["stage"],
        error=job["error"],
        stats=job["stats"],
        documents=job.get("documents", []),
        elapsed_seconds=round(job.get("finished_at", time.monotonic()) - job.get("started_at", time.monotonic()), 1),
        cached_questions=job.get("cached_questions", 0),
        detected_questions=job.get("detected_questions"),
    )


@app.route("/api/download/<job_id>")
def download(job_id):
    job = JOBS.get(job_id)
    if not job or job.get("status") != "done" or not job.get("docx") or not Path(job["docx"]).exists():
        abort(404)
    suffix = "_Boss_Mode" if job.get("document_category")=="boss" else "_Solutions" if job.get("document_category")=="solutions" else "_Questions"
    out_name = job["filename"].rsplit(".", 1)[0] + suffix + ".docx"
    return send_file(str(job["docx"]), as_attachment=True, download_name=out_name)


@app.route("/api/review/<job_id>", methods=["GET", "POST"])
def review(job_id):
    job = JOBS.get(job_id)
    if not job or job.get("status") != "done":
        return jsonify(error="Document is not ready. Upload/process it again if the app was restarted."), 400
    if request.method == "GET":
        return jsonify(model=job["model"], stats=job["stats"])
    if not job["lock"].acquire(blocking=False):
        return jsonify(error="A save is already running. Please wait."), 409
    try:
        from offline_layout import validate_model, export_docx
        incoming = request.get_json(force=True, silent=True)
        model = validate_model(incoming, job["original_model"])
        folder = Path(job["dir"])
        stats = export_docx(model, folder, Path(job["docx"]))
        (folder / "review_model.json").write_text(json.dumps(model, ensure_ascii=False, indent=2), encoding="utf-8")
        job.update(model=model, stats=stats)
        parent=JOBS.get(job.get('parent_id'), job)
        for doc in parent.get('documents', []):
            if doc['job_id']==job_id:doc['stats']=stats
        return jsonify(status="saved", model=model, stats=stats)
    except Exception as exc:
        return jsonify(error=f"Could not save changes: {exc}"), 400
    finally:
        job["lock"].release()


@app.route("/api/asset/<job_id>/<filename>")
def asset(job_id, filename):
    job = JOBS.get(job_id)
    if not job or not re.fullmatch(r"q[0-9]+_(?:source\.jpg|diagram[0-9]+\.png)", filename):
        abort(404)
    path = Path(job["dir"]) / "assets" / filename
    if not path.is_file():
        abort(404)
    return send_file(path)


@app.route("/api/equation-preview", methods=["POST"])
def equation_preview():
    try:
        from offline_layout import equation_xml
        data = request.get_json(force=True, silent=True) or {}
        _, mathml = equation_xml(data.get("latex"))
        return jsonify(mathml=mathml)
    except Exception as exc:
        return jsonify(error=f"Equation could not be parsed: {exc}"), 400


@app.after_request
def local_only_headers(response):
    # Browser traffic remains local. Recognition workers reject remote networking.
    response.headers["Cache-Control"] = "no-store"
    response.headers["Pragma"] = "no-cache"
    response.headers["Referrer-Policy"] = "no-referrer"
    response.headers["Content-Security-Policy"] = "default-src 'self' data: blob:; connect-src 'self'; img-src 'self' data: blob:; style-src 'self' 'unsafe-inline'; script-src 'self'; object-src 'none'; base-uri 'self'"
    return response


@atexit.register
def cleanup_workers():
    module=sys.modules.get('local_recognition')
    for job in JOBS.values():
        job['cancel'].set()
        process=job.get('worker_process')
        if module is not None and process is not None:
            try:module.stop_worker(process)
            except Exception:pass


if __name__ == "__main__":
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(0))
    port=int(os.environ.get('PAPER2WORD_PORT','5000'))
    app.run(host="127.0.0.1", port=port, threaded=True, debug=False)
