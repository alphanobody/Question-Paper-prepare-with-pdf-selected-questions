"""Boss Mode: explicit areas or strict whole-page choices, editable content flow."""
import re
import statistics


def page_numbers(spec, total):
    """Strict, bounded parser. Never silently omit an invalid page/range."""
    message = 'Boss Mode: use valid pages such as 1-3, 5. Every page must be within this PDF.'
    numbers = set()
    if isinstance(spec, list):
        if not spec or len(spec) > total:
            raise ValueError(message)
        for n in spec:
            if isinstance(n, bool) or not isinstance(n, int) or not 1 <= n <= total:
                raise ValueError(message)
            numbers.add(n)
    elif isinstance(spec, str) and spec.strip():
        for token in spec.split(','):
            match = re.fullmatch(r'\s*(\d{1,4})\s*(?:-\s*(\d{1,4})\s*)?', token)
            if not match:
                raise ValueError(message)
            lo = int(match[1]); hi = int(match[2] or match[1])
            if not 1 <= lo <= hi <= total:
                raise ValueError(message)
            numbers.update(range(lo, hi + 1))
    else:
        raise ValueError(message)
    return sorted(numbers)


def boss_settings(data, total):
    if data is None:
        return None
    if not isinstance(data, dict) or not isinstance(data.get('enabled', False), bool):
        raise ValueError('Invalid Boss Mode request.')
    if not data.get('enabled'):
        return None
    mode = data.get('input', 'areas')
    if mode not in ('areas', 'pages'):
        raise ValueError('Boss Mode: choose selected areas or whole pages.')
    columns = str(data.get('output_columns', 'auto'))
    if columns not in ('auto', '1', '2'):
        raise ValueError('Boss Mode: choose Auto, Single or Double Word columns.')
    selections = data.get('selections', {})
    if not isinstance(selections, dict):
        raise ValueError('Invalid Boss Mode area selections.')
    result = dict(input=mode, output_columns=columns, selections=selections, pages=[])
    if mode == 'pages':
        scope = data.get('page_scope', 'all')
        if scope == 'all':
            pages = list(range(1, total + 1))
        elif scope == 'current':
            pages = page_numbers([data.get('current_page')], total)
        elif scope == 'specific':
            pages = page_numbers(data.get('pages'), total)
        else:
            raise ValueError('Boss Mode: choose Current page, Specific pages or All pages.')
        result['pages'] = pages
        # Whole-page conversion is explicit: stored area boxes are NOT used.
        full = {str(p): [dict(x=0., y=0., w=1., h=1., kind='text')] for p in pages}
        for p in pages:
            extras=selections.get(str(p), selections.get(p, []))
            if not isinstance(extras,list):raise ValueError('Invalid Boss Mode extra selections.')
            full[str(p)].extend(r for r in extras if isinstance(r,dict) and r.get('kind') in ('diagram','table'))
        result['selections'] = full
    elif not any(r.get('kind', 'text') == 'text' for rs in selections.values() if isinstance(rs, list) for r in rs if isinstance(r, dict)):
        raise ValueError('Boss Mode: draw at least one main area, or choose Whole pages to convert without boxes.')
    return result


def infer_split(clip, lines, preferred=None):
    """Conservative two-column inference from real native/OCR line boxes."""
    x0, y0, x1, y1 = map(float, clip)
    width = x1-x0
    if preferred and x0 + width*.15 < preferred < x1-width*.15:
        return float(preferred)
    boxes = [r['bbox'] for r in lines if len(str(r.get('text', '')).strip()) >= 4]
    if len(boxes) < 6:
        return None
    for ratio in (.5, .48, .52):
        mid = x0+width*ratio; gap = width*.012
        left = [b for b in boxes if b[2] < mid+gap and b[0] < mid-width*.15]
        right = [b for b in boxes if b[0] > mid-gap and b[2] > mid+width*.15]
        crossing = [b for b in boxes if b[0] < mid-gap and b[2] > mid+gap]
        if len(left) >= 3 and len(right) >= 3 and len(crossing) <= max(3, len(boxes)*.15):
            lo = min(b[1] for b in left); hi = max(b[3] for b in left)
            if any(b[3] > lo and b[1] < hi for b in right):
                return mid
    return None


def order_flow_items(items, page, clip, geometry):
    """Keep spanning headings/tables intact; read columns within horizontal bands."""
    from offline_layout import source_columns
    from editable_export import reading_order
    _, preferred = source_columns(page)
    split = infer_split(list(clip), geometry, preferred)
    events = []
    for item in items:
        bbox = item.get('bbox')
        if bbox is None:
            x = clip.x0 + float(item.get('indent', 0)); y = float(item.get('y', clip.y0))
            bbox = [x, y, min(clip.x1, x+1), y+1]
        events.append(dict(bbox=bbox, item=item))
    headers=[e for e in events if e['item'].get('flow_role') in ('header','page_header')]
    footers=[e for e in events if e['item'].get('flow_role') in ('footer','page_footer','page_number')]
    body=[e for e in events if e not in headers and e not in footers]
    ordered = sorted(headers,key=lambda e:(e['bbox'][1],e['bbox'][0]))+reading_order(body, split)+sorted(footers,key=lambda e:(e['bbox'][1],e['bbox'][0]))
    # Relative indents are stored in font-size-independent em units. Remove
    # each column's common PDF page margin instead of doubling it in Word.
    groups = {}
    for event in ordered:
        b = event['bbox']
        column = 'wide' if split and b[0] < split-8 and b[2] > split+8 else int(bool(split and b[0] >= split))
        groups.setdefault(column, []).append(event)
    native_sizes = [s.get('size', 11) for b in page.get_text('dict', clip=clip).get('blocks', []) if b.get('type') == 0 for ln in b.get('lines', []) for s in ln.get('spans', []) if s.get('text', '').strip()]
    source_size = statistics.median(native_sizes) if native_sizes else 11.
    source_size = max(5., min(40., source_size))
    for column, group in groups.items():
        text_events = [e for e in group if e['item']['type'] == 'text']
        base = min(e['bbox'][0] for e in (text_events or group))
        for event in group:
            item = event['item']
            item['flow_indent_em'] = max(0., min(40., (event['bbox'][0]-base)/source_size))
            item['flow_source_column'] = column
            item['flow_source_width'] = (clip.x1-clip.x0 if column == 'wide' or not split else split-clip.x0 if column == 0 else clip.x1-split)
    return [e['item'] for e in ordered], split


def recover_manual_tables(items, geometry, tables):
    """Manual recovery is local to its table, never across two prose columns."""
    from offline_layout import contained, word_lines, make_table
    import pymupdf as fitz
    warnings = []
    for table in tables:
        if any(i['type'] == 'table' and contained(fitz.Rect(i.get('bbox', [0,0,0,0])), table, .5) for i in items):
            continue
        rows = [ln for ln in geometry if contained(ln['bbox'], table, .5)]
        if not rows:
            warnings.append('A marked Boss Mode table had no readable OCR lines; check the original.')
            continue
        recovered = make_table(word_lines(rows), table, manual=True)
        recovered.update(y=table.y0, bbox=list(table))
        items = [i for i in items if not contained(fitz.Rect(i.get('bbox', [0,0,0,0])), table, .5)]
        items.append(recovered)
        warnings.append('A Boss Mode table was rebuilt from its explicitly marked text-line geometry; verify cells and equations.')
    return items, warnings


def finish_boss_model(model, settings):
    from local_recognition import LocalRecognitionError
    kept = []
    for block in model['questions']:
        if not block['items']:
            model['warnings'].append(f"Boss Mode skipped an empty/unreadable area on page {block['page']}.")
        else:
            block['number_normalized'] = True
            kept.append(block)
    if not kept:
        raise LocalRecognitionError('Boss Mode found no editable content in the chosen pages/areas. Check the PDF or select a smaller readable area. No whole-page picture fallback was used.')
    model['questions'] = kept
    model['document_category'] = 'boss'
    model['boss_input'] = settings['input']
    model['boss_pages'] = list(settings.get('pages', []))
    model['preserve_source_columns'] = False
    model['warnings'].append('Boss Mode keeps source numbering and labels as recognised text; no automatic question numbers or answer-choice relabelling. Content reflows in Word. Exact PDF positions, typography and pagination are not guaranteed. Whole-page input includes printed headers/footers as body content.')
    return model


def plan_boss_regions(page, clip, lines, preferred=None, protected=None):
    """Small serial OCR units, not semantic questions or generated Word numbers.

    Spanning headers/objects remain full-width; ordinary bands are read left
    column then right. Use clear source headings as safe internal tile edges.
    Long unnumbered areas are cut only at observed line gaps, not fixed pixels.
    """
    import pymupdf as fitz
    from question_split import split_selection
    protected = list(protected or [])
    for info in page.get_image_info():
        b=fitz.Rect(info['bbox']) & clip
        if not b.is_empty and b.get_area()<clip.get_area()*.85:protected.append(b)
    split=infer_split(list(clip),lines,preferred)
    spans=[]
    if split:
        for line in lines:
            b=fitz.Rect(line['bbox']) & clip
            if b.x0<split-8 and b.x1>split+8:spans.append([max(clip.y0,b.y0-2),min(clip.y1,b.y1+2)])
        for r in protected:
            b=fitz.Rect(r)&clip
            if not b.is_empty and b.x0<split-8 and b.x1>split+8:spans.append([max(clip.y0,b.y0-2),min(clip.y1,b.y1+2)])
    spans.sort();merged=[]
    for top,bottom in spans:
        if merged and top<=merged[-1][1]+4:merged[-1][1]=max(merged[-1][1],bottom)
        else:merged.append([top,bottom])
    bands=[];top=clip.y0
    for a,b in merged:
        if a-top>1:bands.append((top,a,False))
        bands.append((a,b,True));top=b
    if clip.y1-top>1:bands.append((top,clip.y1,False))
    if not bands:bands=[(clip.y0,clip.y1,False)]
    regions=[]
    for top,bottom,wide in bands:
        columns=[fitz.Rect(clip.x0,top,clip.x1,bottom)] if wide or not split else [fitz.Rect(clip.x0,top,split,bottom),fitz.Rect(split,top,clip.x1,bottom)]
        for column in columns:
            hits=[ln for ln in lines if (fitz.Rect(ln['bbox'])&column).get_area()>=fitz.Rect(ln['bbox']).get_area()*.5]
            # Keep blank geometric regions too: a genuine diagram can have no
            # OCR text. They are skipped later only if recognition finds nothing.
            pieces,_=split_selection(list(column),hits,None)
            safe=[]
            for piece in pieces:
                top=piece['bbox'][1]
                crosses=any(fitz.Rect(r).y0<top<fitz.Rect(r).y1 and fitz.Rect(r).x0<column.x1 and fitz.Rect(r).x1>column.x0 for r in protected)
                if safe and crosses:safe[-1]['bbox'][3]=piece['bbox'][3]
                else:safe.append(piece)
            for piece in safe:
                region=fitz.Rect(piece['bbox'])
                if region.height<=390:
                    regions.append(region);continue
                # Avoid chopping through text lines or explicitly protected
                # figures/tables. Prefer a line gap close to 300 PDF points.
                intervals=[]
                for ln in hits:
                    b=fitz.Rect(ln['bbox'])&region
                    if not b.is_empty:intervals.append([b.y0-1,b.y1+1])
                for r in protected:
                    b=fitz.Rect(r)&region
                    if not b.is_empty:intervals.append([b.y0-1,b.y1+1])
                intervals.sort();occupied=[]
                for a,b in intervals:
                    if occupied and a<=occupied[-1][1]:occupied[-1][1]=max(occupied[-1][1],b)
                    else:occupied.append([a,b])
                gaps=[(occupied[i][1]+occupied[i+1][0])/2 for i in range(len(occupied)-1) if occupied[i+1][0]-occupied[i][1]>=1.5]
                y=region.y0
                while region.y1-y>390:
                    possible=[g for g in gaps if y+100<=g<=min(y+390,region.y1-35)]
                    if not possible:break
                    cut=min(possible,key=lambda g:abs(g-(y+300)))
                    regions.append(fitz.Rect(region.x0,y,region.x1,cut));y=cut
                regions.append(fitz.Rect(region.x0,y,region.x1,region.y1))
    if not regions:regions=[clip]
    warning=[]
    if len(regions)>1:warning.append('Boss Mode used small serial recognition regions to limit RAM. They are rejoined as continuous source content, without added question numbers. Check long tables/formulas and paragraph joins near region boundaries.')
    return [dict(bbox=list(r),source_number=None,source_columns=2 if split and not any(r.y0>=a-.1 and r.y1<=b+.1 for a,b in merged) else 1) for r in regions],warning
