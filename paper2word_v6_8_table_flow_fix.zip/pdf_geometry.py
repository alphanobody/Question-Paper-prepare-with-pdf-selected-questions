"""Use displayed PDF coordinates consistently for preview, OCR, images and paths.

Only the app's saved working copy is changed, never the original upload file.
No page rasterisation, neural orientation guess or whole-page image is added.
"""
from pathlib import Path


def normalize_page_rotations(path):
    import pymupdf as fitz
    path=Path(path);temp=path.with_name(path.stem+'_geometry.tmp.pdf')
    try:
        with fitz.open(path) as doc:
            if doc.needs_pass:return []
            changed=[dict(page=i+1,rotation=p.rotation) for i,p in enumerate(doc) if p.rotation]
            if not changed:return []
            offset_crop=any(p.rotation and p.cropbox!=p.mediabox for p in doc)
            if offset_crop:
                # PyMuPDF 1.26.7 remove_rotation assumes a full MediaBox. On
                # offset CropBoxes it can shift/resize content. Reframe those
                # documents as VECTOR PDF forms instead, preserving appearance.
                # Bake visible annotations only in this working copy, so their
                # appearances are copied too; original PDF remains untouched.
                doc.bake(annots=True,widgets=True)
                with fitz.open() as normalized:
                    for i,page in enumerate(doc):
                        rotation=page.rotation
                        if not rotation:
                            normalized.insert_pdf(doc,from_page=i,to_page=i)
                            continue
                        displayed=page.rect
                        page.set_rotation(0)
                        target=normalized.new_page(width=displayed.width,height=displayed.height)
                        try:target.show_pdf_page(target.rect,doc,i,rotate=-rotation)
                        except ValueError as exc:
                            if 'nothing to show' not in str(exc).lower():raise
                    normalized.set_metadata(doc.metadata)
                    normalized.save(temp,garbage=0,deflate=False)
            else:
                for page in doc:
                    if page.rotation:
                        # NOT set_rotation(0): transfer rotation into contents
                        # so the displayed orientation and positions stay put.
                        page.remove_rotation()
                doc.save(temp,garbage=0,deflate=False)
        temp.replace(path)
        return changed
    finally:
        temp.unlink(missing_ok=True)
